import React, { useState } from 'react';
import {
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  BookOpen,
  ArrowRight,
  Compass,
  Award
} from 'lucide-react';
import { CURRICULUM_CHAPTERS } from '../data/curriculumData';
import { useCosmosStore } from '../store/useCosmosStore';
import { soundEngine } from '../utils/soundEngine';
import { NewtonCannonWidget } from '../components/widgets/NewtonCannonWidget';
import { InverseSquareLightWidget } from '../components/widgets/InverseSquareLightWidget';
import { LunarPhaseWheelWidget } from '../components/widgets/LunarPhaseWheelWidget';
import { OrbitalTiltNodeWidget } from '../components/widgets/OrbitalTiltNodeWidget';
import { DensityComparisonWidget } from '../components/widgets/DensityComparisonWidget';
import { EscapeVelocityWidget } from '../components/widgets/EscapeVelocityWidget';
import { FormulaInspector } from '../components/shared/FormulaInspector';
import { POECard } from '../components/shared/POECard';
import { VectorLegend } from '../components/shared/VectorLegend';

export const AcademyPage: React.FC = () => {
  const {
    gradeTier,
    completedChapters,
    completeChapter,
    setActiveTab,
    addXP
  } = useCosmosStore();

  const [activeChapterIdx, setActiveChapterIdx] = useState<number>(0);
  const [showFormulaDrawer, setShowFormulaDrawer] = useState<boolean>(false);

  const currentChapter = CURRICULUM_CHAPTERS[activeChapterIdx];
  const currentCard = currentChapter.cards[0];
  const isChapterDone = completedChapters.includes(currentChapter.id);

  const renderWidget = (type: string) => {
    switch (type) {
      case 'newton-cannon':
        return <NewtonCannonWidget />;
      case 'inverse-square':
        return <InverseSquareLightWidget />;
      case 'kepler':
        return <NewtonCannonWidget />; // Can share interactive Kepler orbit / Cannon physics
      case 'lunar-phase':
        return <LunarPhaseWheelWidget />;
      case 'orbital-tilt':
        return <OrbitalTiltNodeWidget />;
      case 'density-compare':
        return <DensityComparisonWidget />;
      case 'escape-velocity':
        return <EscapeVelocityWidget />;
      default:
        return <NewtonCannonWidget />;
    }
  };

  const handleNextChapter = () => {
    soundEngine.playClick(800);
    completeChapter(currentChapter.id);
    if (activeChapterIdx < CURRICULUM_CHAPTERS.length - 1) {
      setActiveChapterIdx((prev) => prev + 1);
      setShowFormulaDrawer(false);
    }
  };

  const handlePrevChapter = () => {
    soundEngine.playClick(600);
    if (activeChapterIdx > 0) {
      setActiveChapterIdx((prev) => prev - 1);
      setShowFormulaDrawer(false);
    }
  };

  const handleDeepLink = () => {
    if (currentChapter.deepLinkTab) {
      soundEngine.playOrbitLock();
      setActiveTab(currentChapter.deepLinkTab);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Page Title & Vector Legend */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1 rounded-md bg-cyan-500/20 text-cyan-400">
              <BookOpen className="w-4 h-4" />
            </span>
            <span className="text-xs font-mono uppercase text-cyan-400 font-bold tracking-wider">
              Astrophy-Style Theory Deck
            </span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-heading font-extrabold text-white">
            Cosmic Academy
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Interactive bite-sized theory cards engineered with PhET’s Implicit Scaffolding and Richard Mayer’s Multimedia Learning Principles.
          </p>
        </div>

        <VectorLegend />
      </div>

      {/* Main 2-Column Responsive Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Chapter Roadmap (4 cols on lg) */}
        <div className="lg:col-span-4 bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 p-4 space-y-2">
          <div className="flex items-center justify-between mb-3 px-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Curriculum Roadmap
            </span>
            <span className="text-[11px] font-mono text-cyan-400">
              {completedChapters.length} / {CURRICULUM_CHAPTERS.length} Done
            </span>
          </div>

          <div className="space-y-1.5">
            {CURRICULUM_CHAPTERS.map((ch, idx) => {
              const isSelected = activeChapterIdx === idx;
              const isCompleted = completedChapters.includes(ch.id);

              return (
                <button
                  key={ch.id}
                  onClick={() => {
                    soundEngine.playClick(700);
                    setActiveChapterIdx(idx);
                    setShowFormulaDrawer(false);
                  }}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 border-cyan-400/60 shadow-md text-white'
                      : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-800/60 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`w-6 h-6 rounded-lg text-xs font-mono font-bold flex items-center justify-center shrink-0 ${
                        isCompleted
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : isSelected
                          ? 'bg-cyan-500 text-slate-950 font-bold'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {isCompleted ? '✓' : ch.number}
                    </span>
                    <div>
                      <div className="text-xs font-bold font-heading line-clamp-1">{ch.title}</div>
                      <div className="text-[10px] text-slate-400 line-clamp-1">{ch.subtitle}</div>
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 shrink-0 ${isSelected ? 'text-cyan-400' : 'text-slate-600'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Interactive Card Stage (8 cols on lg) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 shadow-2xl">
            {/* Top Card Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div>
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest font-bold">
                  Chapter {currentChapter.number} • Tier: {gradeTier}
                </span>
                <h2 className="text-xl font-heading font-extrabold text-white mt-0.5">
                  {currentCard.title}
                </h2>
                <p className="text-xs text-slate-400 font-medium">
                  {currentCard.subtitle}
                </p>
              </div>

              {isChapterDone && (
                <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                </span>
              )}
            </div>

            {/* Embedded Micro-Widget (50% card height) */}
            <div className="my-3 min-h-[290px] flex items-center justify-center">
              {renderWidget(currentCard.widgetType)}
            </div>

            {/* Mayer's Principle Concise Explanation (Strictly under 55 words) */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 my-4 text-xs lg:text-sm text-slate-200 leading-relaxed font-sans">
              <span className="text-[10px] font-mono text-slate-400 block mb-1 uppercase tracking-wider font-semibold">
                Pedagogical Core Concept:
              </span>
              {currentCard.explanation[gradeTier]}
            </div>

            {/* Collapsible "Go Deeper: Math Formula" Drawer */}
            {currentCard.formula && (
              <div className="my-3">
                <button
                  onClick={() => setShowFormulaDrawer(!showFormulaDrawer)}
                  className="flex items-center gap-2 text-xs font-mono font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  <span>{showFormulaDrawer ? '▼ Collapse Mathematical Derivation' : '▶ Go Deeper: Mathematical Formulation'}</span>
                </button>
                {showFormulaDrawer && (
                  <FormulaInspector
                    latex={currentCard.formula.latex}
                    bindings={currentCard.formula.bindings}
                  />
                )}
              </div>
            )}

            {/* POE Checkpoint Prompt */}
            {currentCard.poeCheckpoint && (
              <POECard
                prompt={currentCard.poeCheckpoint}
                onComplete={() => completeChapter(currentChapter.id)}
              />
            )}

            {/* Card Footer Navigation & Deep Link CTA */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800 mt-4">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  disabled={activeChapterIdx === 0}
                  onClick={handlePrevChapter}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold text-slate-300 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" /> Previous
                </button>
                <button
                  disabled={activeChapterIdx === CURRICULUM_CHAPTERS.length - 1}
                  onClick={handleNextChapter}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 py-2 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors shadow-lg shadow-cyan-500/20"
                >
                  Continue Next <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Contextual Deep Link Button */}
              {currentChapter.deepLinkTab && (
                <button
                  onClick={handleDeepLink}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 py-2 px-3.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-xs font-semibold transition-colors"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Launch Matching Lab Preset →</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
