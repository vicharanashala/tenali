import React, { useState } from 'react';
import { soundEngine } from '../../utils/soundEngine';

export const InverseSquareLightWidget: React.FC = () => {
  const [distance, setDistance] = useState<number>(2.0); // 1.0 to 3.0

  const area = distance * distance;
  const intensity = 1 / area;

  const handleDistanceChange = (newDist: number) => {
    soundEngine.playClick(600 + newDist * 200);
    setDistance(newDist);
  };

  return (
    <div className="flex flex-col items-center w-full h-full bg-slate-950/60 p-3 rounded-xl border border-slate-800">
      <div className="w-full flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Inverse-Square Law</span>
        <span className="text-xs font-mono text-amber-400 font-bold">F ∝ 1 / r²</span>
      </div>

      {/* SVG 3D Perspective Light Pyramid */}
      <div className="w-full max-w-[340px] aspect-[16/9] relative flex items-center justify-center">
        <svg viewBox="0 0 340 180" className="w-full h-full overflow-visible">
          <defs>
            <radialGradient id="sourceGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FACC15" stopOpacity="1" />
              <stop offset="50%" stopColor="#F59E0B" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#F59E0B" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="beamGrad" x1="0%" y1="50%" x2="100%" y2="50%">
              <stop offset="0%" stopColor="rgba(250, 204, 21, 0.45)" />
              <stop offset="100%" stopColor="rgba(250, 204, 21, 0.05)" />
            </linearGradient>
          </defs>

          {/* Point Source */}
          <circle cx="35" cy="90" r="16" fill="url(#sourceGlow)" />
          <circle cx="35" cy="90" r="6" fill="#FFFFFF" />

          {/* Light emission pyramid lines */}
          <polygon
            points="35,90 310,15 310,165"
            fill="url(#beamGrad)"
          />
          <line x1="35" y1="90" x2="310" y2="15" stroke="#FACC15" strokeWidth="1" strokeDasharray="3 3" opacity="0.6" />
          <line x1="35" y1="90" x2="310" y2="165" stroke="#FACC15" strokeWidth="1" strokeDasharray="3 3" opacity="0.6" />

          {/* Reference Distance Marker Lines: 1r, 2r, 3r */}
          {[1, 2, 3].map((rVal) => {
            const rx = 35 + rVal * 85;
            const rHeight = rVal * 45;
            const isSelected = Math.abs(distance - rVal) < 0.2;

            return (
              <g key={rVal} opacity={isSelected ? 1.0 : 0.45}>
                <line
                  x1={rx}
                  y1={90 - rHeight / 2}
                  x2={rx}
                  y2={90 + rHeight / 2}
                  stroke={isSelected ? '#38BDF8' : '#94A3B8'}
                  strokeWidth={isSelected ? 2 : 1}
                  strokeDasharray={isSelected ? 'none' : '2 2'}
                />
                <text
                  x={rx}
                  y="176"
                  textAnchor="middle"
                  fill={isSelected ? '#38BDF8' : '#64748B'}
                  fontSize="10"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  {rVal}r
                </text>
              </g>
            );
          })}

          {/* Dynamic Draggable Target Screen */}
          {(() => {
            const screenX = 35 + distance * 85;
            const screenH = distance * 45;
            const screenW = distance * 18;
            const topY = 90 - screenH / 2;

            return (
              <g>
                {/* Projected Grid Face */}
                <rect
                  x={screenX - screenW / 2}
                  y={topY}
                  width={screenW}
                  height={screenH}
                  fill="rgba(56, 189, 248, 0.2)"
                  stroke="#38BDF8"
                  strokeWidth="2"
                  rx="4"
                />

                {/* Sub-grid tiles showing 1x, 4x, 9x expansion */}
                <text
                  x={screenX}
                  y={90}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="#F8FAFC"
                  fontSize="12"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  Area: {area.toFixed(1)}×
                </text>
              </g>
            );
          })()}
        </svg>
      </div>

      {/* Telemetry Comparison Readout */}
      <div className="grid grid-cols-3 gap-2 w-full mt-2 font-mono text-center">
        <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
          <div className="text-[10px] uppercase text-slate-400">Distance (r)</div>
          <div className="text-cyan-400 font-bold text-sm">{distance.toFixed(1)}r</div>
        </div>
        <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
          <div className="text-[10px] uppercase text-slate-400">Spread Area (A)</div>
          <div className="text-purple-400 font-bold text-sm">{area.toFixed(2)}×</div>
        </div>
        <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
          <div className="text-[10px] uppercase text-slate-400">Force / Flux (F)</div>
          <div className="text-amber-400 font-bold text-sm">{(intensity * 100).toFixed(0)}%</div>
        </div>
      </div>

      {/* Slider Control */}
      <div className="w-full mt-3">
        <input
          type="range"
          min="1.0"
          max="3.0"
          step="0.1"
          value={distance}
          onChange={(e) => handleDistanceChange(parseFloat(e.target.value))}
          className="w-full accent-amber-400 cursor-pointer"
        />
        <div className="flex justify-between text-[11px] text-slate-500 font-mono mt-1">
          <span>1.0r (100% force)</span>
          <span>2.0r (25% force)</span>
          <span>3.0r (11.1% force)</span>
        </div>
      </div>
    </div>
  );
};
