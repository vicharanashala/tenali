import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Compass,
  ZoomIn,
  Target,
  Sliders,
  CheckCircle2,
  Award,
  ArrowRight,
  Eye,
  FastForward,
  Mic,
  MicOff
} from 'lucide-react';
import { TutorialMiniScene } from './TutorialMiniScene';
import { useCosmosStore } from '../../store/useCosmosStore';
import { soundEngine } from '../../utils/soundEngine';

export const TutorialOverlay: React.FC = () => {
  const {
    tutorialCompleted,
    tutorialCurrentStep,
    setTutorialStep,
    completeTutorial,
    voiceCaptions,
    toggleVoiceCaptions,
    setActiveTab
  } = useCosmosStore();

  const [cumulativeOrbitDelta, setCumulativeOrbitDelta] = useState<number>(0);
  const [zoomRatio, setZoomRatio] = useState<number>(1.0);
  const [moonInspected, setMoonInspected] = useState<boolean>(false);
  const [showVectors, setShowVectors] = useState<boolean>(false);
  const [timeSpeed, setTimeSpeed] = useState<number>(1.0);

  // If completed and not manually replayed, don't render overlay
  if (tutorialCompleted && tutorialCurrentStep === 5) {
    return null;
  }

  // Text-to-speech for steps
  useEffect(() => {
    const stepInstructions: Record<number, string> = {
      1: "Welcome to Cosmos Lab Flight School. Click and drag your mouse or finger to orbit the 3D camera 45 degrees.",
      2: "Great. Now scroll your mouse wheel or pinch to zoom in and out.",
      3: "Now tap on the Moon to lock telemetry and inspect its physical parameters.",
      4: "Turn on the velocity and gravity vectors, and adjust the simulation time speed.",
      5: "Flight certified! You have mastered the 3D orbital flight deck. Welcome aboard, Cadet!"
    };

    if (voiceCaptions && stepInstructions[tutorialCurrentStep]) {
      soundEngine.speak(stepInstructions[tutorialCurrentStep], true);
    }
  }, [tutorialCurrentStep, voiceCaptions]);

  // Step 1: Orbit trigger (45 deg = 0.785 rad)
  const handleOrbitDelta = (delta: number) => {
    if (tutorialCurrentStep !== 1) return;
    setCumulativeOrbitDelta((prev) => {
      const updated = prev + delta;
      if (updated >= 0.785) {
        soundEngine.playOrbitLock();
        setTimeout(() => setTutorialStep(2), 400);
      }
      return updated;
    });
  };

  // Step 2: Zoom trigger
  const handleZoomDelta = (currentDist: number, initialDist: number) => {
    if (tutorialCurrentStep !== 2) return;
    const ratio = currentDist / initialDist;
    setZoomRatio(ratio);
    if (ratio < 0.65 || ratio > 1.35) {
      soundEngine.playOrbitLock();
      setTimeout(() => setTutorialStep(3), 400);
    }
  };

  // Step 3: Moon clicked
  const handleSelectMoon = () => {
    if (tutorialCurrentStep !== 3) return;
    setMoonInspected(true);
    soundEngine.playOrbitLock();
    setTimeout(() => setTutorialStep(4), 500);
  };

  // Step 4: Vectors + Time change
  const handleToggleVectors = () => {
    soundEngine.playClick(800);
    const nextVal = !showVectors;
    setShowVectors(nextVal);
    if (nextVal && timeSpeed !== 1.0 && tutorialCurrentStep === 4) {
      soundEngine.playOrbitLock();
      setTimeout(() => setTutorialStep(5), 400);
    }
  };

  const handleTimeChange = (speed: number) => {
    soundEngine.playClick(650);
    setTimeSpeed(speed);
    if (showVectors && speed !== 1.0 && tutorialCurrentStep === 4) {
      soundEngine.playOrbitLock();
      setTimeout(() => setTutorialStep(5), 400);
    }
  };

  // Step 5: Confetti trigger
  useEffect(() => {
    if (tutorialCurrentStep === 5) {
      soundEngine.playVictory();
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 }
      });
    }
  }, [tutorialCurrentStep]);

  const orbitProgressPercent = Math.min(100, Math.round((cumulativeOrbitDelta / 0.785) * 100));

  return (
    <div className="fixed inset-0 z-50 bg-[#050814] flex flex-col justify-between overflow-hidden">
      {/* 3D Mini Scene Background */}
      <div className="absolute inset-0">
        <TutorialMiniScene
          onOrbitDelta={handleOrbitDelta}
          onZoomDelta={handleZoomDelta}
          onSelectMoon={handleSelectMoon}
          showVectors={showVectors}
          timeSpeed={timeSpeed}
        />
      </div>

      {/* Top Bar Overlay */}
      <div className="relative z-10 w-full p-4 flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-3 bg-slate-950/80 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-800">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <div>
            <span className="text-xs font-heading font-bold text-white uppercase tracking-wider block">
              Stage 0: Flight School Tutorial
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Step {tutorialCurrentStep} of 5 Active
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Voice captions toggle */}
          <button
            onClick={toggleVoiceCaptions}
            className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 backdrop-blur-md transition-colors ${
              voiceCaptions ? 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40' : 'bg-slate-900/80 text-slate-400 border-slate-800'
            }`}
          >
            {voiceCaptions ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            <span className="hidden sm:inline">Voice: {voiceCaptions ? 'ON' : 'OFF'}</span>
          </button>

          {/* Skip Tutorial */}
          <button
            onClick={() => completeTutorial()}
            className="py-2 px-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 text-xs font-semibold backdrop-blur-md transition-colors"
          >
            Skip Tutorial →
          </button>
        </div>
      </div>

      {/* Center Spotlight & Guidance HUD */}
      <div className="relative z-10 max-w-lg mx-auto w-full px-4 my-auto pointer-events-none">
        {/* Step 1: Orbit Camera */}
        {tutorialCurrentStep === 1 && (
          <div className="pointer-events-auto p-5 rounded-2xl bg-slate-950/85 backdrop-blur-xl border border-cyan-500/40 text-center shadow-2xl animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-cyan-500/20 text-cyan-400 mx-auto flex items-center justify-center mb-3 border border-cyan-400/30">
              <Compass className="w-6 h-6 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <h3 className="font-heading font-bold text-white text-base mb-1">1. Orbit the 3D Camera</h3>
            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Click and drag across the screen to rotate around the Earth–Moon system.
            </p>
            {/* Progress ring bar */}
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-cyan-400 h-full transition-all duration-200"
                style={{ width: `${orbitProgressPercent}%` }}
              />
            </div>
            <span className="text-[11px] font-mono text-cyan-400 mt-2 block font-bold">
              {orbitProgressPercent}% of 45° rotation completed
            </span>
          </div>
        )}

        {/* Step 2: Zoom */}
        {tutorialCurrentStep === 2 && (
          <div className="pointer-events-auto p-5 rounded-2xl bg-slate-950/85 backdrop-blur-xl border border-purple-500/40 text-center shadow-2xl animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-purple-500/20 text-purple-400 mx-auto flex items-center justify-center mb-3 border border-purple-400/30">
              <ZoomIn className="w-6 h-6 animate-pulse" />
            </div>
            <h3 className="font-heading font-bold text-white text-base mb-1">2. Zoom & Adjust Scale</h3>
            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Use your mouse scroll wheel or two-finger pinch gesture to zoom in close to Earth or zoom out.
            </p>
            <div className="text-xs font-mono text-purple-300 bg-slate-900/90 py-1.5 px-3 rounded-lg border border-slate-800 inline-block">
              Camera Distance Ratio: {zoomRatio.toFixed(2)}×
            </div>
          </div>
        )}

        {/* Step 3: Inspect Body */}
        {tutorialCurrentStep === 3 && (
          <div className="pointer-events-auto p-5 rounded-2xl bg-slate-950/85 backdrop-blur-xl border border-amber-500/40 text-center shadow-2xl animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 mx-auto flex items-center justify-center mb-3 border border-amber-400/30">
              <Target className="w-6 h-6 animate-bounce" />
            </div>
            <h3 className="font-heading font-bold text-white text-base mb-1">3. Inspect Celestial Body</h3>
            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Click or tap directly on the orbiting Moon in the 3D scene to lock target telemetry.
            </p>
            <button
              onClick={handleSelectMoon}
              className="py-1.5 px-4 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-semibold transition-colors"
            >
              Simulate Moon Click
            </button>
          </div>
        )}

        {/* Step 4: Toggle Vectors & Time */}
        {tutorialCurrentStep === 4 && (
          <div className="pointer-events-auto p-5 rounded-2xl bg-slate-950/90 backdrop-blur-xl border border-cyan-500/40 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center gap-2 mb-2 justify-center">
              <Sliders className="w-5 h-5 text-cyan-400" />
              <h3 className="font-heading font-bold text-white text-base">4. Physics Vectors & Time Speed</h3>
            </div>
            <p className="text-xs text-slate-300 text-center mb-4 leading-relaxed">
              Enable physics vector overlays (Cyan velocity & Amber force) AND adjust the time speed slider away from 1.0×.
            </p>

            <div className="space-y-3 bg-slate-900/90 p-3 rounded-xl border border-slate-800">
              <button
                onClick={handleToggleVectors}
                className={`w-full py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all border ${
                  showVectors
                    ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                <Eye className="w-4 h-4" /> Vectors: {showVectors ? 'ACTIVE (Cyan & Amber)' : 'DISABLED'}
              </button>

              <div>
                <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                  <span>Warp Time Speed:</span>
                  <span className="text-amber-400 font-bold">{timeSpeed.toFixed(1)}×</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="3.0"
                  step="0.2"
                  value={timeSpeed}
                  onChange={(e) => handleTimeChange(parseFloat(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 5: Flight Certified Victory */}
        {tutorialCurrentStep === 5 && (
          <div className="pointer-events-auto p-6 rounded-3xl bg-slate-950/95 backdrop-blur-2xl border-2 border-emerald-500/60 text-center shadow-2xl animate-in zoom-in-90">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center mb-3 border border-emerald-400/40">
              <Award className="w-8 h-8 animate-pulse" />
            </div>
            <h3 className="font-heading font-extrabold text-white text-xl mb-1">Flight Certified!</h3>
            <p className="text-xs text-slate-300 max-w-xs mx-auto mb-4 leading-relaxed">
              Congratulations, Cadet! You have unlocked your first achievement badge (+100 XP) and are cleared for cosmic exploration.
            </p>

            <div className="flex flex-col sm:flex-row gap-2 mt-4">
              <button
                onClick={() => {
                  completeTutorial();
                  setActiveTab('academy');
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-cyan-500/25"
              >
                Launch Cosmic Academy <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  completeTutorial();
                  setActiveTab('observatory');
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold text-xs border border-slate-700 transition-colors"
              >
                Explore 3D Space
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Step Dots */}
      <div className="relative z-10 w-full p-4 flex items-center justify-center gap-2 pointer-events-auto">
        {[1, 2, 3, 4, 5].map((step) => (
          <button
            key={step}
            onClick={() => setTutorialStep(step as any)}
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              tutorialCurrentStep === step
                ? 'w-7 bg-cyan-400'
                : step < tutorialCurrentStep
                ? 'bg-emerald-400'
                : 'bg-slate-800'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
