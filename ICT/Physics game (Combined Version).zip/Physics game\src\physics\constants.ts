// Standard SI Physical Constants
export const G_SI = 6.67430e-11; // m^3 kg^-1 s^-2
export const AU_METERS = 149597870700; // meters
export const AU_KM = 149597870.7; // km
export const C_LIGHT = 299792458; // m/s

// Celestial Mass (kg)
export const M_SUN = 1.98847e30;
export const M_EARTH = 5.9722e24;
export const M_MOON = 7.342e22;
export const M_MARS = 6.4171e23;
export const M_JUPITER = 1.8982e27;

// Mean Radii (km)
export const R_SUN_KM = 696340;
export const R_EARTH_KM = 6371;
export const R_MOON_KM = 1737.4;
export const R_MARS_KM = 3389.5;
export const R_JUPITER_KM = 69911;

// Earth-Moon distance (km)
export const DIST_EARTH_MOON_KM = 384400;

// Classroom scale factors vs True Scale
export const SCALE = {
  // Scaled 3D visualization units
  SUN_RADIUS_VISUAL: 3.5,
  EARTH_RADIUS_VISUAL: 1.0,
  MOON_RADIUS_VISUAL: 0.27,
  MARS_RADIUS_VISUAL: 0.53,
  JUPITER_RADIUS_VISUAL: 2.2,
  AU_VISUAL: 30.0,
  MOON_ORBIT_VISUAL: 4.5,
};
