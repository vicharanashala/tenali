// Constellation and Bright Star Catalog for Stellarium Sky Dome

export interface BrightStar {
  id: string;
  name: string;
  raHours: number;
  decDeg: number;
  mag: number;
  spectralClass: 'O' | 'B' | 'A' | 'F' | 'G' | 'K' | 'M';
  color: string;
  constellation: string;
}

export interface ConstellationFigure {
  id: string;
  name: string;
  englishName: string;
  raHours: number;
  decDeg: number;
  lines: [string, string][]; // Pairs of star names/keys to connect with stick lines
}

export const BRIGHT_STARS: BrightStar[] = [
  // Orion
  { id: 'betelgeuse', name: 'Betelgeuse', raHours: 5.92, decDeg: 7.41, mag: 0.5, spectralClass: 'M', color: '#FF7A59', constellation: 'Orion' },
  { id: 'rigel', name: 'Rigel', raHours: 5.24, decDeg: -8.20, mag: 0.18, spectralClass: 'B', color: '#9BB0FF', constellation: 'Orion' },
  { id: 'bellatrix', name: 'Bellatrix', raHours: 5.42, decDeg: 6.35, mag: 1.64, spectralClass: 'B', color: '#AABFFF', constellation: 'Orion' },
  { id: 'saiph', name: 'Saiph', raHours: 5.79, decDeg: -9.67, mag: 2.07, spectralClass: 'B', color: '#9BB0FF', constellation: 'Orion' },
  { id: 'alnitak', name: 'Alnitak', raHours: 5.68, decDeg: -1.94, mag: 1.74, spectralClass: 'O', color: '#889BFF', constellation: 'Orion' },
  { id: 'alnilam', name: 'Alnilam', raHours: 5.60, decDeg: -1.20, mag: 1.69, spectralClass: 'B', color: '#AABFFF', constellation: 'Orion' },
  { id: 'mintaka', name: 'Mintaka', raHours: 5.53, decDeg: -0.30, mag: 2.25, spectralClass: 'B', color: '#AABFFF', constellation: 'Orion' },

  // Ursa Major (Big Dipper)
  { id: 'dubhe', name: 'Dubhe', raHours: 11.06, decDeg: 61.75, mag: 1.8, spectralClass: 'K', color: '#FFD2A1', constellation: 'Ursa Major' },
  { id: 'merak', name: 'Merak', raHours: 11.03, decDeg: 56.38, mag: 2.37, spectralClass: 'A', color: '#CAD8FF', constellation: 'Ursa Major' },
  { id: 'phecda', name: 'Phecda', raHours: 11.90, decDeg: 53.69, mag: 2.44, spectralClass: 'A', color: '#CAD8FF', constellation: 'Ursa Major' },
  { id: 'megrez', name: 'Megrez', raHours: 12.25, decDeg: 57.03, mag: 3.32, spectralClass: 'A', color: '#CAD8FF', constellation: 'Ursa Major' },
  { id: 'alioth', name: 'Alioth', raHours: 12.90, decDeg: 55.96, mag: 1.76, spectralClass: 'A', color: '#CAD8FF', constellation: 'Ursa Major' },
  { id: 'mizar', name: 'Mizar', raHours: 13.40, decDeg: 54.92, mag: 2.23, spectralClass: 'A', color: '#CAD8FF', constellation: 'Ursa Major' },
  { id: 'alkaid', name: 'Alkaid', raHours: 13.79, decDeg: 49.31, mag: 1.85, spectralClass: 'B', color: '#9BB0FF', constellation: 'Ursa Major' },

  // Polaris (North Star)
  { id: 'polaris', name: 'Polaris', raHours: 2.53, decDeg: 89.26, mag: 1.97, spectralClass: 'F', color: '#F8F9FF', constellation: 'Ursa Minor' },

  // Cassiopeia
  { id: 'schedar', name: 'Schedar', raHours: 0.68, decDeg: 56.54, mag: 2.24, spectralClass: 'K', color: '#FFD2A1', constellation: 'Cassiopeia' },
  { id: 'caph', name: 'Caph', raHours: 0.15, decDeg: 59.15, mag: 2.28, spectralClass: 'F', color: '#F8F9FF', constellation: 'Cassiopeia' },
  { id: 'gamma_cas', name: 'Navi', raHours: 0.94, decDeg: 60.72, mag: 2.15, spectralClass: 'B', color: '#9BB0FF', constellation: 'Cassiopeia' },
  { id: 'ruchbah', name: 'Ruchbah', raHours: 1.43, decDeg: 60.23, mag: 2.66, spectralClass: 'A', color: '#CAD8FF', constellation: 'Cassiopeia' },
  { id: 'segin', name: 'Segin', raHours: 1.90, decDeg: 63.67, mag: 3.35, spectralClass: 'B', color: '#AABFFF', constellation: 'Cassiopeia' },

  // Canis Major / Sirius (Brightest star in night sky)
  { id: 'sirius', name: 'Sirius', raHours: 6.75, decDeg: -16.72, mag: -1.46, spectralClass: 'A', color: '#D8F0FF', constellation: 'Canis Major' },

  // Taurus / Aldebaran
  { id: 'aldebaran', name: 'Aldebaran', raHours: 4.60, decDeg: 16.51, mag: 0.85, spectralClass: 'K', color: '#FFA050', constellation: 'Taurus' },

  // Lyra / Vega
  { id: 'vega', name: 'Vega', raHours: 18.62, decDeg: 38.78, mag: 0.03, spectralClass: 'A', color: '#DCEBFF', constellation: 'Lyra' },

  // Scorpius / Antares
  { id: 'antares', name: 'Antares', raHours: 16.49, decDeg: -26.43, mag: 1.06, spectralClass: 'M', color: '#FF4D2D', constellation: 'Scorpius' },
  { id: 'shaula', name: 'Shaula', raHours: 17.56, decDeg: -37.10, mag: 1.62, spectralClass: 'B', color: '#AABFFF', constellation: 'Scorpius' },
  { id: 'dschubba', name: 'Dschubba', raHours: 16.00, decDeg: -22.62, mag: 2.29, spectralClass: 'B', color: '#9BB0FF', constellation: 'Scorpius' },

  // Southern Cross (Crux)
  { id: 'acrux', name: 'Acrux', raHours: 12.44, decDeg: -63.10, mag: 0.77, spectralClass: 'B', color: '#9BB0FF', constellation: 'Crux' },
  { id: 'mimosa', name: 'Mimosa', raHours: 12.79, decDeg: -59.69, mag: 1.25, spectralClass: 'B', color: '#9BB0FF', constellation: 'Crux' },
  { id: 'gahcrux', name: 'Gacrux', raHours: 12.52, decDeg: -57.11, mag: 1.59, spectralClass: 'M', color: '#FF7A59', constellation: 'Crux' },
  { id: 'impal', name: 'Imai', raHours: 12.25, decDeg: -58.75, mag: 2.79, spectralClass: 'B', color: '#AABFFF', constellation: 'Crux' },
];

export const CONSTELLATIONS: ConstellationFigure[] = [
  {
    id: 'orion',
    name: 'Orion',
    englishName: 'The Hunter',
    raHours: 5.5,
    decDeg: 0,
    lines: [
      ['betelgeuse', 'bellatrix'],
      ['bellatrix', 'mintaka'],
      ['mintaka', 'alnilam'],
      ['alnilam', 'alnitak'],
      ['alnitak', 'saiph'],
      ['saiph', 'rigel'],
      ['betelgeuse', 'alnitak'],
      ['rigel', 'mintaka']
    ]
  },
  {
    id: 'ursa_major',
    name: 'Ursa Major',
    englishName: 'The Big Dipper / Great Bear',
    raHours: 12.0,
    decDeg: 55,
    lines: [
      ['dubhe', 'merak'],
      ['merak', 'phecda'],
      ['phecda', 'megrez'],
      ['megrez', 'dubhe'], // The bowl
      ['megrez', 'alioth'],
      ['alioth', 'mizar'],
      ['mizar', 'alkaid'] // The handle
    ]
  },
  {
    id: 'cassiopeia',
    name: 'Cassiopeia',
    englishName: 'The Queen (W-shape)',
    raHours: 1.0,
    decDeg: 60,
    lines: [
      ['caph', 'schedar'],
      ['schedar', 'gamma_cas'],
      ['gamma_cas', 'ruchbah'],
      ['ruchbah', 'segin']
    ]
  },
  {
    id: 'crux',
    name: 'Crux',
    englishName: 'The Southern Cross',
    raHours: 12.5,
    decDeg: -60,
    lines: [
      ['gahcrux', 'acrux'],
      ['mimosa', 'impal']
    ]
  },
  {
    id: 'scorpius',
    name: 'Scorpius',
    englishName: 'The Scorpion',
    raHours: 16.8,
    decDeg: -30,
    lines: [
      ['dschubba', 'antares'],
      ['antares', 'shaula']
    ]
  }
];
