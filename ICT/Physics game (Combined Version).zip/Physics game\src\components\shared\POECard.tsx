import React, { useState } from 'react';
import { HelpCircle, CheckCircle2, AlertTriangle, ArrowRight, Sparkles } from 'lucide-react';
import { POEPrompt } from '../../types/curriculum';
import { useCosmosStore } from '../../store/useCosmosStore';
import { soundEngine } from '../../utils/soundEngine';

interface POECardProps {
  prompt: POEPrompt;
  onComplete?: () => void;
}

export const POECard: React.FC<POECardProps> = ({ prompt, onComplete }) => {
  const { gradeTier, addXP, recordPoeAnswer } = useCosmosStore();
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [stage, setStage] = useState<'predict' | 'observe' | 'explain'>('predict');

  const selectedOption = prompt.options.find((o) => o.id === selectedOptionId);
  const isCorrect = selectedOption?.isCorrect ?? false;

  const handlePredict = (optionId: string) => {
    setSelectedOptionId(optionId);
    soundEngine.playClick(750);
  };

  const handleLockPrediction = () => {
    if (!selectedOptionId) return;
    soundEngine.playOrbitLock();
    setStage('observe');
  };

  const handleFinishObservation = () => {
    setStage('explain');
    const baseXP = 25;
    const bonusXP = isCorrect ? 15 : 0;
    const totalXP = baseXP + bonusXP;

    recordPoeAnswer(isCorrect);
    addXP(totalXP, isCorrect ? 'Scientific Prediction Verified!' : 'Inquiry Completed');

    if (isCorrect) {
      soundEngine.playVictory();
    } else {
      soundEngine.playClick(650);
    }
  };

  return (
    <div className="w-full bg-slate-900/90 border border-slate-700/80 rounded-xl p-4 my-3 text-slate-100 shadow-xl">
      {/* Header Badge */}
      <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400 border border-purple-500/30">
            <HelpCircle className="w-4 h-4" />
          </span>
          <span className="text-xs font-bold uppercase tracking-wider text-purple-300">
            Predict–Observe–Explain (POE) Loop
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-mono">
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${stage === 'predict' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : stage === 'observe' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'}`}>
            Stage: {stage.toUpperCase()}
          </span>
          <span className="text-amber-400 font-semibold flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> +40 XP Max
          </span>
        </div>
      </div>

      {/* Stage 1: Predict */}
      {stage === 'predict' && (
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-slate-100">{prompt.question}</h4>
          <p className="text-xs text-slate-400 italic">Select your hypothesis before testing in the live simulation:</p>

          <div className="space-y-2">
            {prompt.options.map((opt) => (
              <button
                key={opt.id}
                onClick={() => handlePredict(opt.id)}
                className={`w-full text-left p-3 rounded-lg text-xs font-medium transition-all border ${
                  selectedOptionId === opt.id
                    ? 'bg-cyan-500/20 border-cyan-400 text-cyan-100 shadow-sm'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800/60 hover:border-slate-700'
                }`}
              >
                {opt.text}
              </button>
            ))}
          </div>

          <button
            disabled={!selectedOptionId}
            onClick={handleLockPrediction}
            className="w-full mt-3 py-2 px-4 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2"
          >
            Lock Prediction & Test Hypothesis <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Stage 2: Observe */}
      {stage === 'observe' && (
        <div className="space-y-3">
          <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
            <strong className="block mb-1">Your Hypothesis:</strong>
            "{selectedOption?.text}"
          </div>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300">
            <strong className="text-cyan-400 block mb-1">Observation Directive:</strong>
            {prompt.observeInstruction}
          </div>

          <button
            onClick={handleFinishObservation}
            className="w-full py-2 px-4 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2"
          >
            I Have Observed the Outcome <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Stage 3: Explain */}
      {stage === 'explain' && (
        <div className="space-y-3">
          <div className={`p-3 rounded-lg border flex items-start gap-2.5 ${isCorrect ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200' : 'bg-rose-500/10 border-rose-500/30 text-rose-200'}`}>
            {isCorrect ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            )}
            <div className="text-xs">
              <span className="font-bold block mb-1">
                {isCorrect ? 'Accurate Prediction! (+40 XP)' : 'Valuable Scientific Inquiry! (+25 XP)'}
              </span>
              <span>{prompt.explanation[gradeTier]}</span>
            </div>
          </div>

          {onComplete && (
            <button
              onClick={onComplete}
              className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
            >
              Continue Lesson →
            </button>
          )}
        </div>
      )}
    </div>
  );
};
