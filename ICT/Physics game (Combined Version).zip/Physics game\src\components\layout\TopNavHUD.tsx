﻿import React from 'react';
import {
  BookOpen,
  FlaskConical,
  Compass,
  Layers,
  Orbit,
  Volume2,
  VolumeX,
  HelpCircle,
  Award,
  Mic,
  MicOff
} from 'lucide-react';
import { useCosmosStore } from '../../store/useCosmosStore';
import { GradeTier } from '../../types/curriculum';

export const TopNavHUD: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    gradeTier,
    setGradeTier,
    xp,
    rank,
    isMuted,
    toggleMute,
    voiceCaptions,
    toggleVoiceCaptions,
    toggleQuestDrawer,
    setTutorialStep
  } = useCosmosStore();

  const tabs = [
    { id: 'academy' as const, label: 'Cosmic Academy', icon: BookOpen, shortcut: '1' },
    { id: 'simlab' as const, label: 'Physics Lab', icon: FlaskConical, shortcut: '2' },
    { id: 'observatory' as const, label: 'Solar Observatory', icon: Compass, shortcut: '3' },
    { id: 'materials' as const, label: 'Gravity & Materials', icon: Layers, shortcut: '4' },
    { id: 'space_hub' as const, label: 'Space 3D Hub', icon: Orbit, shortcut: '5' }
  ];

  const tiers: { id: GradeTier; label: string; desc: string }[] = [
    { id: '6-8', label: 'Cadet', desc: 'Class 6–8' },
    { id: '9-10', label: 'Navigator', desc: 'Class 9–10' },
    { id: '11-12', label: 'Astrophysicist', desc: 'Class 11–12' }
  ];

  // Calculate XP towards next rank
  const getNextRankXP = (currentXP: number) => {
    if (currentXP < 300) return { next: 300, prev: 0, title: 'Orbital Pilot' };
    if (currentXP < 800) return { next: 800, prev: 300, title: 'Mission Specialist' };
    if (currentXP < 1500) return { next: 1500, prev: 800, title: 'Solar Cartographer' };
    if (currentXP < 2500) return { next: 2500, prev: 1500, title: 'Chief Astrophysicist' };
    return { next: 5000, prev: 2500, title: 'Cosmic Legend' };
  };

  const rankData = getNextRankXP(xp);
  const rankProgress = Math.min(100, Math.max(0, ((xp - rankData.prev) / (rankData.next - rankData.prev)) * 100));

  return (
    <header className="sticky top-0 z-40 w-full bg-[#050814]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Brand Logo & Rank Pill */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 font-bold text-white text-base">
              ⚛
            </div>
            <div>
              <span className="font-heading font-extrabold tracking-tight text-white text-base">COSMOS<span className="text-cyan-400">LAB</span></span>
              <span className="hidden sm:inline-block ml-2 px-1.5 py-0.5 rounded text-[9px] font-mono uppercase bg-slate-800 text-slate-400 border border-slate-700">
                v1.0 PER
              </span>
            </div>
          </div>

          {/* XP & Rank Bar button */}
          <button
            onClick={toggleQuestDrawer}
            className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-colors cursor-pointer"
          >
            <div className="text-left font-mono">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-amber-400">{rank}</span>
                <span className="text-[10px] text-slate-400">({xp} XP)</span>
              </div>
              <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 to-cyan-400 transition-all duration-300"
                  style={{ width: `${rankProgress}%` }}
                />
              </div>
            </div>
            <Award className="w-4 h-4 text-amber-400" />
          </button>
        </div>

        {/* 5 Main Navigation Tabs */}
        <nav className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800 overflow-x-auto max-w-full">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 text-cyan-200 border border-cyan-400/50 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                <span className="hidden lg:inline text-[9px] font-mono text-slate-500 bg-slate-950 px-1 py-0.2 rounded border border-slate-800">
                  {tab.shortcut}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Grade Tier Selector & Utility Toggles */}
        <div className="flex items-center gap-2">
          {/* Grade Tier Pill Switcher */}
          <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            {tiers.map((t) => {
              const isSelected = gradeTier === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setGradeTier(t.id)}
                  title={t.desc}
                  className={`px-2 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  {t.label}
                </button>
              );
            })}
          </div>

          {/* Voice Captions Toggle */}
          <button
            onClick={toggleVoiceCaptions}
            title={voiceCaptions ? 'Voice Captions: ON' : 'Voice Captions: OFF'}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              voiceCaptions
                ? 'bg-indigo-500/20 border-indigo-400/40 text-indigo-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {voiceCaptions ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
          </button>

          {/* Sound Mute Toggle */}
          <button
            onClick={toggleMute}
            title={isMuted ? 'Audio Synthesizer: Muted' : 'Audio Synthesizer: Active'}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* Flight School Replay (?) Button */}
          <button
            onClick={() => setTutorialStep(1)}
            title="Launch Flight School Tutorial"
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/40 transition-colors cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};