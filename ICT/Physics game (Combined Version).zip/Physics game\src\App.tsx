﻿import React, { useEffect } from 'react';
import { useCosmosStore } from './store/useCosmosStore';
import { TopNavHUD } from './components/layout/TopNavHUD';
import { QuestDrawer } from './components/layout/QuestDrawer';
import { ErrorBoundary3D } from './components/layout/ErrorBoundary3D';
import { TutorialOverlay } from './components/tutorial/TutorialOverlay';
import { AcademyPage } from './pages/AcademyPage';
import { SimLabPage } from './pages/SimLabPage';
import { SolarObservatoryPage } from './pages/SolarObservatoryPage';
import { GravityMaterialsPage } from './pages/GravityMaterialsPage';
import { SpaceHubPage } from './pages/SpaceHubPage';
import { Sparkles, X } from 'lucide-react';

export const App: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    recentAlert,
    clearAlert,
    tutorialCompleted,
    tutorialCurrentStep,
    toggleMute
  } = useCosmosStore();

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === '1') {
        setActiveTab('academy');
      } else if (e.key === '2') {
        setActiveTab('simlab');
      } else if (e.key === '3') {
        setActiveTab('observatory');
      } else if (e.key === '4') {
        setActiveTab('materials');
      } else if (e.key === '5') {
        setActiveTab('space_hub');
      } else if (e.key.toLowerCase() === 'm') {
        toggleMute();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setActiveTab, toggleMute]);

  // Auto-dismiss alert after 4 seconds
  useEffect(() => {
    if (recentAlert) {
      const timer = setTimeout(() => {
        clearAlert();
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [recentAlert, clearAlert]);

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'academy':
        return <AcademyPage />;
      case 'simlab':
        return <SimLabPage />;
      case 'observatory':
        return <SolarObservatoryPage />;
      case 'materials':
        return <GravityMaterialsPage />;
      case 'space_hub':
        return <SpaceHubPage />;
      default:
        return <AcademyPage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#050814] text-[#F8FAFC] flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Flight School Tutorial Overlay */}
      {(!tutorialCompleted || tutorialCurrentStep < 5) && <TutorialOverlay />}

      {/* Top HUD */}
      <TopNavHUD />

      {/* Main Content Area */}
      <main className="flex-1 w-full pb-12">
        <ErrorBoundary3D>
          {renderActiveTab()}
        </ErrorBoundary3D>
      </main>

      {/* Quest Drawer Slide-Over */}
      <QuestDrawer />

      {/* Floating XP / Badge Alert Toast */}
      {recentAlert && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-3 p-4 rounded-2xl bg-slate-900/95 backdrop-blur-xl border border-amber-500/40 text-slate-100 shadow-2xl animate-in slide-in-from-bottom duration-300">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="font-heading font-bold text-xs text-white">{recentAlert.title}</div>
            <div className="text-[11px] text-slate-300 font-mono">{recentAlert.subtitle}</div>
          </div>
          <button
            onClick={clearAlert}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors ml-2"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full border-t border-slate-900 bg-slate-950/60 py-4 px-6 text-center text-xs text-slate-500 font-mono">
        COSMOS LAB • Physics Education Research (PER) Framework • Three.js WebGL2 Engine
      </footer>
    </div>
  );
};

export default App;