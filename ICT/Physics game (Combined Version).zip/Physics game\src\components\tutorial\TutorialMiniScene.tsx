import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { getProceduralTexture } from '../../utils/proceduralTextures';
import { AtmosphereShader } from '../../shaders/atmosphereShader';

interface TutorialMiniSceneProps {
  onOrbitDelta?: (deltaRad: number) => void;
  onZoomDelta?: (currentDist: number, initialDist: number) => void;
  onSelectMoon?: () => void;
  showVectors?: boolean;
  timeSpeed?: number;
}

export const TutorialMiniScene: React.FC<TutorialMiniSceneProps> = ({
  onOrbitDelta,
  onZoomDelta,
  onSelectMoon,
  showVectors = false,
  timeSpeed = 1.0,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const moonMeshRef = useRef<THREE.Mesh | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#050814');

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    const initialDist = 18;
    camera.position.set(0, 5, initialDist);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 6;
    controls.maxDistance = 45;

    let prevAzimuth = controls.getAzimuthalAngle();

    controls.addEventListener('change', () => {
      const currentAzimuth = controls.getAzimuthalAngle();
      const delta = Math.abs(currentAzimuth - prevAzimuth);
      prevAzimuth = currentAzimuth;
      if (onOrbitDelta && delta > 0.001) {
        onOrbitDelta(delta);
      }
      if (onZoomDelta) {
        const dist = camera.position.distanceTo(controls.target);
        onZoomDelta(dist, initialDist);
      }
    });

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.25);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffbe8, 2.5);
    sunLight.position.set(50, 10, 30);
    scene.add(sunLight);

    // Stars background
    const starsGeo = new THREE.BufferGeometry();
    const starCount = 1200;
    const starPositions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount * 3; i += 3) {
      starPositions[i] = (Math.random() - 0.5) * 400;
      starPositions[i + 1] = (Math.random() - 0.5) * 400;
      starPositions[i + 2] = (Math.random() - 0.5) * 400;
    }
    starsGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const starsMat = new THREE.PointsMaterial({ color: 0x94a3b8, size: 0.8 });
    const stars = new THREE.Points(starsGeo, starsMat);
    scene.add(stars);

    // Earth
    const earthGeo = new THREE.SphereGeometry(2.5, 48, 48);
    const earthTex = getProceduralTexture('earth');
    const earthMat = new THREE.MeshStandardMaterial({
      map: earthTex,
      roughness: 0.6,
      metalness: 0.1,
    });
    const earth = new THREE.Mesh(earthGeo, earthMat);
    scene.add(earth);

    // Earth Atmosphere Rim Glow
    const atmosMat = AtmosphereShader.createMaterial('#38BDF8', 0.8, 3.2);
    const atmosMesh = new THREE.Mesh(new THREE.SphereGeometry(2.7, 48, 48), atmosMat);
    scene.add(atmosMesh);

    // Moon
    const moonGeo = new THREE.SphereGeometry(0.7, 32, 32);
    const moonTex = getProceduralTexture('moon');
    const moonMat = new THREE.MeshStandardMaterial({
      map: moonTex,
      roughness: 0.8,
    });
    const moon = new THREE.Mesh(moonGeo, moonMat);
    moonMeshRef.current = moon;
    scene.add(moon);

    // Lunar Orbit Line
    const orbitRadius = 9.0;
    const orbitGeo = new THREE.BufferGeometry();
    const orbitPoints: THREE.Vector3[] = [];
    for (let i = 0; i <= 64; i++) {
      const angle = (i / 64) * Math.PI * 2;
      orbitPoints.push(new THREE.Vector3(Math.cos(angle) * orbitRadius, 0, Math.sin(angle) * orbitRadius));
    }
    orbitGeo.setFromPoints(orbitPoints);
    const orbitMat = new THREE.LineBasicMaterial({
      color: 0xa855f7,
      transparent: true,
      opacity: 0.45,
    });
    const orbitLine = new THREE.Line(orbitGeo, orbitMat);
    scene.add(orbitLine);

    // Vector Arrows (Velocity & Gravitational Force)
    const velocityArrow = new THREE.ArrowHelper(
      new THREE.Vector3(0, 0, 1),
      new THREE.Vector3(0, 0, 0),
      2.5,
      0x38bdf8,
      0.6,
      0.3
    );
    const forceArrow = new THREE.ArrowHelper(
      new THREE.Vector3(-1, 0, 0),
      new THREE.Vector3(0, 0, 0),
      2.2,
      0xf59e0b,
      0.6,
      0.3
    );
    velocityArrow.visible = showVectors;
    forceArrow.visible = showVectors;
    scene.add(velocityArrow);
    scene.add(forceArrow);

    // Raycaster for Moon inspection click
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handleClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects([moon, earth]);
      if (intersects.length > 0) {
        if (intersects[0].object === moon && onSelectMoon) {
          onSelectMoon();
        }
      }
    };

    renderer.domElement.addEventListener('click', handleClick);

    // Animation Loop
    let animId: number;
    let clock = new THREE.Clock();
    let moonAngle = 0;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const dt = clock.getDelta();

      // Rotate Earth
      earth.rotation.y += 0.2 * dt * timeSpeed;

      // Orbit Moon
      moonAngle += 0.4 * dt * timeSpeed;
      const mx = Math.cos(moonAngle) * orbitRadius;
      const mz = Math.sin(moonAngle) * orbitRadius;
      moon.position.set(mx, 0, mz);
      moon.rotation.y += 0.4 * dt * timeSpeed;

      // Update Vector Arrows
      velocityArrow.visible = showVectors;
      forceArrow.visible = showVectors;
      if (showVectors) {
        velocityArrow.position.set(mx, 0, mz);
        // Tangent vector
        const tangent = new THREE.Vector3(-Math.sin(moonAngle), 0, Math.cos(moonAngle)).normalize();
        velocityArrow.setDirection(tangent);

        forceArrow.position.set(mx, 0, mz);
        // Centripetal force towards Earth
        const toEarth = new THREE.Vector3(-mx, 0, -mz).normalize();
        forceArrow.setDirection(toEarth);
      }

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('click', handleClick);
      cancelAnimationFrame(animId);
      controls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [showVectors, timeSpeed]);

  return <div ref={containerRef} className="w-full h-full relative cursor-grab active:cursor-grabbing" />;
};
