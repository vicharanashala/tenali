export interface SimBody {
  id: string;
  name: string;
  mass: number;
  radius: number;
  color: string;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  ax: number;
  ay: number;
  az: number;
  trail: { x: number; y: number; z: number }[];
  isFixed?: boolean;
}

export interface EnergyTelemetry {
  kinetic: number;
  potential: number;
  total: number;
  initialTotal: number;
  driftPercent: number;
}

export class SymplecticNBodySystem {
  public bodies: SimBody[] = [];
  public G: number = 1.0; // Scaled Gravitational constant
  public softening: number = 0.05; // Epsilon softening
  public isGravityCut: boolean = false;
  private initialEnergy: number | null = null;

  constructor(G = 1.0, softening = 0.05) {
    this.G = G;
    this.softening = softening;
  }

  public setBodies(bodies: SimBody[]) {
    this.bodies = bodies.map(b => ({
      ...b,
      ax: 0,
      ay: 0,
      az: 0,
      trail: [{ x: b.x, y: b.y, z: b.z }]
    }));
    this.computeAccelerations();
    this.initialEnergy = this.computeEnergy().total;
  }

  public cutGravity(cut: boolean) {
    this.isGravityCut = cut;
  }

  // Compute accelerations for all bodies
  public computeAccelerations() {
    const N = this.bodies.length;
    // Reset accelerations
    for (let i = 0; i < N; i++) {
      this.bodies[i].ax = 0;
      this.bodies[i].ay = 0;
      this.bodies[i].az = 0;
    }

    if (this.isGravityCut || this.G === 0) {
      return;
    }

    const eps2 = this.softening * this.softening;

    for (let i = 0; i < N; i++) {
      const b1 = this.bodies[i];
      if (b1.isFixed) continue;

      for (let j = 0; j < N; j++) {
        if (i === j) continue;
        const b2 = this.bodies[j];

        const dx = b2.x - b1.x;
        const dy = b2.y - b1.y;
        const dz = b2.z - b1.z;

        const distSq = dx * dx + dy * dy + dz * dz + eps2;
        const dist = Math.sqrt(distSq);
        const invDist3 = 1 / (distSq * dist);

        const factor = this.G * b2.mass * invDist3;
        b1.ax += dx * factor;
        b1.ay += dy * factor;
        b1.az += dz * factor;
      }
    }
  }

  // Symplectic Velocity-Verlet step
  public step(dt: number, substeps = 8, maxTrailLength = 200) {
    const subDt = dt / substeps;

    for (let s = 0; s < substeps; s++) {
      const N = this.bodies.length;

      // Half-step velocity & full-step position
      for (let i = 0; i < N; i++) {
        const b = this.bodies[i];
        if (b.isFixed) continue;

        b.vx += 0.5 * b.ax * subDt;
        b.vy += 0.5 * b.ay * subDt;
        b.vz += 0.5 * b.az * subDt;

        b.x += b.vx * subDt;
        b.y += b.vy * subDt;
        b.z += b.vz * subDt;
      }

      // Recompute accelerations at new positions
      this.computeAccelerations();

      // Second half-step velocity
      for (let i = 0; i < N; i++) {
        const b = this.bodies[i];
        if (b.isFixed) continue;

        b.vx += 0.5 * b.ax * subDt;
        b.vy += 0.5 * b.ay * subDt;
        b.vz += 0.5 * b.az * subDt;
      }
    }

    // Update trails
    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      b.trail.push({ x: b.x, y: b.y, z: b.z });
      if (b.trail.length > maxTrailLength) {
        b.trail.shift();
      }
    }
  }

  // Compute Mechanical Energy
  public computeEnergy(): EnergyTelemetry {
    let kinetic = 0;
    let potential = 0;
    const N = this.bodies.length;
    const eps2 = this.softening * this.softening;

    for (let i = 0; i < N; i++) {
      const b1 = this.bodies[i];
      const vSq = b1.vx * b1.vx + b1.vy * b1.vy + b1.vz * b1.vz;
      kinetic += 0.5 * b1.mass * vSq;

      if (!this.isGravityCut && this.G > 0) {
        for (let j = i + 1; j < N; j++) {
          const b2 = this.bodies[j];
          const dx = b2.x - b1.x;
          const dy = b2.y - b1.y;
          const dz = b2.z - b1.z;
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz + eps2);
          potential -= (this.G * b1.mass * b2.mass) / dist;
        }
      }
    }

    const total = kinetic + potential;
    if (this.initialEnergy === null && total !== 0) {
      this.initialEnergy = total;
    }

    const init = this.initialEnergy ?? total;
    const driftPercent = init !== 0 ? Math.abs((total - init) / init) * 100 : 0;

    return {
      kinetic,
      potential,
      total,
      initialTotal: init,
      driftPercent
    };
  }
}
