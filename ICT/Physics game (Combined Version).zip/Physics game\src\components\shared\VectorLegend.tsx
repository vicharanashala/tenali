import React from 'react';

export const VectorLegend: React.FC = () => {
  const items = [
    { label: 'Velocity (v)', color: '#38BDF8', icon: '→' },
    { label: 'Gravity Force (Fg)', color: '#F59E0B', icon: '➔' },
    { label: 'Orbital Path', color: '#A855F7', icon: '⋯' },
    { label: 'Kinetic (K)', color: '#10B981', icon: '■' },
    { label: 'Potential (U)', color: '#F43F5E', icon: '■' },
    { label: 'Umbra Shadow', color: '#6366F1', icon: '▲' }
  ];

  return (
    <div className="flex flex-wrap items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px] font-mono select-none">
      <span className="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">Global Key:</span>
      {items.map((item) => (
        <div key={item.label} className="flex items-center gap-1.5">
          <span style={{ color: item.color }} className="font-bold text-xs">{item.icon}</span>
          <span className="text-slate-300">{item.label}</span>
        </div>
      ))}
    </div>
  );
};
