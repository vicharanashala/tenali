import { PlanetLayer } from '../types/physics';

export interface PlanetCutawayData {
  id: string;
  name: string;
  coreType: string;
  magneticFieldDesc: Record<string, string>;
  meanDensityGcm3: number;
  layers: PlanetLayer[];
}

export const PLANETARY_MATERIALS: Record<string, PlanetCutawayData> = {
  earth: {
    id: 'earth',
    name: 'Earth',
    coreType: 'Liquid Outer + Solid Inner Iron-Nickel Dynamo',
    meanDensityGcm3: 5.515,
    magneticFieldDesc: {
      '6-8': 'A giant invisible magnetic shield protects our atmosphere and life from lethal solar radiation.',
      '9-10': 'Convection in the liquid iron outer core creates an electrical dynamo, generating Earth’s dipole magnetic field.',
      '11-12': 'The Coriolis force organizes outer core liquid Fe-Ni convection into helical columns, sustaining the geodynamo (30–60 µT).'
    },
    layers: [
      {
        name: 'Crust (Oceanic & Continental)',
        depthRangeKm: '0 – 35 km',
        state: 'Solid brittle rock',
        composition: 'Silicates, granite, basalt (SiO₂, Al₂O₃)',
        density: '2.7 – 3.0 g/cm³',
        temperature: '0 – 500 °C',
        pressure: '0.1 – 1 GPa',
        color: '#3B82F6',
        thicknessFraction: 0.12,
        keyFact: {
          '6-8': 'The thin brittle rocky skin where all mountains, oceans, and life exist.',
          '9-10': 'Broken into tectonic plates floating upon the semi-ductile asthenosphere.',
          '11-12': 'Average continental crust density 2.7 g/cm³; oceanic basalt crust density 3.0 g/cm³.'
        }
      },
      {
        name: 'Mantle (Upper & Lower)',
        depthRangeKm: '35 – 2,890 km',
        state: 'Solid plastic viscoelastic rock',
        composition: 'Bridgmanite, olivine, pyroxene ((Mg,Fe)₂SiO₄)',
        density: '3.4 – 5.6 g/cm³',
        temperature: '500 – 4,000 °C',
        pressure: '1 – 136 GPa',
        color: '#D97706',
        thicknessFraction: 0.40,
        keyFact: {
          '6-8': 'A thick layer of superheated rock that flows slowly like hot asphalt over millions of years.',
          '9-10': 'Thermal convection currents in the mantle drive continental drift and volcanic activity.',
          '11-12': 'Undergoes phase transitions at 410 km and 660 km discontinuities from olivine to ringwoodite to bridgmanite.'
        }
      },
      {
        name: 'Outer Core',
        depthRangeKm: '2,890 – 5,150 km',
        state: 'Liquid molten metal',
        composition: '85% Iron, 5% Nickel, 10% light elements (S, O, Si)',
        density: '9.9 – 12.2 g/cm³',
        temperature: '4,000 – 5,000 °C',
        pressure: '136 – 330 GPa',
        color: '#EF4444',
        thicknessFraction: 0.28,
        keyFact: {
          '6-8': 'A churning sea of molten liquid iron hotter than the surface of the Sun!',
          '9-10': 'The circulation of liquid metal here generates our planetary magnetic field.',
          '11-12': 'Liquid state verified by the complete shadow zone cutoff of seismic shear (S) waves.'
        }
      },
      {
        name: 'Inner Core',
        depthRangeKm: '5,150 – 6,371 km',
        state: 'Solid crystalline metallic',
        composition: 'Solid crystallized Iron-Nickel alloy (Fe-Ni)',
        density: '12.8 – 13.1 g/cm³',
        temperature: '5,400 – 6,000 °C',
        pressure: '330 – 364 GPa',
        color: '#FACC15',
        thicknessFraction: 0.20,
        keyFact: {
          '6-8': 'A solid metal ball at the center of Earth, kept solid despite immense heat by crushing gravity.',
          '9-10': 'Crushing pressure (3.3 million atmospheres) raises the melting point above 5,400 °C.',
          '11-12': 'Hexagonal close-packed (hcp) iron lattice exhibiting seismic anisotropy along Earth’s spin axis.'
        }
      }
    ]
  },
  jupiter: {
    id: 'jupiter',
    name: 'Jupiter',
    coreType: 'Liquid Metallic Hydrogen Dynamo + Dilute Core',
    meanDensityGcm3: 1.326,
    magneticFieldDesc: {
      '6-8': 'Jupiter has a colossal magnetic field 20,000 times stronger than Earth’s, radiating intense radiation belts.',
      '9-10': 'Vast swirling layers of metallic hydrogen conduct electricity under crushing pressure, powering a super-dynamo.',
      '11-12': 'Liquid metallic hydrogen acts as a degenerate Fermi liquid with electrical conductivity comparable to liquid copper.'
    },
    layers: [
      {
        name: 'Molecular Atmosphere & Gas Envelope',
        depthRangeKm: '0 – 3,000 km',
        state: 'Gaseous / Supercritical fluid',
        composition: '90% H₂, 10% He, trace NH₃, CH₄, H₂O',
        density: '0.1 – 0.5 g/cm³',
        temperature: '-110 – 2,000 °C',
        pressure: '0.1 – 100 GPa',
        color: '#F97316',
        thicknessFraction: 0.25,
        keyFact: {
          '6-8': 'Swirling ammonia clouds, jet streams, and storm belts with no solid ground anywhere.',
          '9-10': 'Gradually transitions smoothly from gas to dense supercritical liquid with no sharp surface.',
          '11-12': 'Displays zonal counter-rotating winds reaching 150 m/s driven by deep internal thermal upwelling.'
        }
      },
      {
        name: 'Liquid Molecular Hydrogen',
        depthRangeKm: '3,000 – 15,000 km',
        state: 'Supercritical liquid',
        composition: 'Dense fluid H₂ and Helium droplets',
        density: '0.5 – 1.8 g/cm³',
        temperature: '2,000 – 10,000 °C',
        pressure: '100 – 200 GPa',
        color: '#EA580C',
        thicknessFraction: 0.30,
        keyFact: {
          '6-8': 'Hydrogen gas compressed into a dense boiling liquid ocean thousands of kilometers deep.',
          '9-10': 'Helium rain separates from hydrogen and sinks deeper into the planet releasing gravitational energy.',
          '11-12': 'Characterized by immiscibility of helium in dense hydrogen under megabar pressures.'
        }
      },
      {
        name: 'Liquid Metallic Hydrogen',
        depthRangeKm: '15,000 – 58,000 km',
        state: 'Degenerate metallic liquid',
        composition: 'Ionized protons and free delocalized electron sea (H⁺ + e⁻)',
        density: '1.8 – 4.5 g/cm³',
        temperature: '10,000 – 20,000 °C',
        pressure: '200 – 3,500 GPa',
        color: '#EAB308',
        thicknessFraction: 0.30,
        keyFact: {
          '6-8': 'Hydrogen squeezed so hard that electrons break free and it turns into a shiny liquid metal!',
          '9-10': 'Acts like liquid mercury; rapid planetary rotation (9.9 hrs) turns it into a colossal magnetic powerhouse.',
          '11-12': 'Dissociative metal-insulator transition occurring around 140–200 GPa and 4,000 K.'
        }
      },
      {
        name: 'Dilute Heavy-Element Core',
        depthRangeKm: '58,000 – 69,911 km',
        state: 'Dissolved fuzzy rock-ice slurry',
        composition: 'Silicates, iron oxides, dissolved into metallic hydrogen',
        density: '10 – 25 g/cm³',
        temperature: '20,000 – 30,000 °C',
        pressure: '3,500 – 4,500 GPa',
        color: '#A855F7',
        thicknessFraction: 0.15,
        keyFact: {
          '6-8': 'A fuzzy core 10 to 30 times heavier than all of Earth, partially dissolved into the liquid metal above.',
          '9-10': 'Juno spacecraft gravity measurements revealed the core is not a compact rock, but a "dilute" fuzzy zone.',
          '11-12': 'Low higher-order gravitational harmonics (J₄, J₆, J₈) indicate core erosion by convective hydrogen mixing.'
        }
      }
    ]
  },
  mars: {
    id: 'mars',
    name: 'Mars',
    coreType: 'Partially Molten Sulfur-Rich Core (Extinct Dynamo)',
    meanDensityGcm3: 3.933,
    magneticFieldDesc: {
      '6-8': 'Mars lost its global magnetic shield billions of years ago, allowing the solar wind to strip away its atmosphere.',
      '9-10': 'Its small core cooled rapidly, shutting off the internal dynamo and leaving only magnetized crustal rocks.',
      '11-12': 'InSight SEIS seismic data confirms a large liquid iron-nickel-sulfur core (radius ~1,830 km) with no active convective dynamo.'
    },
    layers: [
      {
        name: 'Crust',
        depthRangeKm: '0 – 50 km',
        state: 'Solid basaltic rock & regolith',
        composition: 'Basalt, iron oxide dust (rust), plagioclase',
        density: '2.9 – 3.2 g/cm³',
        temperature: '-60 – 100 °C',
        pressure: '0.01 – 1 GPa',
        color: '#DC2626',
        thicknessFraction: 0.18,
        keyFact: {
          '6-8': 'Rich in red rust dust (iron oxide), with giant extinct volcanoes like Olympus Mons.',
          '9-10': 'Thicker than Earth’s crust; unsegmented by plate tectonics, allowing hot spots to build monster volcanoes.',
          '11-12': 'Crustal dichotomy: thin northern lowlands (32 km) vs thick southern cratered highlands (58 km).'
        }
      },
      {
        name: 'Silicate Mantle',
        depthRangeKm: '50 – 1,560 km',
        state: 'Solid rock (stagnant lid)',
        composition: 'Olivine, garnet, pyroxene enriched in iron',
        density: '3.4 – 4.4 g/cm³',
        temperature: '100 – 1,500 °C',
        pressure: '1 – 18 GPa',
        color: '#B45309',
        thicknessFraction: 0.45,
        keyFact: {
          '6-8': 'Cool and sluggish rocky mantle that stopped vigorous churning eons ago.',
          '9-10': 'Twice as rich in iron (FeO) as Earth’s mantle, explaining Mars’s lower bulk density.',
          '11-12': 'Operates in a "stagnant-lid" convective regime without plate subduction.'
        }
      },
      {
        name: 'Liquid Core',
        depthRangeKm: '1,560 – 3,390 km',
        state: 'Liquid iron-sulfur alloy',
        composition: 'Iron, nickel, and up to 15–20% light sulfur (Fe-Ni-S)',
        density: '6.0 – 7.2 g/cm³',
        temperature: '1,500 – 2,000 °C',
        pressure: '18 – 40 GPa',
        color: '#F59E0B',
        thicknessFraction: 0.37,
        keyFact: {
          '6-8': 'A liquid metal core kept liquid by high sulfur content, but too sluggish to make a magnetic shield.',
          '9-10': 'High sulfur lowers the freezing temperature, preventing the formation of a solid inner core.',
          '11-12': 'Radius measured at 1,830 ± 40 km by InSight seismic reflections (SKS phases).'
        }
      }
    ]
  }
};
