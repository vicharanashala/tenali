import { Chapter } from '../types/curriculum';

export const CURRICULUM_CHAPTERS: Chapter[] = [
  {
    id: 'ch1',
    number: 1,
    title: 'Gravity: The Invisible Glue',
    subtitle: 'Newton’s Cannon & Orbital Insertion',
    badgeId: 'newtons_heir',
    deepLinkTab: 'simlab',
    deepLinkPreset: 'sun_earth',
    cards: [
      {
        id: 'ch1_c1',
        title: 'Falling Forever',
        subtitle: 'The Thought Experiment That Unlocked the Cosmos',
        widgetType: 'newton-cannon',
        explanation: {
          '6-8': 'Imagine shooting a cannonball off a mountain. Fire it gently, and it hits the ground. Fire it fast enough, and Earth curves away beneath it just as fast as it falls!',
          '9-10': 'An orbit is continuous free fall. The satellite falls toward Earth’s center due to gravity, but its forward speed matches Earth’s spherical curvature.',
          '11-12': 'For a circular orbit of radius r, centripetal acceleration matches gravitational acceleration: v²/r = GM/r², yielding the first cosmic velocity v_c = √(GM/r).'
        },
        formula: {
          latex: 'v_{\\text{orbit}} = \\sqrt{\\frac{G M}{r}}',
          bindings: [
            { symbol: 'v_{\\text{orbit}}', name: 'Orbital Speed', unit: 'm/s', color: '#38BDF8', meaning: { '6-8': 'Speed needed to stay in space without falling.', '9-10': 'Horizontal speed balancing gravity.', '11-12': 'Circular Keplerian velocity vector.' } },
            { symbol: 'G', name: 'Gravitational Constant', unit: 'N·m²/kg²', color: '#F59E0B', meaning: { '6-8': 'The strength of gravity in our universe.', '9-10': 'Universal constant 6.674×10⁻¹¹.', '11-12': 'Newtonian gravitational constant.' } },
            { symbol: 'M', name: 'Planet Mass', unit: 'kg', color: '#A855F7', meaning: { '6-8': 'How heavy Earth is.', '9-10': 'Central celestial body mass.', '11-12': 'Source mass generating potential well.' } },
            { symbol: 'r', name: 'Orbital Radius', unit: 'm', color: '#10B981', meaning: { '6-8': 'Distance from Earth center to satellite.', '9-10': 'Distance from center of mass.', '11-12': 'Geocentric radial coordinate vector.' } }
          ]
        },
        poeCheckpoint: {
          id: 'poe_ch1',
          question: 'What happens if you fire the cannonball at exactly 7.9 km/s from Earth surface (ignoring atmosphere)?',
          options: [
            {
              id: 'opt1',
              text: 'It crashes into the ocean on the other side of Earth.',
              explanation: {
                '6-8': '7.9 km/s is fast enough to clear the ground entirely!',
                '9-10': 'At this velocity, curvature rate equals free-fall rate.',
                '11-12': '7.9 km/s satisfies v = √(GM/R_earth) for circular LEO.'
              }
            },
            {
              id: 'opt2',
              text: 'It enters a stable circular orbit around Earth.',
              isCorrect: true,
              explanation: {
                '6-8': 'Spot on! It falls continuously around Earth without ever touching the ground.',
                '9-10': 'Correct! Centripetal acceleration exactly balances gravitational acceleration.',
                '11-12': 'Exactly. At 7.9 km/s, orbital eccentricity e = 0.'
              }
            },
            {
              id: 'opt3',
              text: 'It escapes Earth forever into deep interplanetary space.',
              explanation: {
                '6-8': 'To escape completely, you need escape velocity (11.2 km/s)!',
                '9-10': 'Escape requires kinetic energy >= gravitational binding energy (√2 times faster).',
                '11-12': 'Escape velocity v_e = √(2) * v_c ≈ 11.19 km/s.'
              }
            }
          ],
          observeInstruction: 'Adjust the launch speed slider to 7.9 km/s and observe the circular trajectory.',
          explanation: {
            '6-8': 'At 7.9 km/s, Earth drops by 5 meters every 8 kilometers—exactly matching the distance gravity pulls an object down in 1 second!',
            '9-10': 'Centripetal force F_c = mv²/r matches gravitational force F_g = GMm/r², resulting in a closed circular orbit.',
            '11-12': 'Specific orbital mechanical energy ε = -GM/(2a). At 7.9 km/s at R_earth, ε is negative and eccentricity e = 0.'
          }
        }
      }
    ]
  },
  {
    id: 'ch2',
    number: 2,
    title: 'Inverse-Square Law & Weight vs. Mass',
    subtitle: 'The Geometry of Gravitational Fields',
    badgeId: 'core_geologist',
    deepLinkTab: 'materials',
    cards: [
      {
        id: 'ch2_c1',
        title: 'Dilution Over Distance',
        subtitle: 'Why Gravity Weakens Rapidly in 3D Space',
        widgetType: 'inverse-square',
        explanation: {
          '6-8': 'Think of butter spread across bread, or a flashlight beam. As you move twice as far away, the light covers 4 times the area, so it is 4 times dimmer!',
          '9-10': 'Gravity radiates spherically into 3D space. The surface area of a sphere is 4πr². When distance doubles, force drops to 1/4 (2²). When distance triples, force drops to 1/9 (3²).',
          '11-12': 'Gauss’s Law for gravity: ∮ g · dA = -4πGM. The inverse-square dependency F ∝ 1/r² is a direct consequence of 3D Euclidean spatial geometry.'
        },
        formula: {
          latex: 'F_g = G \\frac{m_1 m_2}{r^2}',
          bindings: [
            { symbol: 'F_g', name: 'Gravitational Force', unit: 'N', color: '#F59E0B', meaning: { '6-8': 'The pull between two objects.', '9-10': 'Attraction between two masses.', '11-12': 'Magnitude of Newtonian gravitational force vector.' } },
            { symbol: 'm_1, m_2', name: 'Interacting Masses', unit: 'kg', color: '#A855F7', meaning: { '6-8': 'The masses of the two objects.', '9-10': 'Mass values of both bodies.', '11-12': 'Gravitational charge / inertial mass.' } },
            { symbol: 'r', name: 'Center-to-Center Distance', unit: 'm', color: '#10B981', meaning: { '6-8': 'Distance between their centers.', '9-10': 'Separation between centers of mass.', '11-12': 'Norm of position separation vector |r₂ - r₁|.' } }
          ]
        },
        poeCheckpoint: {
          id: 'poe_ch2',
          question: 'If you move 3 times farther from Earth’s center, how does your weight change?',
          options: [
            { id: 'opt1', text: 'It drops to 1/3 of your original weight.', explanation: { '6-8': 'Gravity does not drop linearly; it spreads across a 2D surface!', '9-10': 'Remember the square in the denominator: 3² = 9.', '11-12': 'Force is inversely proportional to r², not r.' } },
            { id: 'opt2', text: 'It drops to 1/9 of your original weight.', isCorrect: true, explanation: { '6-8': 'Correct! 3 times distance means 3 × 3 = 9 times weaker pull.', '9-10': 'Exactly! F ∝ 1/r², so F ∝ 1/3² = 1/9.', '11-12': 'Precise. The field flux spreads over an area 9 times larger.' } },
            { id: 'opt3', text: 'It remains identical because your mass didn’t change.', explanation: { '6-8': 'Your mass stays the same, but weight is the force pulling on you!', '9-10': 'Mass is intrinsic; weight W = mg depends on local g.', '11-12': 'Invariant mass m is conserved, but local gravitational acceleration g drops as 1/r².' } }
          ],
          observeInstruction: 'Drag the target screen from 1r to 3r and watch the force gauge drop from 1.00 to 0.11.',
          explanation: {
            '6-8': 'Your mass (the atoms in your body) never changes, but your weight is the pull of gravity, which drops 9 times weaker at 3r!',
            '9-10': 'W = m · g(r), where g(r) = GM/r². Tripling r divides g by 3² = 9, so weight becomes W/9.',
            '11-12': 'The divergence of the field in empty space is zero (∇ · g = 0), dictating an inverse-square flux conservation across spherical shells.'
          }
        }
      }
    ]
  },
  {
    id: 'ch3',
    number: 3,
    title: 'Orbits & Kepler’s Three Laws',
    subtitle: 'Ellipses, Equal Areas & Harmonic Harmony',
    badgeId: 'keplers_apprentice',
    deepLinkTab: 'simlab',
    deepLinkPreset: 'comet',
    cards: [
      {
        id: 'ch3_c1',
        title: 'Kepler’s Breakthrough',
        subtitle: 'From Perfect Circles to Elegant Ellipses',
        widgetType: 'kepler',
        explanation: {
          '6-8': 'Planets do not orbit in perfect circles! They travel along slightly stretched ovals called ellipses. The Sun sits off-center at one focal point.',
          '9-10': 'Kepler’s 1st Law: Orbits are ellipses with the Sun at one focus. 2nd Law: A line connecting the planet and Sun sweeps out equal areas in equal times.',
          '11-12': 'Conservation of orbital angular momentum L = r × p = constant dictates that r · v_perp is conserved, forcing planets to accelerate at perihelion.'
        },
        formula: {
          latex: 'T^2 = \\frac{4\\pi^2}{G M} a^3',
          bindings: [
            { symbol: 'T', name: 'Orbital Period', unit: 'seconds or years', color: '#38BDF8', meaning: { '6-8': 'Time taken to make one full loop around the Sun.', '9-10': 'Time period of orbit.', '11-12': 'Keplerian orbital period.' } },
            { symbol: 'a', name: 'Semi-Major Axis', unit: 'm or AU', color: '#10B981', meaning: { '6-8': 'Average distance from the Sun.', '9-10': 'Half the longest diameter of the ellipse.', '11-12': 'Semi-major axis of conic section.' } }
          ]
        },
        poeCheckpoint: {
          id: 'poe_ch3',
          question: 'Where in its elliptical orbit does a comet travel fastest?',
          options: [
            { id: 'opt1', text: 'At aphelion (farthest point from the Sun).', explanation: { '6-8': 'At the farthest point, gravity’s pull has slowed the comet down.', '9-10': 'At aphelion, gravitational potential energy is maximum, kinetic energy is minimum.', '11-12': 'r is maximized, so orbital speed v is at its absolute minimum.' } },
            { id: 'opt2', text: 'At perihelion (closest point to the Sun).', isCorrect: true, explanation: { '6-8': 'Correct! The comet whips around the Sun at blazing speed!', '9-10': 'Exactly! Gravitational potential energy converts to kinetic energy.', '11-12': 'Correct. Equal area in equal time requires higher speed when r is smallest.' } },
            { id: 'opt3', text: 'Its speed is constant everywhere along the orbit.', explanation: { '6-8': 'Speed is only constant in a perfect circle, not an ellipse!', '9-10': 'Only circular orbits (e = 0) maintain constant tangential speed.', '11-12': 'In an eccentric orbit, the gravitational force has a component along the velocity vector.' } }
          ],
          observeInstruction: 'Adjust the eccentricity slider to 0.72 and observe the comet speeding up as it swings past the Sun.',
          explanation: {
            '6-8': 'Falling toward the Sun speeds the planet up; climbing away slows it down, just like a cosmic roller coaster!',
            '9-10': 'Mechanical energy E = K + U is conserved. As distance r decreases, potential energy U = -GMm/r becomes more negative, so kinetic energy K must increase.',
            '11-12': 'By the vis-viva equation v² = GM(2/r - 1/a), when r reaches minimum periapsis r_p = a(1 - e), velocity reaches its global maximum.'
          }
        }
      }
    ]
  },
  {
    id: 'ch4',
    number: 4,
    title: 'Moon Phases & Eclipses',
    subtitle: 'Geometry of Shadows & The 5.145° Orbital Tilt',
    badgeId: 'umbra_hunter',
    deepLinkTab: 'observatory',
    cards: [
      {
        id: 'ch4_c1',
        title: 'The Tilted Path',
        subtitle: 'Why Eclipses Don’t Happen Every Single Month',
        widgetType: 'orbital-tilt',
        explanation: {
          '6-8': 'The Moon circles Earth every 29.5 days, but its orbit is tilted by 5 degrees! Most months, its shadow misses Earth entirely, passing above or below.',
          '9-10': 'Eclipses can only occur when the New or Full Moon lines up with the "nodes"—the two points where the Moon’s tilted orbit intersects Earth’s orbital plane.',
          '11-12': 'The lunar orbital plane is inclined at 5.145° to the ecliptic. Eclipse seasons occur roughly every 173.3 days when the nodal line points toward the Sun.'
        },
        formula: {
          latex: 'L_{\\text{umbra}} = \\frac{R_{\\text{Moon}} \\cdot d}{R_{\\text{Sun}} - R_{\\text{Moon}}}',
          bindings: [
            { symbol: 'L_{\\text{umbra}}', name: 'Length of Umbra Shadow Cone', unit: 'km', color: '#6366F1', meaning: { '6-8': 'How far the darkest shadow reaches.', '9-10': 'Apex distance of the total shadow cone.', '11-12': 'Analytical umbral vertex distance.' } }
          ]
        },
        poeCheckpoint: {
          id: 'poe_ch4',
          question: 'If the Moon’s orbit had zero tilt (0° flat in Earth’s orbital plane), how often would we see solar eclipses?',
          options: [
            { id: 'opt1', text: 'Never.', explanation: { '6-8': 'If it was flat, it would block the Sun every single month!', '9-10': 'A coplanar orbit guarantees alignment at every New Moon.', '11-12': 'Nodal alignment would be continuous.' } },
            { id: 'opt2', text: 'Once every single month (at every New Moon).', isCorrect: true, explanation: { '6-8': 'Bingo! Every New Moon would pass directly in front of the Sun.', '9-10': 'Correct! Without the 5.145° tilt, the shadow would hit Earth every 29.5 days.', '11-12': 'Exactly. Eclipse geometry would be strictly periodic with the synodic month.' } },
            { id: 'opt3', text: 'Once every year.', explanation: { '6-8': 'The Moon circles Earth every month, not once a year!', '9-10': 'Earth takes a year to orbit the Sun, but the Moon circles Earth every month.', '11-12': 'The Moon passes between Sun and Earth once every synodic period (29.53 d).' } }
          ],
          observeInstruction: 'Toggle the tilt from 5.145° to 0° in the widget to see the shadow hit Earth on every orbit pass.',
          explanation: {
            '6-8': 'Because the Moon’s orbit is tilted, its shadow usually misses Earth. Only when the tilt aligns with the Sun do we get total eclipses!',
            '9-10': 'Eclipses require two simultaneous conditions: syzygy (Sun-Earth-Moon collinearity) AND nodal crossing (Moon at or near the orbital node).',
            '11-12': 'The ecliptic latitude β of the Moon must be less than the combined apparent angular radii of Sun and Moon for an eclipse to occur.'
          }
        }
      }
    ]
  },
  {
    id: 'ch5',
    number: 5,
    title: 'Inside Worlds: Planetary Materials & Structure',
    subtitle: 'Density, Differentiation & Magnetic Dynamos',
    badgeId: 'core_geologist',
    deepLinkTab: 'materials',
    cards: [
      {
        id: 'ch5_c1',
        title: 'Planetary Density & Sorting',
        subtitle: 'Why Heavy Metals Sink to the Core',
        widgetType: 'density-compare',
        explanation: {
          '6-8': 'When young planets were molten magma balls, heavy metals like iron sank to the center to form cores, while lighter rocky froth floated to the surface!',
          '9-10': 'Planetary differentiation: denser materials sink, converting gravitational potential energy into heat. That’s why Earth’s core is dense iron (13 g/cm³) while crust is only 2.7 g/cm³.',
          '11-12': 'Hydrostatic equilibrium dP/dr = -ρ(r)g(r) coupled with the Birch-Murnaghan equation of state describes planetary interior pressure and density gradients.'
        },
        formula: {
          latex: '\\rho_{\\text{mean}} = \\frac{M}{\\frac{4}{3}\\pi R^3}',
          bindings: [
            { symbol: '\\rho', name: 'Mean Density', unit: 'g/cm³ or kg/m³', color: '#F59E0B', meaning: { '6-8': 'How tightly packed the planet’s matter is.', '9-10': 'Average mass per unit volume.', '11-12': 'Volumetric bulk density.' } }
          ]
        },
        poeCheckpoint: {
          id: 'poe_ch5',
          question: 'Saturn has a mass of 95 Earths, but its mean density is only 0.687 g/cm³. What would happen if placed in a colossal bathtub of water (density 1.0 g/cm³)?',
          options: [
            { id: 'opt1', text: 'It would sink to the bottom immediately because of its huge mass.', explanation: { '6-8': 'Mass doesn’t determine floating; density does!', '9-10': 'Archimedes’ principle depends on relative density, not total mass.', '11-12': 'Buoyant force F_b = ρ_fluid · V · g exceeds gravitational force.' } },
            { id: 'opt2', text: 'It would float on the water.', isCorrect: true, explanation: { '6-8': 'Yes! Because its average density is less than water, it would float!', '9-10': 'Spot on! Any object with density < 1.0 g/cm³ floats in liquid water.', '11-12': 'Correct. Since ρ_Saturn (0.687 g/cm³) < ρ_water (1.000 g/cm³), net buoyancy is positive.' } },
            { id: 'opt3', text: 'It would explode due to water pressure.', explanation: { '6-8': 'This is a physics thought experiment about density!', '9-10': 'Focus on Archimedes’ principle of flotation.', '11-12': 'Ignoring hydrodynamic disruption, buoyancy dictates equilibrium.' } }
          ],
          observeInstruction: 'Select Saturn and Water in the density comparison bar to inspect their relative values.',
          explanation: {
            '6-8': 'Saturn is made mostly of hydrogen and helium gas. Even though it is huge, its atoms are spaced far apart, making it less dense than water!',
            '9-10': 'Massive gas giants have low mean densities because hydrogen gas has very low atomic mass compared to the iron and silicates of rocky planets.',
            '11-12': 'Saturn’s low mean density (0.687 g/cm³) reflects a 96% H₂/He molecular composition with only a relatively small ~15–20 M_earth heavy element core.'
          }
        }
      }
    ]
  },
  {
    id: 'ch6',
    number: 6,
    title: 'Rockets, Satellites & Escape Velocity',
    subtitle: 'Reaching Orbit & Hohmann Interplanetary Transfers',
    badgeId: 'hohmann_master',
    deepLinkTab: 'materials',
    cards: [
      {
        id: 'ch6_c1',
        title: 'Breaking Free',
        subtitle: 'The Energy Barrier to the Stars',
        widgetType: 'escape-velocity',
        explanation: {
          '6-8': 'To break completely free from a planet’s gravitational grip, a rocket must reach "escape speed". For Earth, that’s 11.2 kilometers every single second!',
          '9-10': 'Escape velocity occurs when kinetic energy exactly equals gravitational binding energy: ½mv² = GMm/R, giving v_escape = √(2GM/R) = √2 · v_circular.',
          '11-12': 'At escape velocity, specific orbital energy ε = 0. Trajectory transitions from a closed bound ellipse (ε < 0, e < 1) to an open parabolic escape path (ε = 0, e = 1).'
        },
        formula: {
          latex: 'v_{\\text{escape}} = \\sqrt{\\frac{2 G M}{R}}',
          bindings: [
            { symbol: 'v_{\\text{escape}}', name: 'Escape Velocity', unit: 'm/s or km/s', color: '#10B981', meaning: { '6-8': 'Speed needed to never fall back.', '9-10': 'Speed to escape gravity well.', '11-12': 'Parabolic escape velocity.' } }
          ]
        },
        poeCheckpoint: {
          id: 'poe_ch6',
          question: 'How does the escape velocity from the Moon (radius 1,737 km, mass 7.3×10²² kg) compare to Earth (radius 6,371 km, mass 5.97×10²⁴ kg)?',
          options: [
            { id: 'opt1', text: 'Moon escape speed is higher because it has no atmosphere.', explanation: { '6-8': 'Atmosphere causes drag, but gravity depends on mass and radius!', '9-10': 'Atmospheric density does not enter the gravitational potential equation.', '11-12': 'Escape velocity is purely a function of gravitational potential: √(2GM/R).' } },
            { id: 'opt2', text: 'Moon escape speed is much lower (~2.38 km/s vs 11.2 km/s).', isCorrect: true, explanation: { '6-8': 'Correct! The Moon is much less massive, so its gravitational grip is far weaker.', '9-10': 'Exactly! Because the Moon has ~1% of Earth’s mass, escape speed is only 2.38 km/s.', '11-12': 'Precise. v_e(Moon) = 2.38 km/s, allowing Apollo lunar modules to take off with tiny fuel tanks.' } },
            { id: 'opt3', text: 'Both have the exact same escape speed.', explanation: { '6-8': 'Heavier worlds require much higher speeds to escape!', '9-10': 'Escape velocity scales with √(M/R).', '11-12': 'M_earth / M_moon ≈ 81.3, resulting in vastly different potential depths.' } }
          ],
          observeInstruction: 'Select the Moon in the Escape Velocity widget and launch a probe at 2.4 km/s to see it escape into interplanetary space.',
          explanation: {
            '6-8': 'Because the Moon has much less mass than Earth, its gravity well is much shallower, making it easy for rockets to blast off with very little fuel!',
            '9-10': 'v_escape scales with √(M/R). Since the Moon has 1.2% the mass and 27% the radius of Earth, its escape velocity is only 21% of Earth’s.',
            '11-12': 'The Moon’s gravitational potential well depth is GM/R ≈ 2.82×10⁶ J/kg, compared to Earth’s 6.25×10⁷ J/kg, a 22-fold energy reduction.'
          }
        }
      }
    ]
  }
];
