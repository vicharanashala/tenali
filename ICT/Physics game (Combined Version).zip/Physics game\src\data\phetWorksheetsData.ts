import { GradeTier } from '../types/curriculum';

export interface PhETInquiryTask {
  id: string;
  taskTitle: string;
  instructions: Record<GradeTier, string>;
  verificationQuestion: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
  xpReward: number;
}

export interface PhETSimMeta {
  id: string;
  title: string;
  url: string;
  recommendedTiers: GradeTier[];
  description: Record<GradeTier, string>;
  tasks: PhETInquiryTask[];
}

export const PHET_SIMULATIONS: PhETSimMeta[] = [
  {
    id: 'gravity-and-orbits',
    title: 'Gravity and Orbits',
    url: 'https://phet.colorado.edu/sims/html/gravity-and-orbits/latest/gravity-and-orbits_en.html',
    recommendedTiers: ['6-8', '9-10'],
    description: {
      '6-8': 'Move the Sun, Earth, Moon, and space station to see how gravity controls their motion and paths.',
      '9-10': 'Explore how changing the mass of the Sun or Earth alters the orbital speed, radius, and period.',
      '11-12': 'Verify circular vs elliptical orbit dynamics, vector alignments, and conservation of angular momentum.'
    },
    tasks: [
      {
        id: 'task_gno_1',
        taskTitle: 'Turn Gravity OFF Mid-Orbit',
        instructions: {
          '6-8': 'Turn on the Path checkbox. While Earth is orbiting, turn Gravity to OFF. Observe the path Earth takes.',
          '9-10': 'Observe the velocity vector direction immediately after turning gravity off.',
          '11-12': 'Verify Newton’s 1st Law: with net external force F_net = 0, d(mv)/dt = 0; the trajectory becomes a straight inertial tangent line.'
        },
        verificationQuestion: {
          question: 'What path does Earth take when gravity is turned off?',
          options: [
            'It continues orbiting in a circle.',
            'It stops dead in space.',
            'It flies straight in a straight line along its current velocity vector.',
            'It spirals inward towards where the Sun used to be.'
          ],
          correctIndex: 2,
          explanation: 'Newton’s First Law: an object in motion remains in straight-line motion at constant velocity unless acted upon by a net force!'
        },
        xpReward: 25
      },
      {
        id: 'task_gno_2',
        taskTitle: 'Double the Star’s Mass',
        instructions: {
          '6-8': 'Double the Star’s mass using the mass slider. What happens to the Earth’s orbit?',
          '9-10': 'Observe how doubling M increases gravitational acceleration g = GM/r², pulling Earth into a tighter, faster orbit or causing a collision.',
          '11-12': 'Since v_c = √(GM/r), doubling M at the existing radius leaves the current velocity sub-circular, turning the orbit into an ellipse with periapsis closer to the star.'
        },
        verificationQuestion: {
          question: 'When the Star mass is doubled, what happens to the Earth?',
          options: [
            'It flies out of the solar system.',
            'It is pulled inward into a closer, faster elliptical orbit.',
            'Its orbit does not change at all.',
            'Its speed drops to zero.'
          ],
          correctIndex: 1,
          explanation: 'Stronger gravity pulls Earth inward, increasing orbital acceleration and tightening the orbit.'
        },
        xpReward: 25
      }
    ]
  },
  {
    id: 'gravity-force-lab-basics',
    title: 'Gravity Force Lab: Basics',
    url: 'https://phet.colorado.edu/sims/html/gravity-force-lab-basics/latest/gravity-force-lab-basics_en.html',
    recommendedTiers: ['6-8', '9-10'],
    description: {
      '6-8': 'Pull spheres apart and change their masses to see the gravitational force arrows grow and shrink.',
      '9-10': 'Measure the exact force values to discover the inverse-square law and Newton’s 3rd Law.',
      '11-12': 'Quantitative verification of F = G·m₁·m₂/r² with reciprocal equal-and-opposite force vectors.'
    },
    tasks: [
      {
        id: 'task_gfl_1',
        taskTitle: 'Newton’s Third Law Reciprocity',
        instructions: {
          '6-8': 'Set Sphere 1 to 10 kg and Sphere 2 to 100 kg. Compare the force arrow on Sphere 1 vs Sphere 2.',
          '9-10': 'Observe whether the more massive sphere exerts a greater force on the smaller sphere than the smaller sphere exerts on the larger one.',
          '11-12': 'Verify that |F₁₂| = |F₂₁| strictly holds regardless of mass ratio m₁/m₂.'
        },
        verificationQuestion: {
          question: 'Does the 100 kg sphere pull harder on the 10 kg sphere than the 10 kg sphere pulls on the 100 kg sphere?',
          options: [
            'Yes, the 100 kg sphere pulls 10 times harder.',
            'No, both pull on each other with the EXACT same force magnitude.',
            'The 10 kg sphere pulls harder because it is lighter.',
            'Neither pulls on the other.'
          ],
          correctIndex: 1,
          explanation: 'Newton’s Third Law: forces always occur in equal and opposite pairs! F₁₂ = -F₂₁.'
        },
        xpReward: 25
      }
    ]
  },
  {
    id: 'keplers-laws',
    title: 'Kepler’s Laws',
    url: 'https://phet.colorado.edu/sims/html/keplers-laws/latest/keplers-laws_en.html',
    recommendedTiers: ['9-10', '11-12'],
    description: {
      '6-8': 'Explore oval orbits, swept sectors, and how orbital distance controls year length.',
      '9-10': 'Verify Kepler’s 1st Law (ellipses), 2nd Law (equal areas in equal time), and 3rd Law (T² ∝ a³).',
      '11-12': 'Analyze orbital eccentricity, perihelion vs aphelion velocity ratios, and vis-viva mechanical energy.'
    },
    tasks: [
      {
        id: 'task_kep_1',
        taskTitle: 'Verify Equal Areas in Equal Times',
        instructions: {
          '9-10': 'Enable the Swept Area tool. Compare the short, wide sector at perihelion with the long, narrow sector at aphelion.',
          '11-12': 'Verify dA/dt = L / (2m) = constant. Confirm areal velocity conservation over identical time intervals Δt.',
          '6-8': 'Turn on the shaded slices tool and watch the slices fill in.'
        },
        verificationQuestion: {
          question: 'Why is the swept area triangle near perihelion short and wide, while near aphelion it is long and skinny?',
          options: [
            'Because the planet speeds up when close to the Sun, covering a longer arc distance in the same time.',
            'Because the Sun moves toward the planet.',
            'Because the timer runs slower at perihelion.',
            'It is just an optical illusion.'
          ],
          correctIndex: 0,
          explanation: 'Because the planet travels faster at perihelion, the base of the triangle (arc length v·Δt) is much wider, balancing the shorter height (r) to maintain equal area!'
        },
        xpReward: 30
      }
    ]
  },
  {
    id: 'my-solar-system',
    title: 'My Solar System',
    url: 'https://phet.colorado.edu/sims/html/my-solar-system/latest/my-solar-system_en.html',
    recommendedTiers: ['11-12'],
    description: {
      '6-8': 'Create your own planetary system with up to 4 stars and planets.',
      '9-10': 'Set up multi-body systems and watch how small perturbations can fling planets out.',
      '11-12': 'Investigate chaotic 3-body gravitational dynamics, Lagrange points, and binary star systems.'
    },
    tasks: [
      {
        id: 'task_mss_1',
        taskTitle: 'Binary Star System Stability',
        instructions: {
          '11-12': 'Select Preset: Binary Star with Planet. Observe how the planet’s trajectory is perturbed by the rotating quadrupole gravitational potential.',
          '9-10': 'Watch how two massive stars orbit their common center of mass (barycenter).',
          '6-8': 'Watch two suns dancing around each other like a cosmic waltz.'
        },
        verificationQuestion: {
          question: 'Where is the center of mass (barycenter) in a system of two stars of identical mass?',
          options: [
            'Inside Star 1.',
            'Inside Star 2.',
            'Exactly halfway between the two stars in empty space.',
            'At infinity.'
          ],
          correctIndex: 2,
          explanation: 'When two masses are equal (m₁ = m₂), the barycenter R_cm = (m₁r₁ + m₂r₂)/(m₁ + m₂) lies exactly halfway between their centers.'
        },
        xpReward: 30
      }
    ]
  }
];
