import * as THREE from 'three';

export const SunCoronaShader = {
  vertexShader: `
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vPosition;

    void main() {
      vUv = uv;
      vNormal = normalize(normalMatrix * normal);
      vPosition = position;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform float uTime;
    uniform vec3 uColorCore;
    uniform vec3 uColorEdge;
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vPosition;

    // Simple noise inside GLSL
    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      f = f * f * (3.0 - 2.0 * f);
      return mix(
        mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), f.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
        f.y
      );
    }

    void main() {
      // Animated plasma pulsation
      vec2 uv = vUv * 8.0;
      float n1 = noise(uv + vec2(uTime * 0.15, uTime * 0.08));
      float n2 = noise(uv * 2.0 - vec2(uTime * 0.2, -uTime * 0.12));
      float plasma = n1 * 0.6 + n2 * 0.4;

      // Fresnel rim glow
      vec3 viewDir = vec3(0.0, 0.0, 1.0);
      float fresnel = 1.0 - max(dot(vNormal, viewDir), 0.0);
      fresnel = pow(fresnel, 2.5);

      vec3 color = mix(uColorCore, uColorEdge, fresnel + plasma * 0.35);
      float alpha = clamp(0.3 + fresnel * 0.7 + plasma * 0.2, 0.0, 1.0);

      gl_FragColor = vec4(color, alpha);
    }
  `,
  createMaterial: () => {
    return new THREE.ShaderMaterial({
      vertexShader: SunCoronaShader.vertexShader,
      fragmentShader: SunCoronaShader.fragmentShader,
      uniforms: {
        uTime: { value: 0 },
        uColorCore: { value: new THREE.Color('#FACC15') },
        uColorEdge: { value: new THREE.Color('#EA580C') },
      },
      transparent: true,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      depthWrite: false,
    });
  }
};
