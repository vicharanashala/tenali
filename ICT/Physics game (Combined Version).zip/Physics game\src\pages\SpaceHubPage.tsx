﻿import React, { useState, useRef } from 'react';
import {
  Orbit,
  Maximize2,
  ExternalLink,
  RotateCcw
} from 'lucide-react';

export const SpaceHubPage: React.FC = () => {
  const [iframeKey, setIframeKey] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const handleFullscreen = () => {
    if (iframeRef.current) {
      if (iframeRef.current.requestFullscreen) {
        iframeRef.current.requestFullscreen();
      }
    }
  };

  const handleOpenNewTab = () => {
    window.open('/space_physics_3d_hub/index.html', '_blank');
  };

  const handleReload = () => {
    setIframeKey((prev) => prev + 1);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-4 flex flex-col gap-4">
      {/* Top Controls & Module Info Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900/80 backdrop-blur-md p-4 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold">
            <Orbit className="w-5 h-5 text-cyan-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-heading font-extrabold text-base md:text-lg text-white">
                Space Physics 3D Hub
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                CLASS 8 INTERACTIVE
              </span>
            </div>
            <p className="text-xs text-slate-400 font-sans mt-0.5">
              Moon Phases & Lunar Eclipse • Kepler's 3 Laws • Solar System Encyclopedia • Bilingual (EN / हिंदी)
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          <button
            onClick={handleReload}
            title="Reload 3D Hub Module"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Reset</span>
          </button>
          <button
            onClick={handleFullscreen}
            title="Full Screen View"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Fullscreen</span>
          </button>
          <button
            onClick={handleOpenNewTab}
            title="Open Space Physics 3D Hub in New Window"
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open in Full Tab</span>
          </button>
        </div>
      </div>

      {/* Interactive 3D Frame Container */}
      <div className="relative w-full h-[calc(100vh-175px)] min-h-[620px] rounded-2xl overflow-hidden border border-slate-800 bg-[#020510] shadow-2xl">
        <iframe
          key={iframeKey}
          ref={iframeRef}
          src="/space_physics_3d_hub/index.html"
          title="Space Physics 3D Hub"
          className="w-full h-full border-0 block"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; microphone; fullscreen"
        />
      </div>
    </div>
  );
};