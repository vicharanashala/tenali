import React, { useState } from 'react';
import katex from 'katex';
import { FormulaBinding } from '../../types/curriculum';
import { useCosmosStore } from '../../store/useCosmosStore';

interface FormulaInspectorProps {
  latex: string;
  bindings: FormulaBinding[];
}

export const FormulaInspector: React.FC<FormulaInspectorProps> = ({ latex, bindings }) => {
  const { gradeTier } = useCosmosStore();
  const [activeBinding, setActiveBinding] = useState<FormulaBinding | null>(null);

  // Render raw KaTeX to HTML string safely
  const renderedFormulaHtml = React.useMemo(() => {
    try {
      return katex.renderToString(latex, {
        displayMode: true,
        throwOnError: false
      });
    } catch {
      return latex;
    }
  }, [latex]);

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-xl p-3 my-2 text-slate-200">
      <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
        <span>Interactive Formula Inspector</span>
        <span className="text-cyan-400 font-mono">Hover variables below</span>
      </div>

      {/* KaTeX Equation Display */}
      <div
        className="py-2 px-3 bg-slate-950/70 rounded-lg text-center overflow-x-auto border border-slate-800/80 my-2"
        dangerouslySetInnerHTML={{ __html: renderedFormulaHtml }}
      />

      {/* Variable Pills */}
      <div className="flex flex-wrap gap-1.5 mt-2">
        {bindings.map((b) => (
          <button
            key={b.symbol}
            onMouseEnter={() => setActiveBinding(b)}
            onClick={() => setActiveBinding(b)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono transition-all border"
            style={{
              borderColor: activeBinding?.symbol === b.symbol ? b.color : 'rgba(148, 163, 184, 0.2)',
              backgroundColor: activeBinding?.symbol === b.symbol ? `${b.color}25` : 'rgba(15, 23, 42, 0.6)',
              color: b.color
            }}
          >
            <span className="font-bold">{b.symbol}</span>
            <span className="text-slate-400 text-[10px]">({b.unit})</span>
          </button>
        ))}
      </div>

      {/* Active Variable Details Card */}
      {activeBinding && (
        <div className="mt-2.5 p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 text-xs animate-in fade-in duration-200">
          <div className="flex items-center justify-between mb-1 font-mono">
            <span className="font-bold" style={{ color: activeBinding.color }}>
              {activeBinding.name} [{activeBinding.symbol}]
            </span>
            <span className="text-[11px] text-slate-400">SI Unit: {activeBinding.unit}</span>
          </div>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            {activeBinding.meaning[gradeTier]}
          </p>
        </div>
      )}
    </div>
  );
};
