﻿param(
    [int]$StartPort = 5173,
    [string]$Root = "$PSScriptRoot\dist"
)

$listener = $null
$Port = $StartPort

for ($p = $StartPort; $p -le ($StartPort + 20); $p++) {
    try {
        $temp = New-Object System.Net.HttpListener
        $prefix = "http://localhost:$p/"
        $temp.Prefixes.Add($prefix)
        $temp.Start()
        $listener = $temp
        $Port = $p
        break
    } catch {
        if ($temp) {
            try { $temp.Close() } catch {}
        }
    }
}

if (-not $listener) {
    Write-Error "Failed to bind HttpListener to any port from $StartPort to $($StartPort + 20)"
    exit 1
}

Write-Host "COSMOS LAB Server running at http://localhost:$Port/"

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".mjs"  = "application/javascript; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".svg"  = "image/svg+xml"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".json" = "application/json; charset=utf-8"
    ".ico"  = "image/x-icon"
    ".woff2"= "font/woff2"
    ".woff" = "font/woff"
    ".ttf"  = "font/ttf"
}

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $urlPath = $request.Url.LocalPath
        $relPath = $urlPath.TrimStart('/').Replace('/', '\')
        $filePath = Join-Path $Root $relPath

        if ($urlPath -eq "/" -or -not (Test-Path $filePath -PathType Leaf)) {
            $filePath = Join-Path $Root "index.html"
        }

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $mime = if ($mimeTypes.ContainsKey($ext)) { $mimeTypes[$ext] } else { "application/octet-stream" }
            $response.ContentType = $mime
            $response.AddHeader("Access-Control-Allow-Origin", "*")

            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
            $notFound = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $response.ContentLength64 = $notFound.Length
            $response.OutputStream.Write($notFound, 0, $notFound.Length)
        }
        $response.Close()
    }
} finally {
    if ($listener) {
        $listener.Stop()
        $listener.Close()
    }
}
