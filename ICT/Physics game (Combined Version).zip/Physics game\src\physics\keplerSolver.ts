import { OrbitalElements } from '../types/physics';

// Newton-Raphson solver for Kepler's equation: M = E - e * sin(E)
export function solveKepler(M_rad: number, e: number, maxIterations = 30, tolerance = 1e-8): number {
  // Normalize M to [0, 2pi)
  let M = M_rad % (2 * Math.PI);
  if (M < 0) M += 2 * Math.PI;

  // Initial estimate
  let E = e > 0.8 ? Math.PI : M;

  for (let i = 0; i < maxIterations; i++) {
    const f = E - e * Math.sin(E) - M;
    if (Math.abs(f) < tolerance) break;
    const fPrime = 1 - e * Math.cos(E);
    E = E - f / fPrime;
  }

  return E;
}

// Computes true anomaly nu from eccentric anomaly E and eccentricity e
export function trueAnomalyFromE(E: number, e: number): number {
  const cosE = Math.cos(E);
  const sinE = Math.sin(E);
  return 2 * Math.atan2(Math.sqrt(1 + e) * sinE, Math.sqrt(1 - e) * (1 + cosE));
}

// Converts orbital elements to 3D Heliocentric Cartesian Position (x, y, z)
export function elementsToPosition(
  elements: OrbitalElements,
  timeDays: number
): { x: number; y: number; z: number; r: number; trueAnomaly: number } {
  const { semiMajorAxis, eccentricity: e, inclination, longitudeOfAscendingNode: node, argumentOfPeriapsis: peri, meanAnomalyAtEpoch, periodDays } = elements;

  // Mean motion n (rad/day)
  const n = (2 * Math.PI) / periodDays;
  const M0_rad = (meanAnomalyAtEpoch * Math.PI) / 180;
  const M = M0_rad + n * timeDays;

  // Solve for Eccentric Anomaly
  const E = solveKepler(M, e);

  // True anomaly nu
  const nu = trueAnomalyFromE(E, e);

  // Radius r
  const r = semiMajorAxis * (1 - e * Math.cos(E));

  // Position in orbital plane
  const x_orb = r * Math.cos(nu);
  const y_orb = r * Math.sin(nu);

  // Angles in radians
  const i_rad = (inclination * Math.PI) / 180;
  const node_rad = (node * Math.PI) / 180;
  const peri_rad = (peri * Math.PI) / 180;

  // Rotations: Periapsis -> Inclination -> Ascending Node
  const cosNode = Math.cos(node_rad);
  const sinNode = Math.sin(node_rad);
  const cosPeri = Math.cos(peri_rad);
  const sinPeri = Math.sin(peri_rad);
  const cosInc = Math.cos(i_rad);
  const sinInc = Math.sin(i_rad);

  const Px = cosNode * cosPeri - sinNode * sinPeri * cosInc;
  const Py = sinNode * cosPeri + cosNode * sinPeri * cosInc;
  const Pz = sinPeri * sinInc;

  const Qx = -cosNode * sinPeri - sinNode * cosPeri * cosInc;
  const Qy = -sinNode * sinPeri + cosNode * cosPeri * cosInc;
  const Qz = cosPeri * sinInc;

  const x = x_orb * Px + y_orb * Qx;
  const y = x_orb * Pz + y_orb * Qz; // Y-up in Three.js
  const z = -(x_orb * Py + y_orb * Qy);

  return { x, y, z, r, trueAnomaly: nu };
}
