export type GradeTier = '6-8' | '9-10' | '11-12';

export interface POEPrompt {
  id: string;
  question: string;
  options: {
    id: string;
    text: string;
    isCorrect?: boolean;
    explanation: Record<GradeTier, string>;
  }[];
  observeInstruction: string;
  explanation: Record<GradeTier, string>;
}

export interface FormulaBinding {
  symbol: string;
  name: string;
  unit: string;
  meaning: Record<GradeTier, string>;
  color: string;
}

export interface LessonCard {
  id: string;
  title: string;
  subtitle: string;
  widgetType: 'newton-cannon' | 'inverse-square' | 'kepler' | 'lunar-phase' | 'orbital-tilt' | 'density-compare' | 'escape-velocity';
  explanation: Record<GradeTier, string>;
  formula?: {
    latex: string;
    bindings: FormulaBinding[];
  };
  poeCheckpoint?: POEPrompt;
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  subtitle: string;
  badgeId: string;
  deepLinkTab?: 'academy' | 'simlab' | 'observatory' | 'materials';
  deepLinkPreset?: string;
  cards: LessonCard[];
}
