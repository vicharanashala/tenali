import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw } from 'lucide-react';
import { soundEngine } from '../../utils/soundEngine';

export const NewtonCannonWidget: React.FC = () => {
  const [speed, setSpeed] = useState<number>(7.9); // km/s
  const [isFiring, setIsFiring] = useState<boolean>(false);
  const [simTime, setSimTime] = useState<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Speed regimes:
  // < 7.9: Sub-orbital (crashes into Earth)
  // 7.9: Circular orbit
  // 8.0 - 11.1: Elliptical orbit
  // >= 11.2: Parabolic/Hyperbolic escape

  useEffect(() => {
    let animId: number;
    if (isFiring) {
      animId = requestAnimationFrame(() => {
        setSimTime((t) => t + 0.03);
      });
    }
    return () => cancelAnimationFrame(animId);
  }, [isFiring, simTime]);

  const handleFire = () => {
    soundEngine.playThruster(0.2);
    setSimTime(0);
    setIsFiring(true);
  };

  const handleReset = () => {
    soundEngine.playClick(600);
    setIsFiring(false);
    setSimTime(0);
  };

  // Render 2D Canvas simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const cx = w / 2;
    const cy = h / 2 + 15;
    const earthRadius = 70;
    const mountainHeight = 16;
    const launchR = earthRadius + mountainHeight;

    // Draw Earth
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, earthRadius, 0, Math.PI * 2);
    const earthGrad = ctx.createRadialGradient(cx - 20, cy - 20, 10, cx, cy, earthRadius);
    earthGrad.addColorStop(0, '#38BDF8');
    earthGrad.addColorStop(0.7, '#1E40AF');
    earthGrad.addColorStop(1, '#0F172A');
    ctx.fillStyle = earthGrad;
    ctx.fill();
    ctx.strokeStyle = '#38BDF8';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Atmosphere halo
    ctx.beginPath();
    ctx.arc(cx, cy, earthRadius + 6, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
    ctx.lineWidth = 4;
    ctx.stroke();

    // Mountain at top
    ctx.beginPath();
    ctx.moveTo(cx - 8, cy - earthRadius);
    ctx.lineTo(cx, cy - launchR);
    ctx.lineTo(cx + 8, cy - earthRadius);
    ctx.closePath();
    ctx.fillStyle = '#64748B';
    ctx.fill();

    // Trajectory calculation
    // Speed regime calculation
    const points: { x: number; y: number }[] = [];
    const maxTheta = speed >= 11.2 ? Math.PI * 0.95 : Math.PI * 4;
    const steps = 180;

    let crashed = false;

    for (let i = 0; i < steps; i++) {
      const theta = (i / steps) * maxTheta;
      let r = launchR;

      if (speed < 7.9) {
        // Spiral in or crash
        const decay = (7.9 - speed) * 0.15;
        r = launchR - theta * 32 * decay;
        if (r <= earthRadius) {
          crashed = true;
          points.push({
            x: cx + r * Math.sin(theta),
            y: cy - r * Math.cos(theta),
          });
          break;
        }
      } else if (Math.abs(speed - 7.9) < 0.2) {
        // Circle
        r = launchR;
      } else if (speed < 11.2) {
        // Ellipse
        const e = (speed - 7.9) / 3.3; // 0 to ~1
        r = launchR * (1 + e) / (1 + e * Math.cos(theta));
      } else {
        // Hyperbola escape
        const e = 1.0 + (speed - 11.2) * 0.3;
        r = launchR * (1 + e) / (1 + e * Math.cos(theta));
      }

      points.push({
        x: cx + r * Math.sin(theta),
        y: cy - r * Math.cos(theta),
      });
    }

    // Draw full trajectory line
    ctx.beginPath();
    points.forEach((pt, idx) => {
      if (idx === 0) ctx.moveTo(pt.x, pt.y);
      else ctx.lineTo(pt.x, pt.y);
    });
    ctx.strokeStyle = speed >= 11.2 ? '#10B981' : speed >= 7.9 ? '#A855F7' : '#EF4444';
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.setLineDash([]);

    // Animated projectile position
    if (points.length > 0) {
      const currentIdx = Math.min(points.length - 1, Math.floor(simTime * 40) % points.length);
      const currPt = points[currentIdx];

      // Draw cannonball
      ctx.beginPath();
      ctx.arc(currPt.x, currPt.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#FACC15';
      ctx.fill();
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Velocity vector (Cyan)
      if (currentIdx < points.length - 1) {
        const nextPt = points[currentIdx + 1];
        const vx = (nextPt.x - currPt.x) * 4;
        const vy = (nextPt.y - currPt.y) * 4;
        ctx.beginPath();
        ctx.moveTo(currPt.x, currPt.y);
        ctx.lineTo(currPt.x + vx, currPt.y + vy);
        ctx.strokeStyle = '#38BDF8';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      // Gravitational force vector toward Earth center (Solar Amber)
      const toCenterX = (cx - currPt.x) * 0.15;
      const toCenterY = (cy - currPt.y) * 0.15;
      ctx.beginPath();
      ctx.moveTo(currPt.x, currPt.y);
      ctx.lineTo(currPt.x + toCenterX, currPt.y + toCenterY);
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    ctx.restore();
  }, [speed, simTime]);

  const getStatusText = () => {
    if (speed < 7.9) return { text: 'Sub-Orbital Ballistic Crash', color: 'text-rose-400' };
    if (Math.abs(speed - 7.9) < 0.2) return { text: 'Stable Circular Orbit (v ≈ 7.9 km/s)', color: 'text-cyan-400' };
    if (speed < 11.2) return { text: 'Elliptical Kepler Orbit (e < 1.0)', color: 'text-purple-400' };
    return { text: 'Hyperbolic Escape Trajectory (v ≥ 11.2 km/s)', color: 'text-emerald-400' };
  };

  const status = getStatusText();

  return (
    <div className="flex flex-col items-center w-full h-full bg-slate-950/60 p-3 rounded-xl border border-slate-800">
      <div className="w-full flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Newton’s Mountain Cannon</span>
        <span className={`text-xs font-bold font-mono ${status.color}`}>{status.text}</span>
      </div>

      <div className="relative w-full max-w-[340px] aspect-[4/3] flex items-center justify-center">
        <canvas ref={canvasRef} width={340} height={250} className="w-full h-full" />
      </div>

      <div className="w-full mt-2 space-y-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400">Launch Velocity (v):</span>
          <span className="text-cyan-400 font-bold text-sm">{speed.toFixed(1)} km/s</span>
        </div>

        <input
          type="range"
          min="2.0"
          max="13.0"
          step="0.1"
          value={speed}
          onChange={(e) => {
            setSpeed(parseFloat(e.target.value));
            setSimTime(0);
          }}
          className="w-full accent-cyan-400 cursor-pointer"
        />

        <div className="flex items-center justify-between gap-2 pt-1">
          <button
            onClick={handleFire}
            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-medium transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" /> Fire Cannon
          </button>
          <button
            onClick={handleReset}
            className="flex items-center justify-center gap-1.5 py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </button>
        </div>
      </div>
    </div>
  );
};
