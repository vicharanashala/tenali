// Celestial coordinate transformations for Stellarium-style Sky Dome

export interface SkyCoord {
  raHours: number; // 0 to 24
  decDeg: number;  // -90 to +90
}

export interface HorizontalCoord {
  altDeg: number; // -90 to +90
  azDeg: number;  // 0 to 360 (0=North, 90=East)
}

// Obliquity of ecliptic J2000
export const EPSILON_OBLIQUITY_DEG = 23.4392911;

// Convert Right Ascension (hours) and Declination (deg) to 3D unit sphere vector (Three.js coordinates)
export function radecToCartesian(raHours: number, decDeg: number, radius = 100): [number, number, number] {
  const raRad = (raHours * 15 * Math.PI) / 180;
  const decRad = (decDeg * Math.PI) / 180;

  const cosDec = Math.cos(decRad);
  const x = radius * cosDec * Math.cos(raRad);
  const y = radius * Math.sin(decRad); // Celestial North along +Y
  const z = -radius * cosDec * Math.sin(raRad);

  return [x, y, z];
}

// Convert Alt/Az to local observer Cartesian (dome view)
export function altazToCartesian(altDeg: number, azDeg: number, radius = 100): [number, number, number] {
  const altRad = (altDeg * Math.PI) / 180;
  const azRad = (azDeg * Math.PI) / 180;

  const cosAlt = Math.cos(altRad);
  // Azimuth: 0=N, 90=E, 180=S, 270=W
  const x = radius * cosAlt * Math.sin(azRad);
  const y = radius * Math.sin(altRad); // Zenith = +Y
  const z = -radius * cosAlt * Math.cos(azRad);

  return [x, y, z];
}

// Convert Equatorial (RA/Dec) to Local Horizontal (Alt/Az)
export function equatorialToHorizontal(
  raHours: number,
  decDeg: number,
  observerLatDeg: number,
  localSiderealTimeHours: number
): HorizontalCoord {
  const haHours = (localSiderealTimeHours - raHours + 24) % 24;
  const haRad = (haHours * 15 * Math.PI) / 180;
  const decRad = (decDeg * Math.PI) / 180;
  const latRad = (observerLatDeg * Math.PI) / 180;

  const sinAlt = Math.sin(decRad) * Math.sin(latRad) + Math.cos(decRad) * Math.cos(latRad) * Math.cos(haRad);
  const altRad = Math.asin(Math.max(-1, Math.min(1, sinAlt)));

  const cosAz = (Math.sin(decRad) - Math.sin(altRad) * Math.sin(latRad)) / (Math.cos(altRad) * Math.cos(latRad));
  let azRad = Math.acos(Math.max(-1, Math.min(1, cosAz)));

  if (Math.sin(haRad) > 0) {
    azRad = 2 * Math.PI - azRad;
  }

  return {
    altDeg: (altRad * 180) / Math.PI,
    azDeg: (azRad * 180) / Math.PI
  };
}
