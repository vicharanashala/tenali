import { CelestialBody } from '../types/physics';

export const SOLAR_SYSTEM_BODIES: CelestialBody[] = [
  {
    id: 'sun',
    name: 'Sun',
    mass: 1.98847e30,
    radius: 696340,
    color: '#FACC15',
    semiMajorAxis: 0,
    eccentricity: 0,
    inclination: 0,
    orbitalPeriod: 0,
    rotationPeriod: 609.12,
    axialTilt: 7.25,
    type: 'star',
    description: {
      '6-8': 'The glowing giant heart of our solar system, containing 99.8% of all matter.',
      '9-10': 'G-type main-sequence star fusing 600 million tons of hydrogen into helium every second via the proton-proton chain.',
      '11-12': 'Spectral class G2V, radiating 3.828×10²⁶ W, establishing the heliocentric gravitational potential well.'
    }
  },
  {
    id: 'mercury',
    name: 'Mercury',
    mass: 3.3011e23,
    radius: 2439.7,
    color: '#94A3B8',
    semiMajorAxis: 0.387098,
    eccentricity: 0.20563,
    inclination: 7.005,
    orbitalPeriod: 0.240846,
    rotationPeriod: 1407.6,
    axialTilt: 0.034,
    type: 'rocky',
    description: {
      '6-8': 'The smallest and closest planet to the Sun, boiling hot during day and freezing at night.',
      '9-10': 'High orbital speed (47.4 km/s) and highest orbital eccentricity among the 8 major planets.',
      '11-12': 'Exhibits a 3:2 spin-orbit resonance and 43 arcseconds/century anomalous perihelion precession verified by General Relativity.'
    }
  },
  {
    id: 'venus',
    name: 'Venus',
    mass: 4.8675e24,
    radius: 6051.8,
    color: '#FDE047',
    semiMajorAxis: 0.723332,
    eccentricity: 0.00677,
    inclination: 3.39458,
    orbitalPeriod: 0.615197,
    rotationPeriod: -5832.5,
    axialTilt: 177.36,
    type: 'rocky',
    atmosphereColor: '#F59E0B',
    description: {
      '6-8': 'Earth’s toxic twin, cloaked in thick yellow sulfuric acid clouds with runaway greenhouse heat.',
      '9-10': 'Extreme 92-bar carbon dioxide atmosphere causing surface temperatures of 465 °C, hotter than Mercury.',
      '11-12': 'Retrograde axial rotation (-243 d) and super-rotating upper atmosphere (4 d period) with near-zero orbital eccentricity.'
    }
  },
  {
    id: 'earth',
    name: 'Earth',
    mass: 5.9722e24,
    radius: 6371.0,
    color: '#38BDF8',
    semiMajorAxis: 1.000000,
    eccentricity: 0.0167086,
    inclination: 0.00005,
    orbitalPeriod: 1.000017,
    rotationPeriod: 23.934,
    axialTilt: 23.439,
    type: 'rocky',
    atmosphereColor: '#38BDF8',
    description: {
      '6-8': 'Our oasis world with liquid water oceans, a shielding magnetic field, and the only known life.',
      '9-10': 'Mean orbital speed 29.78 km/s; 23.44° axial obliquity drives the annual cycle of four seasons.',
      '11-12': 'Dynamo geodynamo driven by liquid Fe-Ni convection in the outer core; 1 AU = 149,597,870.7 km baseline.'
    }
  },
  {
    id: 'moon',
    name: 'Moon',
    mass: 7.342e22,
    radius: 1737.4,
    color: '#CBD5E1',
    semiMajorAxis: 0.00257, // ~384,400 km
    eccentricity: 0.0549,
    inclination: 5.145,
    orbitalPeriod: 0.0748, // 27.32 days
    rotationPeriod: 655.7,
    axialTilt: 1.542,
    type: 'moon',
    description: {
      '6-8': 'Earth’s only natural satellite, causing ocean tides and spectacular solar & lunar eclipses.',
      '9-10': 'Synchronously tidally locked to Earth; 5.145° orbital inclination prevents eclipses at every new/full moon.',
      '11-12': 'Nodal regression period of 18.61 years; moves Earth-Moon barycenter 4,670 km from Earth’s center.'
    }
  },
  {
    id: 'mars',
    name: 'Mars',
    mass: 6.4171e23,
    radius: 3389.5,
    color: '#EF4444',
    semiMajorAxis: 1.523679,
    eccentricity: 0.0934,
    inclination: 1.850,
    orbitalPeriod: 1.8808,
    rotationPeriod: 24.622,
    axialTilt: 25.19,
    type: 'rocky',
    atmosphereColor: '#DC2626',
    description: {
      '6-8': 'The Red Planet, rich in iron oxide dust, home to giant Olympus Mons and ancient dried river valleys.',
      '9-10': 'Surface gravity g = 3.72 m/s² (38% of Earth); thin CO₂ atmosphere with seasonal polar dry-ice sublimation.',
      '11-12': 'Kepler’s analysis of Tycho Brahe’s Mars observations proved orbits are ellipses with the Sun at one focus.'
    }
  },
  {
    id: 'jupiter',
    name: 'Jupiter',
    mass: 1.8982e27,
    radius: 69911,
    color: '#F97316',
    semiMajorAxis: 5.204267,
    eccentricity: 0.048498,
    inclination: 1.303,
    orbitalPeriod: 11.862,
    rotationPeriod: 9.925,
    axialTilt: 3.13,
    type: 'gas_giant',
    description: {
      '6-8': 'The king of planets: a massive ball of gas with a Great Red Spot storm larger than Earth!',
      '9-10': 'Contains 2.5 times the mass of all other planets combined; fastest planetary spin period (under 10 hours).',
      '11-12': 'Barycenter with the Sun lies outside the solar photosphere (1.07 R_sun); massive metallic hydrogen mantle.'
    }
  },
  {
    id: 'saturn',
    name: 'Saturn',
    mass: 5.6834e26,
    radius: 58232,
    color: '#EAB308',
    semiMajorAxis: 9.5826,
    eccentricity: 0.05555,
    inclination: 2.485,
    orbitalPeriod: 29.457,
    rotationPeriod: 10.656,
    axialTilt: 26.73,
    type: 'gas_giant',
    rings: {
      innerRadius: 1.2,
      outerRadius: 2.3,
      color: '#CA8A04'
    },
    description: {
      '6-8': 'The jewel of the solar system with dazzling rings made of billions of icy rock fragments.',
      '9-10': 'Mean density is only 0.687 g/cm³—Saturn would float in a giant cosmic bathtub filled with water!',
      '11-12': 'Rings span 282,000 km but average just 10 meters thick; maintained within the Roche limit by shepherd moons.'
    }
  }
];
