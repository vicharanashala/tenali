﻿import { GradeTier } from './curriculum';

export type RankTitle =
  | 'Star Cadet'
  | 'Orbital Pilot'
  | 'Mission Specialist'
  | 'Solar Cartographer'
  | 'Chief Astrophysicist';

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string; // lucide icon identifier
  unlockedAt?: string | null;
  category: 'onboarding' | 'physics' | 'astronomy' | 'engineering';
}

export type TutorialStep = 1 | 2 | 3 | 4 | 5;

export interface UserProgress {
  xp: number;
  rank: RankTitle;
  gradeTier: GradeTier;
  tutorialCompleted: boolean;
  tutorialCurrentStep: TutorialStep;
  voiceCaptions: boolean;
  isMuted: boolean;
  activeTab: 'academy' | 'simlab' | 'observatory' | 'materials' | 'space_hub';
  unlockedBadges: string[]; // badge IDs
  completedChapters: string[];
  completedMissions: string[];
  poeStreak: number;
  visitedEclipses: {
    totalSolar: boolean;
    annularSolar: boolean;
    totalLunar: boolean;
  };
  identifiedConstellations: string[];
  inspectedLayers: Record<string, string[]>; // planetId -> layerNames[]
  comparedJumpWorlds: string[];
}
