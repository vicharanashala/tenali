import { G_SI } from './constants';

export function calculateSurfaceGravity(massKg: number, radiusKm: number): number {
  const radiusMeters = radiusKm * 1000;
  return (G_SI * massKg) / (radiusMeters * radiusMeters);
}

export function calculateWeight(massKg: number, g: number): number {
  return massKg * g;
}

export function calculateJumpProfile(
  g: number,
  takeoffSpeedMs = 3.0 // Standard human athletic standing vertical takeoff ~3 m/s
): {
  maxHeightMeters: number;
  hangTimeSeconds: number;
  heightAtTime: (t: number) => number;
  speedAtTime: (t: number) => number;
} {
  const safeG = Math.max(0.01, g);
  const maxHeightMeters = (takeoffSpeedMs * takeoffSpeedMs) / (2 * safeG);
  const hangTimeSeconds = (2 * takeoffSpeedMs) / safeG;

  const heightAtTime = (t: number) => {
    if (t < 0 || t > hangTimeSeconds) return 0;
    return Math.max(0, takeoffSpeedMs * t - 0.5 * safeG * t * t);
  };

  const speedAtTime = (t: number) => {
    if (t < 0 || t > hangTimeSeconds) return 0;
    return takeoffSpeedMs - safeG * t;
  };

  return {
    maxHeightMeters,
    hangTimeSeconds,
    heightAtTime,
    speedAtTime
  };
}

export function calculateEscapeVelocity(massKg: number, radiusKm: number): number {
  const radiusMeters = radiusKm * 1000;
  return Math.sqrt((2 * G_SI * massKg) / radiusMeters); // in m/s
}

export function calculateCircularVelocity(massKg: number, radiusKm: number): number {
  const radiusMeters = radiusKm * 1000;
  return Math.sqrt((G_SI * massKg) / radiusMeters); // in m/s
}

// Hohmann Transfer delta-v calculator
export function calculateHohmannTransfer(
  primaryMassKg: number,
  r1Km: number, // Initial orbit radius
  r2Km: number  // Target orbit radius
): {
  deltaV1Kms: number;
  deltaV2Kms: number;
  totalDeltaVKms: number;
  transferTimeHours: number;
  semiMajorAxisKm: number;
} {
  const mu = G_SI * primaryMassKg; // m^3 / s^2
  const r1M = r1Km * 1000;
  const r2M = r2Km * 1000;

  const aTransM = (r1M + r2M) / 2;

  // Initial circular speed
  const v1 = Math.sqrt(mu / r1M);
  // Transfer ellipse speed at periapsis
  const vTrans1 = Math.sqrt(mu * (2 / r1M - 1 / aTransM));
  const deltaV1 = Math.abs(vTrans1 - v1);

  // Final circular speed
  const v2 = Math.sqrt(mu / r2M);
  // Transfer ellipse speed at apoapsis
  const vTrans2 = Math.sqrt(mu * (2 / r2M - 1 / aTransM));
  const deltaV2 = Math.abs(v2 - vTrans2);

  // Half orbital period of transfer ellipse
  const transferTimeSec = Math.PI * Math.sqrt(Math.pow(aTransM, 3) / mu);

  return {
    deltaV1Kms: deltaV1 / 1000,
    deltaV2Kms: deltaV2 / 1000,
    totalDeltaVKms: (deltaV1 + deltaV2) / 1000,
    transferTimeHours: transferTimeSec / 3600,
    semiMajorAxisKm: aTransM / 1000
  };
}
