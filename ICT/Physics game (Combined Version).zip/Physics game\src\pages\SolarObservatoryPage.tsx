import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import {
  Compass,
  Sparkles,
  Play,
  Pause,
  RotateCcw,
  Eye,
  Info,
  Calendar,
  Layers,
  Moon,
  Sun,
  Globe
} from 'lucide-react';
import { SOLAR_SYSTEM_BODIES } from '../data/solarSystemData';
import { BRIGHT_STARS, CONSTELLATIONS } from '../data/constellationsData';
import { getProceduralTexture } from '../utils/proceduralTextures';
import { AtmosphereShader } from '../shaders/atmosphereShader';
import { SunCoronaShader } from '../shaders/sunCoronaShader';
import { ShadowConeShader } from '../shaders/shadowConeShader';
import { classifySolarEclipse, classifyLunarEclipse, computeShadowCones } from '../physics/eclipseGeometry';
import { radecToCartesian, equatorialToHorizontal } from '../physics/celestialCoords';
import { useCosmosStore } from '../store/useCosmosStore';
import { soundEngine } from '../utils/soundEngine';
import { formatDistance, formatSpeed } from '../utils/telemetryFormat';

export const SolarObservatoryPage: React.FC = () => {
  const {
    gradeTier,
    addXP,
    identifyConstellation,
    recordEclipseVisit
  } = useCosmosStore();

  const [subView, setSubView] = useState<'system' | 'skydome' | 'eclipse'>('system');
  const [scaleMode, setScaleMode] = useState<'classroom' | 'true'>('classroom');
  const [selectedBodyId, setSelectedBodyId] = useState<string>('earth');
  const [timeMultiplier, setTimeMultiplier] = useState<number>(1.0);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Eclipse view state
  const [eclipseMode, setEclipseMode] = useState<'solar' | 'lunar'>('solar');
  const [lunarDistanceKm, setLunarDistanceKm] = useState<number>(384400); // 363,300 (perigee) to 405,500 (apogee)
  const [nodeOffsetDeg, setNodeOffsetDeg] = useState<number>(0); // 0 = exactly at node -> Total eclipse!
  const [hasTilt, setHasTilt] = useState<boolean>(true);

  // Sky dome toggles
  const [showConstellationLines, setShowConstellationLines] = useState<boolean>(true);
  const [showRADecGrid, setShowRADecGrid] = useState<boolean>(true);
  const [observerLat, setObserverLat] = useState<number>(28.6); // New Delhi ~28.6 deg N
  const [siderealTime, setSiderealTime] = useState<number>(6.0); // 0 to 24 hrs

  const containerRef = useRef<HTMLDivElement | null>(null);
  const pipCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const selectedBody = SOLAR_SYSTEM_BODIES.find((b) => b.id === selectedBodyId) || SOLAR_SYSTEM_BODIES[3];

  // Eclipse Classification
  const eclipseInfo = React.useMemo(() => {
    const effectiveNodeDeg = hasTilt ? nodeOffsetDeg : 0;
    if (eclipseMode === 'solar') {
      const res = classifySolarEclipse(lunarDistanceKm, effectiveNodeDeg);
      if (res.type === 'TOTAL_SOLAR') recordEclipseVisit('totalSolar');
      if (res.type === 'ANNULAR_SOLAR') recordEclipseVisit('annularSolar');
      return res;
    } else {
      const res = classifyLunarEclipse(lunarDistanceKm, effectiveNodeDeg);
      if (res.type === 'TOTAL_LUNAR') recordEclipseVisit('totalLunar');
      return { ...res, umbraRadiusKm: 4600 };
    }
  }, [eclipseMode, lunarDistanceKm, nodeOffsetDeg, hasTilt]);

  // Picture-in-Picture 2D Canvas rendering for Eclipse Observer
  useEffect(() => {
    if (subView !== 'eclipse') return;
    const canvas = pipCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const cx = w / 2;
    const cy = h / 2;
    const sunR = 48;

    // Apparent Moon size depends on distance: Perigee = larger (Total), Apogee = smaller (Annular)
    // At perigee ~363,300 km -> moonR ~ 50.5 px (larger than Sun -> Total)
    // At apogee ~405,500 km -> moonR ~ 45.2 px (smaller than Sun -> Annular ring!)
    const moonR = sunR * (384400 / lunarDistanceKm) * 0.99;

    // Offset of Moon center from Sun center based on node offset
    const offsetX = 0;
    const offsetY = (hasTilt ? nodeOffsetDeg : 0) * 4.5;

    // Background sky
    ctx.fillStyle = '#050814';
    ctx.fillRect(0, 0, w, h);

    if (eclipseMode === 'solar') {
      // 1. Corona rays (if in total eclipse)
      if (eclipseInfo.type === 'TOTAL_SOLAR') {
        const coronaGrad = ctx.createRadialGradient(cx, cy, sunR * 0.9, cx, cy, sunR * 2.8);
        coronaGrad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
        coronaGrad.addColorStop(0.3, 'rgba(56, 189, 248, 0.5)');
        coronaGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
        ctx.fillStyle = coronaGrad;
        ctx.beginPath();
        ctx.arc(cx, cy, sunR * 2.8, 0, Math.PI * 2);
        ctx.fill();

        // Diamond ring glint
        ctx.beginPath();
        ctx.arc(cx + sunR * 0.9, cy - sunR * 0.4, 6, 0, Math.PI * 2);
        ctx.fillStyle = '#FFFFFF';
        ctx.shadowColor = '#FACC15';
        ctx.shadowBlur = 15;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // 2. Sun Disk (Photosphere)
      ctx.beginPath();
      ctx.arc(cx, cy, sunR, 0, Math.PI * 2);
      ctx.fillStyle = '#FACC15';
      ctx.fill();

      // 3. Moon Occulting Disk
      ctx.beginPath();
      ctx.arc(cx + offsetX, cy + offsetY, moonR, 0, Math.PI * 2);
      ctx.fillStyle = '#050814';
      ctx.fill();

      // If Annular, stroke the exposed gold ring
      if (eclipseInfo.type === 'ANNULAR_SOLAR') {
        ctx.beginPath();
        ctx.arc(cx, cy, sunR, 0, Math.PI * 2);
        ctx.strokeStyle = '#F59E0B';
        ctx.lineWidth = 3;
        ctx.stroke();
      }
    } else {
      // Lunar Eclipse: Moon passing through Earth's umbra shadow
      // Moon disk
      ctx.beginPath();
      ctx.arc(cx, cy, sunR * 0.8, 0, Math.PI * 2);
      if (eclipseInfo.type === 'TOTAL_LUNAR') {
        // Coppery Crimson Blood Moon
        ctx.fillStyle = '#991B1B';
      } else if (eclipseInfo.type === 'PARTIAL_LUNAR') {
        ctx.fillStyle = '#7F1D1D';
      } else {
        ctx.fillStyle = '#E2E8F0';
      }
      ctx.fill();
    }
  }, [subView, eclipseMode, eclipseInfo, lunarDistanceKm, nodeOffsetDeg, hasTilt]);

  // Main 3D Three.js Viewport
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#050814');

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 2000);
    camera.position.set(0, 35, 75);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;

    // Ambient & Directional Lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.2);
    scene.add(ambient);

    // ==========================================
    // 1. SOLAR SYSTEM VIEW BUILDER
    // ==========================================
    const planetMeshes: { body: any; mesh: THREE.Mesh; orbitRadius: number; speed: number; angle: number }[] = [];

    if (subView === 'system') {
      // Sun
      const sunGeo = new THREE.SphereGeometry(3.5, 48, 48);
      const sunMat = new THREE.MeshBasicMaterial({ map: getProceduralTexture('sun') });
      const sunMesh = new THREE.Mesh(sunGeo, sunMat);
      scene.add(sunMesh);

      const sunLight = new THREE.PointLight(0xffffff, 3.5, 500, 0.5);
      scene.add(sunLight);

      // Planets
      SOLAR_SYSTEM_BODIES.filter((b) => b.id !== 'sun' && b.id !== 'moon').forEach((b, idx) => {
        // Orbit radius: classroom scaled spacing
        const orbitR = scaleMode === 'classroom' ? 8 + idx * 7.5 : b.semiMajorAxis * 20;
        const radius = scaleMode === 'classroom' ? (b.type === 'gas_giant' ? 1.6 : 0.8) : (b.radius / 6371) * 0.4;

        const pGeo = new THREE.SphereGeometry(radius, 32, 32);
        const pTex = getProceduralTexture(b.id);
        const pMat = new THREE.MeshStandardMaterial({ map: pTex, roughness: 0.7 });
        const pMesh = new THREE.Mesh(pGeo, pMat);
        scene.add(pMesh);

        // Orbit ring
        const oGeo = new THREE.BufferGeometry();
        const oPoints = [];
        for (let i = 0; i <= 96; i++) {
          const theta = (i / 96) * Math.PI * 2;
          oPoints.push(new THREE.Vector3(Math.cos(theta) * orbitR, 0, Math.sin(theta) * orbitR));
        }
        oGeo.setFromPoints(oPoints);
        const oMat = new THREE.LineBasicMaterial({ color: 0x334155, transparent: true, opacity: 0.4 });
        scene.add(new THREE.Line(oGeo, oMat));

        planetMeshes.push({
          body: b,
          mesh: pMesh,
          orbitRadius: orbitR,
          speed: (1 / (b.orbitalPeriod || 1)) * 0.5,
          angle: idx * 0.8
        });
      });
    }

    // ==========================================
    // 2. STELLARIUM SKY DOME BUILDER
    // ==========================================
    if (subView === 'skydome') {
      camera.position.set(0, 0, 0.1); // Observer inside the celestial sphere
      controls.minDistance = 0.05;
      controls.maxDistance = 10;

      // 4,000+ Procedural Stars on Celestial Sphere
      const starCount = 4200;
      const starGeo = new THREE.BufferGeometry();
      const starPositions = new Float32Array(starCount * 3);
      const starColors = new Float32Array(starCount * 3);

      const spectralColors: [number, number, number][] = [
        [0.6, 0.7, 1.0], // O - Blue
        [0.7, 0.8, 1.0], // B - Deep Blue
        [0.85, 0.9, 1.0], // A - White
        [0.98, 0.98, 1.0], // F - Yellow-White
        [1.0, 0.95, 0.7], // G - Yellow (Sun-like)
        [1.0, 0.8, 0.5], // K - Orange
        [1.0, 0.45, 0.35] // M - Red
      ];

      for (let i = 0; i < starCount; i++) {
        // Uniform sphere sampling
        const u = Math.random();
        const v = Math.random();
        const theta = u * 2.0 * Math.PI;
        const phi = Math.acos(2.0 * v - 1.0);
        const r = 200;

        const x = r * Math.sin(phi) * Math.cos(theta);
        const y = r * Math.sin(phi) * Math.sin(theta);
        const z = r * Math.cos(phi);

        starPositions[i * 3] = x;
        starPositions[i * 3 + 1] = y;
        starPositions[i * 3 + 2] = z;

        const color = spectralColors[Math.floor(Math.random() * spectralColors.length)];
        starColors[i * 3] = color[0];
        starColors[i * 3 + 1] = color[1];
        starColors[i * 3 + 2] = color[2];
      }

      starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
      starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
      const starMat = new THREE.PointsMaterial({
        size: 1.2,
        vertexColors: true,
        transparent: true,
        opacity: 0.9
      });
      scene.add(new THREE.Points(starGeo, starMat));

      // Constellation Stick Figures
      if (showConstellationLines) {
        CONSTELLATIONS.forEach((c) => {
          c.lines.forEach(([s1Name, s2Name]) => {
            const s1 = BRIGHT_STARS.find((st) => st.id === s1Name);
            const s2 = BRIGHT_STARS.find((st) => st.id === s2Name);
            if (s1 && s2) {
              const p1 = radecToCartesian(s1.raHours, s1.decDeg, 195);
              const p2 = radecToCartesian(s2.raHours, s2.decDeg, 195);

              const lineGeo = new THREE.BufferGeometry().setFromPoints([
                new THREE.Vector3(...p1),
                new THREE.Vector3(...p2)
              ]);
              const lineMat = new THREE.LineBasicMaterial({
                color: 0x38bdf8,
                transparent: true,
                opacity: 0.7
              });
              scene.add(new THREE.Line(lineGeo, lineMat));
            }
          });
        });
      }
    }

    // ==========================================
    // 3. 3D ECLIPSE OBSERVATORY BUILDER
    // ==========================================
    if (subView === 'eclipse') {
      camera.position.set(0, 12, 35);

      // Sun on the left
      const sunGeo = new THREE.SphereGeometry(6, 48, 48);
      const sunMat = new THREE.MeshBasicMaterial({ map: getProceduralTexture('sun') });
      const sun = new THREE.Mesh(sunGeo, sunMat);
      sun.position.set(-30, 0, 0);
      scene.add(sun);

      // Earth at origin
      const earthGeo = new THREE.SphereGeometry(2.5, 32, 32);
      const earthMat = new THREE.MeshStandardMaterial({ map: getProceduralTexture('earth') });
      const earth = new THREE.Mesh(earthGeo, earthMat);
      earth.position.set(0, 0, 0);
      scene.add(earth);

      // Moon
      const moonGeo = new THREE.SphereGeometry(0.7, 32, 32);
      const moonMat = new THREE.MeshStandardMaterial({ map: getProceduralTexture('moon') });
      const moon = new THREE.Mesh(moonGeo, moonMat);

      // In Solar eclipse, Moon is between Sun and Earth
      // In Lunar eclipse, Earth is between Sun and Moon
      const moonX = eclipseMode === 'solar' ? -10 : 10;
      const moonY = hasTilt ? nodeOffsetDeg * 0.4 : 0;
      moon.position.set(moonX, moonY, 0);
      scene.add(moon);

      // 3D Umbra Shadow Cone (Indigo-Crimson)
      const occultingBody = eclipseMode === 'solar' ? moon : earth;
      const umbraGeo = new THREE.ConeGeometry(eclipseMode === 'solar' ? 0.7 : 2.5, 20, 32);
      const umbraMat = ShadowConeShader.createMaterial('#6366F1', 0.45);
      const umbraCone = new THREE.Mesh(umbraGeo, umbraMat);
      umbraCone.rotation.z = Math.PI / 2; // Point away from Sun along +X
      umbraCone.position.set(occultingBody.position.x + 10, occultingBody.position.y, 0);
      scene.add(umbraCone);

      // 3D Penumbra Shadow Cone (Translucent Slate)
      const penumbraGeo = new THREE.ConeGeometry(eclipseMode === 'solar' ? 2.5 : 5.0, 24, 32);
      const penumbraMat = ShadowConeShader.createMaterial('#94A3B8', 0.18);
      const penumbraCone = new THREE.Mesh(penumbraGeo, penumbraMat);
      penumbraCone.rotation.z = -Math.PI / 2;
      penumbraCone.position.set(occultingBody.position.x + 12, occultingBody.position.y, 0);
      scene.add(penumbraCone);

      const light = new THREE.DirectionalLight(0xfffbe8, 2.5);
      light.position.set(-40, 0, 0);
      scene.add(light);
    }

    // Animation Loop
    let animId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const dt = clock.getDelta();

      if (!isPaused && subView === 'system') {
        planetMeshes.forEach((p) => {
          p.angle += p.speed * dt * timeMultiplier;
          p.mesh.position.x = Math.cos(p.angle) * p.orbitRadius;
          p.mesh.position.z = Math.sin(p.angle) * p.orbitRadius;
          p.mesh.rotation.y += 0.5 * dt;
        });
      }

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
      controls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [subView, scaleMode, timeMultiplier, isPaused, eclipseMode, lunarDistanceKm, nodeOffsetDeg, hasTilt, showConstellationLines]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Top Header & Sub-View Switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1 rounded-md bg-indigo-500/20 text-indigo-400">
              <Compass className="w-4 h-4" />
            </span>
            <span className="text-xs font-mono uppercase text-indigo-400 font-bold tracking-wider">
              Astrodynamics & Observational Astronomy
            </span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-heading font-extrabold text-white">
            Solar Observatory & Sky Dome
          </h1>
        </div>

        {/* 3 Sub-View Selector */}
        <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => {
              soundEngine.playClick(600);
              setSubView('system');
            }}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
              subView === 'system'
                ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" /> 3D Solar System
          </button>
          <button
            onClick={() => {
              soundEngine.playClick(600);
              setSubView('skydome');
            }}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
              subView === 'skydome'
                ? 'bg-indigo-500/20 text-indigo-200 border border-indigo-400/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Stellarium Sky Dome
          </button>
          <button
            onClick={() => {
              soundEngine.playClick(600);
              setSubView('eclipse');
            }}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
              subView === 'eclipse'
                ? 'bg-purple-500/20 text-purple-200 border border-purple-400/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Moon className="w-3.5 h-3.5" /> 3D Eclipse Simulator
          </button>
        </div>
      </div>

      {/* Main Viewport + HUD Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main 3D Canvas Container (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Sub-view Specific Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
            {subView === 'system' && (
              <>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setScaleMode(scaleMode === 'classroom' ? 'true' : 'classroom')}
                    className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold"
                  >
                    Scale: {scaleMode === 'classroom' ? 'Classroom (Visible)' : 'True Scale (1:1)'}
                  </button>
                  <button
                    onClick={() => setIsPaused(!isPaused)}
                    className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                  >
                    {isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <div className="flex items-center gap-2 font-mono text-xs">
                  <span className="text-slate-400">Orbit Speed:</span>
                  {[0.5, 1, 5, 20].map((s) => (
                    <button
                      key={s}
                      onClick={() => setTimeMultiplier(s)}
                      className={`px-2 py-1 rounded-md text-[11px] font-bold ${
                        timeMultiplier === s ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {s}×
                    </button>
                  ))}
                </div>
              </>
            )}

            {subView === 'skydome' && (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setShowConstellationLines(!showConstellationLines)}
                  className={`py-1.5 px-3 rounded-xl text-xs font-semibold border ${
                    showConstellationLines ? 'bg-cyan-500/20 text-cyan-200 border-cyan-400/50' : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  Constellation Figures: {showConstellationLines ? 'ON' : 'OFF'}
                </button>
                <div className="flex items-center gap-2 font-mono text-xs text-slate-400">
                  <span>Observer Lat:</span>
                  <input
                    type="range"
                    min="-90"
                    max="90"
                    value={observerLat}
                    onChange={(e) => setObserverLat(parseFloat(e.target.value))}
                    className="accent-cyan-400 cursor-pointer w-20"
                  />
                  <span className="text-cyan-400 font-bold">{observerLat}°</span>
                </div>
              </div>
            )}

            {subView === 'eclipse' && (
              <div className="flex flex-wrap items-center justify-between w-full gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setEclipseMode('solar')}
                    className={`py-1.5 px-3 rounded-xl text-xs font-semibold ${
                      eclipseMode === 'solar' ? 'bg-amber-500/25 text-amber-200 border border-amber-400' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    Solar Eclipse
                  </button>
                  <button
                    onClick={() => setEclipseMode('lunar')}
                    className={`py-1.5 px-3 rounded-xl text-xs font-semibold ${
                      eclipseMode === 'lunar' ? 'bg-rose-500/25 text-rose-200 border border-rose-400' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    Lunar Eclipse
                  </button>
                </div>

                <button
                  onClick={() => setHasTilt(!hasTilt)}
                  className={`py-1.5 px-3 rounded-xl text-xs font-semibold border ${
                    hasTilt ? 'bg-purple-500/25 text-purple-200 border-purple-400/50' : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  5.145° Moon Tilt: {hasTilt ? 'ACTIVE' : 'FLAT 0°'}
                </button>
              </div>
            )}
          </div>

          {/* 3D WebGL Canvas */}
          <div className="relative w-full aspect-[16/10] min-h-[500px] rounded-2xl border border-slate-800 overflow-hidden shadow-2xl bg-slate-950">
            <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

            {/* Synced Picture-in-Picture Viewport (in Eclipse Mode) */}
            {subView === 'eclipse' && (
              <div className="absolute top-4 right-4 w-44 rounded-2xl bg-slate-950/90 backdrop-blur-md border border-slate-700 p-2.5 shadow-2xl space-y-2">
                <div className="flex items-center justify-between text-[10px] font-mono font-bold text-slate-300">
                  <span>Earth Surface View</span>
                  <span className="text-amber-400 font-bold">{eclipseInfo.coveragePercent}%</span>
                </div>
                <div className="w-full aspect-square rounded-xl bg-black border border-slate-800 overflow-hidden flex items-center justify-center">
                  <canvas ref={pipCanvasRef} width={160} height={160} className="w-full h-full" />
                </div>
                <div className="text-center font-mono text-[11px] font-bold text-cyan-300">
                  {eclipseInfo.type.replace('_', ' ')}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Telemetry & Scientific Inspector (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {subView === 'system' && (
            <div className="bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="font-heading font-extrabold text-white text-lg">{selectedBody.name}</h3>
                  <span className="text-[10px] font-mono uppercase text-cyan-400 font-semibold">{selectedBody.type}</span>
                </div>
                <div className="w-8 h-8 rounded-full" style={{ backgroundColor: selectedBody.color }} />
              </div>

              {/* Planet Selector Pills */}
              <div className="grid grid-cols-4 gap-1.5">
                {SOLAR_SYSTEM_BODIES.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => {
                      soundEngine.playClick(650);
                      setSelectedBodyId(b.id);
                    }}
                    className={`py-1 px-1.5 rounded-lg text-[11px] font-medium transition-colors ${
                      selectedBodyId === b.id
                        ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {b.name}
                  </button>
                ))}
              </div>

              {/* Physical Telemetry Grid */}
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                  <div className="text-[10px] text-slate-400 uppercase">Mean Distance</div>
                  <div className="text-cyan-400 font-bold mt-0.5">{selectedBody.semiMajorAxis} AU</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                  <div className="text-[10px] text-slate-400 uppercase">Orbital Period</div>
                  <div className="text-amber-400 font-bold mt-0.5">{selectedBody.orbitalPeriod} Yrs</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                  <div className="text-[10px] text-slate-400 uppercase">Equatorial Radius</div>
                  <div className="text-purple-400 font-bold mt-0.5">{selectedBody.radius.toLocaleString()} km</div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                  <div className="text-[10px] text-slate-400 uppercase">Axial Obliquity</div>
                  <div className="text-emerald-400 font-bold mt-0.5">{selectedBody.axialTilt}°</div>
                </div>
              </div>

              {/* Grade-Tier Adapted Description */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 leading-relaxed">
                <span className="text-[10px] font-mono text-slate-400 block mb-1 uppercase font-semibold">Scientific Overview:</span>
                {selectedBody.description[gradeTier]}
              </div>
            </div>
          )}

          {subView === 'eclipse' && (
            <div className="bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 space-y-4">
              <h3 className="font-heading font-extrabold text-white text-base">
                Analytical Shadow Geometry
              </h3>

              {/* Interactive Scrubber: Earth-Moon Distance (Perigee vs Apogee) */}
              <div>
                <div className="flex justify-between text-xs font-mono text-slate-300 mb-1">
                  <span>Moon Distance:</span>
                  <span className="text-cyan-400 font-bold">{Math.round(lunarDistanceKm).toLocaleString()} km</span>
                </div>
                <input
                  type="range"
                  min="363300"
                  max="405500"
                  step="1000"
                  value={lunarDistanceKm}
                  onChange={(e) => setLunarDistanceKm(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-0.5">
                  <span>Perigee (Total Eclipse)</span>
                  <span>Apogee (Annular Ring)</span>
                </div>
              </div>

              {/* Interactive Scrubber: Nodal Offset Angle */}
              <div>
                <div className="flex justify-between text-xs font-mono text-slate-300 mb-1">
                  <span>Offset from Node:</span>
                  <span className="text-purple-400 font-bold">{nodeOffsetDeg}°</span>
                </div>
                <input
                  type="range"
                  min="-6"
                  max="6"
                  step="0.2"
                  value={nodeOffsetDeg}
                  onChange={(e) => setNodeOffsetDeg(parseFloat(e.target.value))}
                  className="w-full accent-purple-400 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-0.5">
                  <span>-6° (Shadow Misses)</span>
                  <span>0° (Direct Hit)</span>
                  <span>+6° (Shadow Misses)</span>
                </div>
              </div>

              {/* Status Box */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-1.5">
                <div className="text-slate-400">Classified Eclipse State:</div>
                <div className="text-base font-bold text-amber-400">{eclipseInfo.type}</div>
                <div className="text-slate-400">Sun Light Obscuration: <span className="text-emerald-400 font-bold">{eclipseInfo.coveragePercent}%</span></div>
              </div>
            </div>
          )}

          {subView === 'skydome' && (
            <div className="bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 space-y-4">
              <h3 className="font-heading font-extrabold text-white text-base">
                Major Constellations
              </h3>
              <p className="text-xs text-slate-400">
                Tap constellations to register them into your Star Cadet log (+30 XP):
              </p>

              <div className="space-y-2">
                {CONSTELLATIONS.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => identifyConstellation(c.name)}
                    className="w-full text-left p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-400/60 flex items-center justify-between transition-colors"
                  >
                    <div>
                      <div className="text-xs font-bold text-slate-200">{c.name}</div>
                      <div className="text-[10px] text-slate-400">{c.englishName}</div>
                    </div>
                    <span className="text-[11px] font-mono text-cyan-400">RA {c.raHours}h / Dec {c.decDeg}°</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
