# ISRO 3D Rocket Launch & Lunar-Phases Mission — Grounded App Specification

## 1. User Request Alignment & Functional Scope
- **3D Engine & Environment (`Three.js` r128 + Custom Procedural High-Resolution Canvas Textures & Shaders)**:
  - Uses `THREE.WebGLRenderer({ logarithmicDepthBuffer: true, antialias: true })` to prevent depth-buffer Z-fighting across multi-scale astronomical scenes.
  - Surrounded by a procedural 3D Milky Way galactic band, nebula glow clouds, and a multi-layer starfield particle system (>4,000 stars with parallax depth).
  - Features directional Solar illumination (`PCFSoftShadowMap`, razor-sharp day/night terminator on the Moon, zero dark-side ambient washout) plus golden parallel solar light-ray vector arrows showing the Sun's direction (`-X` to `+X` or sun-vector aligned).
  - Includes an **"Educational Scale" vs. "True Astronomical Scale (30x Earth Diameter)"** toggle slider/switch.
- **10 Selectable Superhero / Cartoon-Archetype Astronaut Avatars**:
  - Interactive character selection hangar & live switcher with 10 distinct 3D rigged astronaut suits (built on a shared procedural 3D astronaut mesh + custom helmet/visor/cape/crest/aura geometry and colors):
    1. **Iron-Tech Crimson** (Gold faceplate, crimson titanium armor, arc-chest reactor glow)
    2. **Gotham Dark-Cowl** (Pointed tactical bat-ears helmet, matte carbon-grey suit, utility belt & cape fins)
    3. **Krypton Solar-Cape** (Cobalt-blue astro suit, crimson solar thruster cape, S-crest chest emblem)
    4. **Web-Slinger Spider** (Red-and-blue web-patterned visor suit, expressive white optic lenses)
    5. **Wakanda Vibranium** (Obsidian panther-ear helmet, glowing kinetic purple energy seams)
    6. **Saiyan Z-Fighter** (Spiky golden aura crest visor, orange-and-navy battle space armor)
    7. **Thunder Asgardian** (Winged silver helmet, storm-blue suit with electric cyan lightning particles)
    8. **Emerald Star-Lantern** (Glowing emerald ring-corps visor & green plasma jetpack trails)
    9. **Speedster Crimson-Flash** (Aerodynamic golden lightning ear-wings, scarlet velocity suit)
    10. **Toon-Verse Classic** (Cel-shaded white-and-gold retro cartoon astronaut with oversized bubble dome)
- **4 Progressive Pedagogical Stages (Playable Mission Campaign + Free-Play Sandbox)**:
  - **Stage 1: ISRO Sriharikota Rocket Launch & Ascent**:
    - Rocket stands on Second Launch Pad at **Satish Dhawan Space Centre (SDSC SHAR), Sriharikota** (India's orbital spaceport on the Andhra Pradesh east coast, launch site of Chandrayaan-1, Chandrayaan-2, and Chandrayaan-3 aboard LVM3).
    - Interactive **Ignition / Launch Sequence** button & throttle control: rocket fires dual solid strap-on boosters + core stage with volumetric particle flame plume, camera shakes, altitude climbs from 0 km through Rayleigh-blue atmosphere fading to black space, and velocity accelerates toward Earth's escape velocity (**11.2 km/s**).
    - Web Audio API synthesized rocket rumble that realistically attenuates to silence as atmospheric density drops to zero in vacuum (with HUD audio meter & mute toggle).
  - **Stage 2: EVA Spacewalk & Progressive 3D Label Discovery**:
    - Your chosen superhero astronaut deploys in EVA near the Earth-Moon system with jetpack thrusters (controllable via WASD / Arrow keys / on-screen D-pad).
    - **Progressive 3D Callout Labels (1-by-1 Unlock)**: Clicking or pressing "Unlock Next Concept Label" reveals 6 interactive 3D world-space callout pins one by one (with XP rewards and physics explanations):
      1. *Solar Parallel Rays* (Light travels from the Sun in parallel rays; always illuminates 50% of the Moon's sphere)
      2. *Terminator Line* (The razor-sharp twilight boundary between the sunlit lunar day side and dark night side, governed by surface normal dot product $\hat{N} \cdot \hat{L}$)
      3. *Tidal Locking (27.3 Days)* (The Moon's sidereal rotation period matches its 27.3-day orbital period, keeping the same near-side hemisphere facing Earth)
      4. *Lunar Maria & Highlands* (Dark basaltic plains formed by ancient volcanic flows vs. bright cratered highlands)
      5. *Perigee (363,000 km) & Apogee (405,000 km)* (Elliptical orbit with mean eccentricity $e = 0.0549$ and average distance **384,400 km**, ~30 Earth diameters)
      6. *Vacuum Sound Attenuation* (Mechanical sound waves require a medium; rocket roar vanishes above the Kármán line)
  - **Stage 3: Earth-Moon Orbital Mechanics, Axial Tilt & Eclipse Nodes**:
    - Interactive 3D orbital rings showing Earth's **23.5° axial tilt** and the Moon's **5.145° (5.14°) orbital inclination** relative to the ecliptic plane.
    - Highlights the **Ascending and Descending Line of Nodes** where the Moon's tilted orbit crosses the ecliptic plane, visually demonstrating why solar and lunar eclipses do not occur every month.
    - Side-by-side comparison readout of **Sidereal Month (27.3 days)** vs. **Synodic Month (29.5 days)**.
  - **Stage 4: Sensor-Driven Lunar Phase Lab & Gamified Phase Challenge**:
    - **Dual-Viewport Picture-in-Picture (PiP) "Earth Observer View"**: Top-right live 2D/3D synced viewport showing the exact Moon phase as seen from Earth (New Moon, Waxing Crescent, First Quarter, Waxing Gibbous, Full Moon, Waning Gibbous, Third Quarter, Waning Crescent), % illumination, lunar day (0–29.5 days), and Sun-Earth-Moon elongation angle ($0^\circ\text{–}360^\circ$).
    - **DeviceOrientation Gyroscope Sensor Controls + Calibrate Zero + Slider/Orbit Fallback**: Toggle smartphone gyroscope tilt (`alpha`, `beta`, `gamma`) to orbit the astronaut/Moon by tilting your device, with a "Recalibrate Zero" button and smooth slider/mouse/touch controls for desktop evaluators.
    - **Gamified "Phase Commander Quiz Challenge"**: Interactive mission challenges asking the student to pilot the Moon/astronaut to target phases or eclipse node alignments (e.g., *"Position the Moon for a Waxing Gibbous (~135° elongation)"*, *"Align for a First Quarter Moon (90°)"*, *"Trigger a Total Solar Eclipse at a Node (0°)"*) with live score, streak multiplier, XP badge progression, and downloadable Mission Report.

## 2. Grounded Real-World Data Inventory (Backed by NASA & ISRO Tool Outputs)
- **Launch Site**: Satish Dhawan Space Centre (SDSC SHAR), Sriharikota, Andhra Pradesh — ISRO's operational orbital spaceport with two orbital launch pads (First Launch Pad for PSLV/SSLV; Second Launch Pad for GSLV/LVM3, used for Chandrayaan-3).
- **Earth Escape Velocity**: `11.2 km/s` from Earth's surface.
- **Earth-Moon Mean Distance**: `384,400 km` (~30 Earth diameters; varies between `363,000 km` at perigee and `405,000 km` at apogee; eccentricity `0.0549`; light travel time `1.3 seconds`).
- **Moon Radius / Diameter**: Equatorial radius `~1,740 km` (`3,475 km` diameter, roughly 1/4 Earth's width).
- **Orbital Periods**: Sidereal period `27.3 days` (`655.728 hours`, synchronous with rotation due to tidal locking); Synodic period `29.5 days` (New Moon to New Moon).
- **Orbital Angles**: Earth axial tilt `23.5°`; Moon orbital inclination `5.145°` (`5.14°`) to the ecliptic plane (varying between `18.28°` and `28.58°` to Earth's equator).
