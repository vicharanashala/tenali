import React from 'react';
import { X, Award, CheckCircle2, Lock, Sparkles, RotateCcw } from 'lucide-react';
import { useCosmosStore, ALL_BADGES } from '../../store/useCosmosStore';
import { soundEngine } from '../../utils/soundEngine';

export const QuestDrawer: React.FC = () => {
  const {
    questDrawerOpen,
    toggleQuestDrawer,
    xp,
    rank,
    unlockedBadges,
    resetProgress
  } = useCosmosStore();

  if (!questDrawerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md h-full bg-[#0B1224] border-l border-slate-800 p-6 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-300">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Award className="w-5 h-5" />
              </span>
              <div>
                <h3 className="font-heading font-bold text-white text-base">Cosmic Dossier</h3>
                <p className="text-xs text-slate-400 font-mono">Rank: <span className="text-amber-400 font-bold">{rank}</span> ({xp} XP)</p>
              </div>
            </div>
            <button
              onClick={toggleQuestDrawer}
              className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Badges Shelf */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Achievements & Badges ({unlockedBadges.length} / {ALL_BADGES.length})
              </h4>
              <span className="text-[11px] font-mono text-cyan-400">
                {Math.round((unlockedBadges.length / ALL_BADGES.length) * 100)}% Complete
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {ALL_BADGES.map((b) => {
                const isUnlocked = unlockedBadges.includes(b.id);
                return (
                  <div
                    key={b.id}
                    className={`p-3 rounded-xl border transition-all ${
                      isUnlocked
                        ? 'bg-amber-500/10 border-amber-500/30 text-amber-100 shadow-sm'
                        : 'bg-slate-950/40 border-slate-800/80 text-slate-500'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`text-sm ${isUnlocked ? 'text-amber-400' : 'text-slate-600'}`}>
                        {isUnlocked ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Lock className="w-4 h-4" />}
                      </span>
                      <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800">
                        {b.category}
                      </span>
                    </div>
                    <div className="font-semibold text-xs text-slate-200">{b.name}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5 leading-snug line-clamp-2">{b.description}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Daily Inquiry Objectives */}
          <div className="mt-6">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Active Research Quests
            </h4>
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-medium text-slate-200 block">Cut Gravity to Zero Mid-Orbit</span>
                  <span className="text-[10px] text-slate-400">Page 2 Native Vector Lab</span>
                </div>
                <span className="font-mono text-amber-400 font-bold text-xs">+30 XP</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-medium text-slate-200 block">Achieve LEO Circular Insertion</span>
                  <span className="text-[10px] text-slate-400">Page 4 Orbital Sandbox Mission 1</span>
                </div>
                <span className="font-mono text-amber-400 font-bold text-xs">+100 XP</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer with Reset Option */}
        <div className="pt-6 border-t border-slate-800 mt-6">
          <button
            onClick={() => {
              if (window.confirm('Reset all Cosmos Lab XP, ranks, and unlocked badges?')) {
                soundEngine.playWarning();
                resetProgress();
              }
            }}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-medium transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset Local Progress
          </button>
        </div>
      </div>
    </div>
  );
};
