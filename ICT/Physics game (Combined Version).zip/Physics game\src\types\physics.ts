export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface CelestialBody {
  id: string;
  name: string;
  mass: number; // in kg or scaled sim units
  radius: number; // in km or scaled sim units
  color: string;
  semiMajorAxis: number; // in AU
  eccentricity: number;
  inclination: number; // in degrees
  orbitalPeriod: number; // in Earth years or days
  rotationPeriod: number; // in Earth hours
  axialTilt: number; // in degrees
  description: Record<string, string>; // per tier
  textureKey?: string;
  type: 'star' | 'rocky' | 'gas_giant' | 'ice_giant' | 'moon' | 'dwarf';
  atmosphereColor?: string;
  rings?: {
    innerRadius: number;
    outerRadius: number;
    color: string;
  };
}

export interface OrbitalElements {
  semiMajorAxis: number; // a
  eccentricity: number;  // e
  inclination: number;   // i (deg)
  longitudeOfAscendingNode: number; // Omega (deg)
  argumentOfPeriapsis: number; // omega (deg)
  meanAnomalyAtEpoch: number; // M0 (deg)
  periodDays: number;
}

export interface PlanetLayer {
  name: string;
  depthRangeKm: string;
  state: string; // 'Solid', 'Liquid', 'Supercritical fluid', etc.
  composition: string;
  density: string; // e.g. "12.8 - 13.1 g/cm³"
  temperature: string; // e.g. "5,400 °C"
  pressure: string; // e.g. "330 - 360 GPa"
  color: string;
  thicknessFraction: number; // normalized 0..1 for rendering wedge
  keyFact: Record<string, string>; // per tier
}

export interface MissionSpec {
  id: string;
  title: string;
  tier: '6-8' | '9-10' | '11-12' | 'all';
  briefing: string;
  objective: string;
  initialState: {
    r: number; // km
    v: number; // km/s
    altitudeKm: number;
  };
  targetConditions: {
    minPeriapsisKm?: number;
    maxPeriapsisKm?: number;
    minApoapsisKm?: number;
    maxApoapsisKm?: number;
    targetPeriodHours?: number;
    periodToleranceHours?: number;
    maxEccentricity?: number;
    minEccentricity?: number;
    minSpeedKms?: number;
    maxSpeedKms?: number;
    maxPerigeeAltitudeKm?: number; // for re-entry
  };
  hints: string[];
  xpReward: number;
}
