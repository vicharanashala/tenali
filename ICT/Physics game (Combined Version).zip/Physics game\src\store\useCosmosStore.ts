﻿import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { GradeTier } from '../types/curriculum';
import { RankTitle, Badge, TutorialStep } from '../types/gameState';
import { soundEngine } from '../utils/soundEngine';

export const ALL_BADGES: Badge[] = [
  { id: 'flight_certified', name: 'Flight Certified', description: 'Complete Stage 0 Flight School Tutorial', icon: 'Award', category: 'onboarding' },
  { id: 'newtons_heir', name: "Newton's Heir", description: 'Complete Chapter 1 and trigger Gravity-OFF Inertia Experiment', icon: 'Compass', category: 'physics' },
  { id: 'keplers_apprentice', name: "Kepler's Apprentice", description: 'Verify Equal Areas in Equal Times in Sim Lab', icon: 'Orbit', category: 'physics' },
  { id: 'umbra_hunter', name: 'Umbra Hunter', description: 'Witness Total Solar, Annular, and Total Lunar Eclipses', icon: 'Moon', category: 'astronomy' },
  { id: 'stargazer', name: 'Stargazer', description: 'Identify 3 Constellations in Earth Surface Sky View', icon: 'Sparkles', category: 'astronomy' },
  { id: 'core_geologist', name: 'Core Geologist', description: 'Inspect all interior layers of Earth and Jupiter', icon: 'Layers', category: 'physics' },
  { id: 'heavy_lifter', name: 'Heavy Lifter', description: 'Compare jump height across Moon, Mars, Earth, and Jupiter', icon: 'Activity', category: 'physics' },
  { id: 'orbital_engineer', name: 'Orbital Engineer', description: 'Complete 4+ Orbital Sandbox Missions', icon: 'Rocket', category: 'engineering' },
  { id: 'hohmann_master', name: 'Hohmann Master', description: 'Execute the Earth-to-Mars interplanetary transfer mission', icon: 'Navigation', category: 'engineering' },
  { id: 'zero_misconception', name: 'Zero-Misconception Streak', description: 'Score 100% on 3 consecutive POE checkpoints', icon: 'Zap', category: 'physics' }
];

export function getRankFromXP(xp: number): RankTitle {
  if (xp >= 2500) return 'Chief Astrophysicist';
  if (xp >= 1500) return 'Solar Cartographer';
  if (xp >= 800) return 'Mission Specialist';
  if (xp >= 300) return 'Orbital Pilot';
  return 'Star Cadet';
}

interface CosmosState {
  xp: number;
  rank: RankTitle;
  gradeTier: GradeTier;
  tutorialCompleted: boolean;
  tutorialCurrentStep: TutorialStep;
  voiceCaptions: boolean;
  isMuted: boolean;
  activeTab: 'academy' | 'simlab' | 'observatory' | 'materials' | 'space_hub';
  questDrawerOpen: boolean;
  unlockedBadges: string[];
  completedChapters: string[];
  completedMissions: string[];
  poeStreak: number;
  visitedEclipses: {
    totalSolar: boolean;
    annularSolar: boolean;
    totalLunar: boolean;
  };
  identifiedConstellations: string[];
  inspectedLayers: Record<string, string[]>;
  comparedJumpWorlds: string[];

  // Toast notifications for XP / Badges
  recentAlert: { title: string; subtitle: string; xp?: number } | null;

  // Actions
  setGradeTier: (tier: GradeTier) => void;
  setActiveTab: (tab: 'academy' | 'simlab' | 'observatory' | 'materials' | 'space_hub') => void;
  addXP: (amount: number, reason?: string) => void;
  unlockBadge: (badgeId: string) => void;
  setTutorialStep: (step: TutorialStep) => void;
  completeTutorial: () => void;
  toggleMute: () => void;
  toggleVoiceCaptions: () => void;
  toggleQuestDrawer: () => void;
  clearAlert: () => void;
  recordPoeAnswer: (correct: boolean) => void;
  completeChapter: (chapterId: string) => void;
  completeMission: (missionId: string) => void;
  recordEclipseVisit: (type: 'totalSolar' | 'annularSolar' | 'totalLunar') => void;
  identifyConstellation: (id: string) => void;
  inspectLayer: (planetId: string, layerName: string) => void;
  compareJumpWorld: (worldId: string) => void;
  resetProgress: () => void;
}

export const useCosmosStore = create<CosmosState>()(
  persist(
    (set, get) => ({
      xp: 0,
      rank: 'Star Cadet',
      gradeTier: '9-10',
      tutorialCompleted: false,
      tutorialCurrentStep: 1,
      voiceCaptions: false,
      isMuted: false,
      activeTab: 'academy',
      questDrawerOpen: false,
      unlockedBadges: [],
      completedChapters: [],
      completedMissions: [],
      poeStreak: 0,
      visitedEclipses: {
        totalSolar: false,
        annularSolar: false,
        totalLunar: false
      },
      identifiedConstellations: [],
      inspectedLayers: {},
      comparedJumpWorlds: [],
      recentAlert: null,

      setGradeTier: (tier) => {
        soundEngine.playClick(900);
        set({ gradeTier: tier });
      },

      setActiveTab: (tab) => {
        soundEngine.playClick(600);
        set({ activeTab: tab });
      },

      addXP: (amount, reason) => {
        const currentXP = get().xp;
        const newXP = currentXP + amount;
        const oldRank = get().rank;
        const newRank = getRankFromXP(newXP);

        soundEngine.playOrbitLock();

        if (oldRank !== newRank) {
          soundEngine.playVictory();
        }

        set({
          xp: newXP,
          rank: newRank,
          recentAlert: {
            title: reason || `+${amount} XP Earned!`,
            subtitle: oldRank !== newRank ? `Rank Promoted to ${newRank}!` : `Total XP: ${newXP}`,
            xp: amount
          }
        });
      },

      unlockBadge: (badgeId) => {
        const state = get();
        if (state.unlockedBadges.includes(badgeId)) return;

        const badge = ALL_BADGES.find(b => b.id === badgeId);
        if (!badge) return;

        soundEngine.playVictory();
        set({
          unlockedBadges: [...state.unlockedBadges, badgeId],
          recentAlert: {
            title: `Badge Unlocked: ${badge.name}!`,
            subtitle: badge.description,
            xp: 50
          },
          xp: state.xp + 50,
          rank: getRankFromXP(state.xp + 50)
        });
      },

      setTutorialStep: (step) => {
        soundEngine.playClick(750);
        set({ tutorialCurrentStep: step });
      },

      completeTutorial: () => {
        soundEngine.playVictory();
        set({
          tutorialCompleted: true,
          tutorialCurrentStep: 5
        });
        get().unlockBadge('flight_certified');
        get().addXP(100, 'Flight School Graduate');
      },

      toggleMute: () => {
        const nextMute = !get().isMuted;
        soundEngine.setMuted(nextMute);
        set({ isMuted: nextMute });
      },

      toggleVoiceCaptions: () => {
        soundEngine.playClick(600);
        set((s) => ({ voiceCaptions: !s.voiceCaptions }));
      },

      toggleQuestDrawer: () => {
        soundEngine.playClick(700);
        set((s) => ({ questDrawerOpen: !s.questDrawerOpen }));
      },

      clearAlert: () => set({ recentAlert: null }),

      recordPoeAnswer: (correct) => {
        const state = get();
        if (correct) {
          const newStreak = state.poeStreak + 1;
          set({ poeStreak: newStreak });
          if (newStreak >= 3) {
            get().unlockBadge('zero_misconception');
          }
        } else {
          set({ poeStreak: 0 });
        }
      },

      completeChapter: (chapterId) => {
        const state = get();
        if (!state.completedChapters.includes(chapterId)) {
          set({ completedChapters: [...state.completedChapters, chapterId] });
          get().addXP(150, `Chapter ${chapterId.replace('ch', '')} Completed`);
        }
      },

      completeMission: (missionId) => {
        const state = get();
        if (!state.completedMissions.includes(missionId)) {
          const next = [...state.completedMissions, missionId];
          set({ completedMissions: next });
          if (next.length >= 4) {
            get().unlockBadge('orbital_engineer');
          }
          if (missionId === 'm4_hohmann_mars') {
            get().unlockBadge('hohmann_master');
          }
        }
      },

      recordEclipseVisit: (type) => {
        const state = get();
        const visited = { ...state.visitedEclipses, [type]: true };
        set({ visitedEclipses: visited });
        if (visited.totalSolar && visited.annularSolar && visited.totalLunar) {
          get().unlockBadge('umbra_hunter');
        }
      },

      identifyConstellation: (id) => {
        const state = get();
        if (!state.identifiedConstellations.includes(id)) {
          const updated = [...state.identifiedConstellations, id];
          set({ identifiedConstellations: updated });
          get().addXP(30, `Constellation Identified: ${id}`);
          if (updated.length >= 3) {
            get().unlockBadge('stargazer');
          }
        }
      },

      inspectLayer: (planetId, layerName) => {
        const state = get();
        const currentLayers = state.inspectedLayers[planetId] || [];
        if (!currentLayers.includes(layerName)) {
          const updated = {
            ...state.inspectedLayers,
            [planetId]: [...currentLayers, layerName]
          };
          set({ inspectedLayers: updated });

          // Check if inspected all 4 layers of Earth and Jupiter
          const earthLayers = updated['earth'] || [];
          const jupiterLayers = updated['jupiter'] || [];
          if (earthLayers.length >= 4 && jupiterLayers.length >= 4) {
            get().unlockBadge('core_geologist');
          }
        }
      },

      compareJumpWorld: (worldId) => {
        const state = get();
        if (!state.comparedJumpWorlds.includes(worldId)) {
          const next = [...state.comparedJumpWorlds, worldId];
          set({ comparedJumpWorlds: next });
          const required = ['moon', 'mars', 'earth', 'jupiter'];
          if (required.every(w => next.includes(w))) {
            get().unlockBadge('heavy_lifter');
          }
        }
      },

      resetProgress: () => {
        set({
          xp: 0,
          rank: 'Star Cadet',
          tutorialCompleted: false,
          tutorialCurrentStep: 1,
          unlockedBadges: [],
          completedChapters: [],
          completedMissions: [],
          poeStreak: 0,
          visitedEclipses: { totalSolar: false, annularSolar: false, totalLunar: false },
          identifiedConstellations: [],
          inspectedLayers: {},
          comparedJumpWorlds: []
        });
      }
    }),
    {
      name: 'cosmos_lab_v1'
    }
  )
);
