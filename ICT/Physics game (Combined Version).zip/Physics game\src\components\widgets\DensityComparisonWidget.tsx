import React, { useState } from 'react';
import { soundEngine } from '../../utils/soundEngine';

interface MaterialItem {
  name: string;
  density: number; // g/cm³
  color: string;
  description: string;
}

const MATERIALS: MaterialItem[] = [
  { name: 'Iron Core Metal', density: 13.0, color: '#EF4444', description: 'Deep planetary inner core' },
  { name: 'Earth Average', density: 5.515, color: '#38BDF8', description: 'Differentiated rocky planet' },
  { name: 'Silicate Crust Rock', density: 2.8, color: '#A855F7', description: 'Continental granite & basalt' },
  { name: 'Liquid Water', density: 1.0, color: '#0284C7', description: 'Reference baseline standard' },
  { name: 'Saturn Average', density: 0.687, color: '#EAB308', description: 'Gas giant (floats in water!)' },
];

export const DensityComparisonWidget: React.FC = () => {
  const [selectedIdx, setSelectedIdx] = useState<number>(4); // Saturn

  const selected = MATERIALS[selectedIdx];
  const floats = selected.density < 1.0;

  const handleSelect = (idx: number) => {
    soundEngine.playClick(600 + idx * 100);
    setSelectedIdx(idx);
  };

  return (
    <div className="flex flex-col items-center w-full h-full bg-slate-950/60 p-3 rounded-xl border border-slate-800">
      <div className="w-full flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Planetary Density Tank</span>
        <span className={`text-xs font-mono font-bold ${floats ? 'text-amber-400' : 'text-cyan-400'}`}>
          {floats ? '✨ Floats in Water (ρ < 1.0)' : '⬇ Sinks to Bottom (ρ > 1.0)'}
        </span>
      </div>

      {/* Flotation Tank SVG */}
      <div className="w-full max-w-[340px] aspect-[16/9] bg-slate-900/80 rounded-xl border border-slate-800 relative overflow-hidden flex items-center justify-center p-2">
        <svg viewBox="0 0 320 150" className="w-full h-full">
          <defs>
            <linearGradient id="waterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="rgba(56, 189, 248, 0.4)" />
              <stop offset="100%" stopColor="rgba(2, 132, 199, 0.7)" />
            </linearGradient>
          </defs>

          {/* Water Surface and Tank */}
          <rect x="20" y="45" width="280" height="95" fill="url(#waterGrad)" rx="4" />
          <line x1="20" y1="45" x2="300" y2="45" stroke="#38BDF8" strokeWidth="2" strokeDasharray="4 2" />
          <text x="30" y="60" fill="#E0F2FE" fontSize="10" fontFamily="monospace">Liquid Water (ρ = 1.00 g/cm³)</text>

          {/* Floating or Sunk Object */}
          {(() => {
            const sphereY = floats ? 35 : 120;
            return (
              <g className="transition-all duration-500 ease-out" transform={`translate(160, ${sphereY})`}>
                <circle cx="0" cy="0" r="22" fill={selected.color} stroke="#FFFFFF" strokeWidth="1.5" />
                <text x="0" y="4" textAnchor="middle" fill="#FFFFFF" fontSize="9" fontWeight="bold" fontFamily="monospace">
                  {selected.density}
                </text>
                <text x="0" y="-28" textAnchor="middle" fill={selected.color} fontSize="10" fontWeight="bold">
                  {selected.name}
                </text>
              </g>
            );
          })()}
        </svg>
      </div>

      {/* Selector Pills */}
      <div className="grid grid-cols-5 gap-1 w-full mt-2">
        {MATERIALS.map((mat, idx) => (
          <button
            key={mat.name}
            onClick={() => handleSelect(idx)}
            className={`py-1 px-1 rounded text-[10px] font-mono font-medium transition-colors text-center truncate ${
              selectedIdx === idx
                ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            {mat.name.split(' ')[0]}
          </button>
        ))}
      </div>

      {/* Readout */}
      <div className="w-full mt-2 p-2 rounded-lg bg-slate-900 border border-slate-800 font-mono text-xs flex justify-between items-center">
        <span className="text-slate-400">{selected.description}</span>
        <span className="text-amber-400 font-bold">{selected.density.toFixed(3)} g/cm³</span>
      </div>
    </div>
  );
};
