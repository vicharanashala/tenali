import React, { useState, useEffect, useRef } from 'react';
import {
  FlaskConical,
  ExternalLink,
  Maximize2,
  Minimize2,
  RotateCcw,
  Play,
  Pause,
  AlertTriangle,
  Sparkles,
  HelpCircle,
  Eye,
  Sliders,
  CheckCircle2,
  Layers
} from 'lucide-react';
import { PHET_SIMULATIONS, PhETSimMeta, PhETInquiryTask } from '../data/phetWorksheetsData';
import { SymplecticNBodySystem, SimBody } from '../physics/nBodyIntegrator';
import { useCosmosStore } from '../store/useCosmosStore';
import { soundEngine } from '../utils/soundEngine';
import { POECard } from '../components/shared/POECard';
import { VectorLegend } from '../components/shared/VectorLegend';

export const SimLabPage: React.FC = () => {
  const { gradeTier, addXP, unlockBadge } = useCosmosStore();
  const [labMode, setLabMode] = useState<'phet' | 'native'>('native');

  // PhET Mode State
  const [activePhetIdx, setActivePhetIdx] = useState<number>(0);
  const [inquiryDrawerOpen, setInquiryDrawerOpen] = useState<boolean>(true);
  const [iframeError, setIframeError] = useState<boolean>(false);
  const [completedPhetTasks, setCompletedPhetTasks] = useState<string[]>([]);
  const [activeVerificationTask, setActiveVerificationTask] = useState<PhETInquiryTask | null>(null);

  // Native Lab State
  const [preset, setPreset] = useState<string>('sun_earth');
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [showVectors, setShowVectors] = useState<boolean>(true);
  const [showKeplerWedges, setShowKeplerWedges] = useState<boolean>(false);
  const [isGravityCut, setIsGravityCut] = useState<boolean>(false);
  const [showCutGravityPOE, setShowCutGravityPOE] = useState<boolean>(false);
  const [energyData, setEnergyData] = useState<{ k: number; u: number; total: number; drift: number }>({
    k: 0,
    u: 0,
    total: 0,
    drift: 0
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const nBodySystemRef = useRef<SymplecticNBodySystem>(new SymplecticNBodySystem(1.0, 0.05));
  const wedgesRef = useRef<{ pts: { x: number; y: number }[]; color: string }[]>([]);
  const lastWedgeTime = useRef<number>(0);

  const activePhet = PHET_SIMULATIONS[activePhetIdx];

  // Initialize Native Presets
  const loadPreset = (presetKey: string) => {
    soundEngine.playClick(700);
    setPreset(presetKey);
    setIsGravityCut(false);
    wedgesRef.current = [];

    const sys = nBodySystemRef.current;
    sys.cutGravity(false);

    if (presetKey === 'sun_earth') {
      // Circular orbit
      sys.G = 1.0;
      sys.setBodies([
        {
          id: 'sun',
          name: 'Sun',
          mass: 1000,
          radius: 18,
          color: '#FACC15',
          x: 0,
          y: 0,
          z: 0,
          vx: 0,
          vy: 0,
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: [],
          isFixed: true
        },
        {
          id: 'earth',
          name: 'Earth',
          mass: 1,
          radius: 7,
          color: '#38BDF8',
          x: 130,
          y: 0,
          z: 0,
          vx: 0,
          vy: Math.sqrt((1.0 * 1000) / 130), // ~2.77
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: []
        }
      ]);
    } else if (presetKey === 'comet') {
      // High-eccentricity orbit
      sys.G = 1.0;
      sys.setBodies([
        {
          id: 'sun',
          name: 'Sun',
          mass: 1000,
          radius: 18,
          color: '#FACC15',
          x: 0,
          y: 0,
          z: 0,
          vx: 0,
          vy: 0,
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: [],
          isFixed: true
        },
        {
          id: 'comet',
          name: 'Halley Comet',
          mass: 0.1,
          radius: 5,
          color: '#A855F7',
          x: 180,
          y: 0,
          z: 0,
          vx: 0,
          vy: 1.35, // much slower at aphelion -> high e ~ 0.72
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: []
        }
      ]);
    } else if (presetKey === 'binary') {
      // Binary Star Waltz
      sys.G = 1.0;
      sys.setBodies([
        {
          id: 'star1',
          name: 'Star Alpha',
          mass: 500,
          radius: 14,
          color: '#F97316',
          x: -60,
          y: 0,
          z: 0,
          vx: 0,
          vy: -1.45,
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: []
        },
        {
          id: 'star2',
          name: 'Star Beta',
          mass: 500,
          radius: 14,
          color: '#38BDF8',
          x: 60,
          y: 0,
          z: 0,
          vx: 0,
          vy: 1.45,
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: []
        }
      ]);
    } else if (presetKey === 'slingshot') {
      // Gravity Assist
      sys.G = 1.0;
      sys.setBodies([
        {
          id: 'sun',
          name: 'Sun',
          mass: 1200,
          radius: 20,
          color: '#FACC15',
          x: 0,
          y: 0,
          z: 0,
          vx: 0,
          vy: 0,
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: [],
          isFixed: true
        },
        {
          id: 'jupiter',
          name: 'Jupiter',
          mass: 120,
          radius: 12,
          color: '#EA580C',
          x: 140,
          y: 0,
          z: 0,
          vx: 0,
          vy: 2.9,
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: []
        },
        {
          id: 'probe',
          name: 'Voyager Probe',
          mass: 0.01,
          radius: 4,
          color: '#10B981',
          x: 100,
          y: -120,
          z: 0,
          vx: 1.4,
          vy: 2.8,
          vz: 0,
          ax: 0,
          ay: 0,
          az: 0,
          trail: []
        }
      ]);
    }
  };

  useEffect(() => {
    loadPreset('sun_earth');
  }, []);

  // Native Simulation 60 FPS Loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let simTimer = 0;

    const render = () => {
      animId = requestAnimationFrame(render);
      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2;

      const sys = nBodySystemRef.current;

      if (isRunning) {
        sys.step(0.4, 8, 250);
        simTimer += 0.016;

        // Kepler wedge recording every 0.6 seconds
        if (showKeplerWedges && preset === 'comet' && simTimer - lastWedgeTime.current > 0.6) {
          lastWedgeTime.current = simTimer;
          const comet = sys.bodies.find((b) => b.id === 'comet');
          const sun = sys.bodies.find((b) => b.id === 'sun');
          if (comet && sun) {
            const nextColor = wedgesRef.current.length % 2 === 0 ? 'rgba(168, 85, 247, 0.35)' : 'rgba(56, 189, 248, 0.35)';
            wedgesRef.current.push({
              pts: [
                { x: cx + sun.x, y: cy + sun.y },
                { x: cx + comet.x, y: cy + comet.y }
              ],
              color: nextColor
            });
            if (wedgesRef.current.length > 14) {
              wedgesRef.current.shift();
            }
          }
        }

        const e = sys.computeEnergy();
        setEnergyData({
          k: e.kinetic,
          u: e.potential,
          total: e.total,
          drift: e.driftPercent
        });
      }

      // Draw background
      ctx.fillStyle = '#050814';
      ctx.fillRect(0, 0, w, h);

      // Subtle coordinate grid
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.08)';
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Draw Kepler Wedges if enabled
      if (showKeplerWedges && wedgesRef.current.length > 1) {
        for (let i = 0; i < wedgesRef.current.length - 1; i++) {
          const w1 = wedgesRef.current[i];
          const w2 = wedgesRef.current[i + 1];
          ctx.beginPath();
          ctx.moveTo(w1.pts[0].x, w1.pts[0].y); // Sun
          ctx.lineTo(w1.pts[1].x, w1.pts[1].y); // Comet at t1
          ctx.lineTo(w2.pts[1].x, w2.pts[1].y); // Comet at t2
          ctx.closePath();
          ctx.fillStyle = w1.color;
          ctx.fill();
        }
      }

      // Draw bodies & trails
      sys.bodies.forEach((b) => {
        const bx = cx + b.x;
        const by = cy + b.y;

        // Trail
        if (b.trail.length > 1) {
          ctx.beginPath();
          b.trail.forEach((pt, idx) => {
            if (idx === 0) ctx.moveTo(cx + pt.x, cy + pt.y);
            else ctx.lineTo(cx + pt.x, cy + pt.y);
          });
          ctx.strokeStyle = b.color;
          ctx.lineWidth = 1.5;
          ctx.setLineDash([2, 3]);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        // Body sphere
        ctx.beginPath();
        ctx.arc(bx, by, b.radius, 0, Math.PI * 2);
        ctx.fillStyle = b.color;
        ctx.shadowColor = b.color;
        ctx.shadowBlur = b.isFixed ? 20 : 8;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Body label
        ctx.fillStyle = '#F8FAFC';
        ctx.font = '10px monospace';
        ctx.fillText(b.name, bx + b.radius + 4, by + 3);

        // Vectors (if enabled)
        if (showVectors && !b.isFixed) {
          // Velocity Vector (Electric Cyan #38BDF8)
          const vScale = 16;
          ctx.beginPath();
          ctx.moveTo(bx, by);
          ctx.lineTo(bx + b.vx * vScale, by + b.vy * vScale);
          ctx.strokeStyle = '#38BDF8';
          ctx.lineWidth = 2.5;
          ctx.stroke();

          // Gravity Force Vector (Solar Amber #F59E0B)
          const fScale = 1200;
          ctx.beginPath();
          ctx.moveTo(bx, by);
          ctx.lineTo(bx + b.ax * fScale, by + b.ay * fScale);
          ctx.strokeStyle = '#F59E0B';
          ctx.lineWidth = 2.5;
          ctx.stroke();
        }
      });
    };

    render();

    return () => cancelAnimationFrame(animId);
  }, [isRunning, showVectors, showKeplerWedges, preset]);

  // Handle Cut Gravity Button
  const handleCutGravityClick = () => {
    soundEngine.playWarning();
    setShowCutGravityPOE(true);
  };

  const executeCutGravity = () => {
    setShowCutGravityPOE(false);
    setIsGravityCut(true);
    nBodySystemRef.current.cutGravity(true);
    unlockBadge('newtons_heir');
    addXP(50, 'Newton Inertia Experiment Triggered');
  };

  const verifyKeplerEqualAreas = () => {
    soundEngine.playVictory();
    setShowKeplerWedges(true);
    unlockBadge('keplers_apprentice');
    addXP(50, 'Kepler Equal Areas Verified');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Top Header & Mode Toggle */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1 rounded-md bg-purple-500/20 text-purple-400">
              <FlaskConical className="w-4 h-4" />
            </span>
            <span className="text-xs font-mono uppercase text-purple-400 font-bold tracking-wider">
              Research-Grade Physics Engine
            </span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-heading font-extrabold text-white">
            Virtual Physics Lab
          </h1>
        </div>

        {/* Mode Segmented Switcher */}
        <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => {
              soundEngine.playClick(600);
              setLabMode('native');
            }}
            className={`py-1.5 px-4 rounded-lg text-xs font-bold transition-all ${
              labMode === 'native'
                ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Native Symplectic Lab (60 FPS)
          </button>
          <button
            onClick={() => {
              soundEngine.playClick(600);
              setLabMode('phet');
            }}
            className={`py-1.5 px-4 rounded-lg text-xs font-bold transition-all ${
              labMode === 'phet'
                ? 'bg-indigo-500/20 text-indigo-200 border border-indigo-400/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Official PhET HTML5 Suite
          </button>
        </div>
      </div>

      {/* MODE B: NATIVE SYMPLECTIC ORBIT LAB */}
      {labMode === 'native' && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
            {/* Presets */}
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { id: 'sun_earth', label: 'Sun–Earth Circular' },
                { id: 'comet', label: 'Eccentric Comet (e = 0.72)' },
                { id: 'binary', label: 'Binary Star Waltz' },
                { id: 'slingshot', label: 'Jupiter Gravity Assist' }
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => loadPreset(p.id)}
                  className={`py-1.5 px-3 rounded-lg text-xs font-medium transition-colors ${
                    preset === p.id
                      ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Teaching Action Buttons */}
            <div className="flex items-center gap-2">
              {/* Play / Pause */}
              <button
                onClick={() => {
                  soundEngine.playClick(600);
                  setIsRunning(!isRunning);
                }}
                className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors"
                title={isRunning ? 'Pause Simulation' : 'Resume Simulation'}
              >
                {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              </button>

              {/* Vectors Toggle */}
              <button
                onClick={() => {
                  soundEngine.playClick(700);
                  setShowVectors(!showVectors);
                }}
                className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl border text-xs font-semibold transition-colors ${
                  showVectors ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40' : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                <Eye className="w-3.5 h-3.5" /> Vectors
              </button>

              {/* Kepler Equal-Area Sweeper */}
              <button
                onClick={verifyKeplerEqualAreas}
                className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl border text-xs font-semibold transition-colors ${
                  showKeplerWedges ? 'bg-purple-500/25 text-purple-200 border-purple-400/50' : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                <Layers className="w-3.5 h-3.5" /> Kepler Sweeper
              </button>

              {/* CUT GRAVITY (G = 0) Emergency Switch */}
              <button
                onClick={handleCutGravityClick}
                className="flex items-center gap-1.5 py-1.5 px-3.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-all shadow-md shadow-rose-500/10"
              >
                <AlertTriangle className="w-3.5 h-3.5" /> CUT GRAVITY (G = 0)
              </button>

              {/* Reset */}
              <button
                onClick={() => loadPreset(preset)}
                className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors"
                title="Reset Scene"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive 2D/3D Canvas Viewport */}
          <div className="relative w-full aspect-[16/9] max-h-[560px] rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
            <canvas ref={canvasRef} width={960} height={540} className="w-full h-full" />

            {/* Live Energy HUD overlay */}
            <div className="absolute top-3 left-3 p-3 rounded-xl bg-slate-950/80 backdrop-blur-md border border-slate-800 text-xs font-mono space-y-1">
              <div className="text-[10px] uppercase text-slate-400 font-bold mb-1">Symplectic Energy Conservation:</div>
              <div className="flex items-center justify-between gap-4">
                <span className="text-emerald-400">Kinetic (K):</span>
                <span>{energyData.k.toFixed(1)} J</span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <span className="text-rose-400">Potential (U):</span>
                <span>{energyData.u.toFixed(1)} J</span>
              </div>
              <div className="flex items-center justify-between gap-4 border-t border-slate-800 pt-1">
                <span className="text-cyan-400 font-bold">Total Energy (E):</span>
                <span className="font-bold">{energyData.total.toFixed(1)} J</span>
              </div>
              <div className="text-[10px] text-slate-500">
                Drift: {energyData.drift.toFixed(3)}% (Velocity-Verlet)
              </div>
            </div>

            {/* Gravity Cut Notification Banner */}
            {isGravityCut && (
              <div className="absolute top-3 right-3 p-3 rounded-xl bg-rose-500/20 backdrop-blur-md border border-rose-500/40 text-rose-200 text-xs font-semibold flex items-center gap-2 animate-pulse">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>GRAVITY OFF: Inertial Straight-Line Motion Active</span>
              </div>
            )}
          </div>

          {/* POE Modal for Cutting Gravity */}
          {showCutGravityPOE && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
              <div className="max-w-md w-full">
                <POECard
                  prompt={{
                    id: 'poe_cut_gravity',
                    question: 'If you suddenly cut the Sun’s gravity to ZERO right now, what will happen to Earth?',
                    options: [
                      { id: 'opt1', text: 'It will stop dead in space immediately.', explanation: { '6-8': 'Objects have inertia—they don’t stop without friction!', '9-10': 'Newton’s 1st Law: objects maintain their current state of motion.', '11-12': 'Momentum p is conserved when external force F_net = 0.' } },
                      { id: 'opt2', text: 'It will fly off along a straight line tangent to its orbit.', isCorrect: true, explanation: { '6-8': 'Exactly! With no gravity pulling it into a curve, it flies straight!', '9-10': 'Correct! The velocity vector remains constant in magnitude and direction.', '11-12': 'Precise. With F_g = 0, d²r/dt² = 0, producing uniform rectilinear inertial motion.' } },
                      { id: 'opt3', text: 'It will spiral outwards into deep space.', explanation: { '6-8': 'A spiral requires a continuous force curving the path!', '9-10': 'Spirals require non-zero angular acceleration.', '11-12': 'Rectilinear motion follows when net force is zero.' } }
                    ],
                    observeInstruction: 'Click continue to witness gravity drop to zero and observe Earth’s straight velocity vector.',
                    explanation: {
                      '6-8': 'Without gravity constantly pulling Earth inward, inertia takes over and it flies straight along its current speed and direction!',
                      '9-10': 'Newton’s First Law: an object in motion continues in uniform straight-line motion unless acted upon by an external net force.',
                      '11-12': 'The centripetal force F_c = -G M m / r² vanishes instantaneously, leaving the equation of motion d(m v)/dt = 0.'
                    }
                  }}
                  onComplete={executeCutGravity}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODE A: OFFICIAL PHET HTML5 SIMULATION SUITE */}
      {labMode === 'phet' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Main PhET iFrame (8 cols) */}
          <div className="lg:col-span-8 space-y-4">
            {/* PhET Sim Selector Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 p-2 rounded-xl bg-slate-900 border border-slate-800">
              {PHET_SIMULATIONS.map((sim, idx) => (
                <button
                  key={sim.id}
                  onClick={() => {
                    soundEngine.playClick(650);
                    setActivePhetIdx(idx);
                    setIframeError(false);
                  }}
                  className={`py-1.5 px-3 rounded-lg text-xs font-semibold transition-colors ${
                    activePhetIdx === idx
                      ? 'bg-indigo-500/30 text-indigo-200 border border-indigo-400/50'
                      : 'bg-slate-800/80 text-slate-400 hover:text-white'
                  }`}
                >
                  {sim.title}
                </button>
              ))}
            </div>

            {/* iFrame Container */}
            <div className="relative w-full aspect-[16/10] min-h-[500px] rounded-2xl border border-slate-800 overflow-hidden bg-slate-950">
              {!iframeError ? (
                <iframe
                  src={activePhet.url}
                  title={activePhet.title}
                  allow="fullscreen"
                  className="w-full h-full border-0"
                  onError={() => setIframeError(true)}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center">
                  <AlertTriangle className="w-8 h-8 text-amber-400 mb-2" />
                  <h3 className="font-heading font-bold text-white text-base">PhET Simulation Firewalled or Offline</h3>
                  <p className="text-xs text-slate-400 max-w-sm mt-1 mb-4">
                    School firewalls may block external iframe domains. You can switch to our high-performance Native Symplectic Lab!
                  </p>
                  <button
                    onClick={() => setLabMode('native')}
                    className="py-2 px-4 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs"
                  >
                    Switch to Native Lab Mode →
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Collapsible Inquiry Drawer (4 cols) */}
          <div className="lg:col-span-4 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Guided Inquiry Tasks
              </span>
              <span className="text-[11px] font-mono text-cyan-400">
                Tier: {gradeTier}
              </span>
            </div>

            <div className="space-y-2.5">
              {activePhet.tasks.map((task) => {
                const isCompleted = completedPhetTasks.includes(task.id);
                return (
                  <div
                    key={task.id}
                    className={`p-3 rounded-xl border transition-all ${
                      isCompleted
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <span className="font-semibold text-xs text-slate-200">{task.taskTitle}</span>
                      <span className="text-[10px] font-mono text-amber-400 font-bold">+{task.xpReward} XP</span>
                    </div>

                    <p className="text-[11px] text-slate-400 leading-relaxed mb-2.5">
                      {task.instructions[gradeTier]}
                    </p>

                    <button
                      disabled={isCompleted}
                      onClick={() => setActiveVerificationTask(task)}
                      className={`w-full py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                        isCompleted
                          ? 'bg-emerald-500/20 text-emerald-300 cursor-default'
                          : 'bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 className="w-3.5 h-3.5" /> : null}
                      {isCompleted ? 'Task Verified (+25 XP)' : 'Verify Experimental Finding'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* PhET Verification Question Modal */}
      {activeVerificationTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="max-w-md w-full bg-slate-900 border border-slate-700 rounded-2xl p-5 space-y-3">
            <h3 className="font-heading font-bold text-white text-base">
              Verification Check: {activeVerificationTask.taskTitle}
            </h3>
            <p className="text-xs text-slate-300">
              {activeVerificationTask.verificationQuestion.question}
            </p>

            <div className="space-y-2">
              {activeVerificationTask.verificationQuestion.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    const isCorrect = idx === activeVerificationTask.verificationQuestion.correctIndex;
                    if (isCorrect) {
                      soundEngine.playVictory();
                      setCompletedPhetTasks([...completedPhetTasks, activeVerificationTask.id]);
                      addXP(activeVerificationTask.xpReward, activeVerificationTask.taskTitle);
                      setActiveVerificationTask(null);
                    } else {
                      soundEngine.playWarning();
                      alert('Incorrect hypothesis. Re-run the simulation experiment and try again!');
                    }
                  }}
                  className="w-full text-left p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 hover:border-cyan-400 text-xs text-slate-200 transition-colors"
                >
                  {opt}
                </button>
              ))}
            </div>

            <button
              onClick={() => setActiveVerificationTask(null)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-400 text-xs font-semibold rounded-lg"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
