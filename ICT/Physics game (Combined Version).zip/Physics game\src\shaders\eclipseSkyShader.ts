import * as THREE from 'three';

export const EclipseSkyShader = {
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform float uTime;
    uniform float uCoverage;       // 0.0 to 1.0
    uniform int uEclipseKind;      // 0: none, 1: total solar, 2: annular solar, 3: partial solar, 4: lunar
    uniform vec2 uMoonOffset;      // Offset of Moon center relative to Sun in UV space

    varying vec2 vUv;

    void main() {
      vec2 center = vec2(0.5, 0.5);
      vec2 uv = vUv;
      float distToSun = length(uv - center);
      vec2 moonCenter = center + uMoonOffset;
      float distToMoon = length(uv - moonCenter);

      float sunRadius = 0.22;
      float moonRadius = (uEclipseKind == 2) ? 0.195 : 0.225; // In annular, Moon is slightly smaller!

      vec3 finalColor = vec3(0.02, 0.03, 0.07); // Deep space background

      if (uEclipseKind == 4) {
        // Lunar Eclipse (Blood Moon)
        if (distToMoon < moonRadius) {
          float limb = distToMoon / moonRadius;
          // Coppery crimson blood moon
          vec3 bloodRed = vec3(0.78, 0.22, 0.12);
          vec3 shadowCore = vec3(0.35, 0.08, 0.05);
          float shadowProg = clamp(uCoverage, 0.0, 1.0);
          vec3 moonColor = mix(vec3(0.7, 0.68, 0.65), mix(shadowCore, bloodRed, limb), shadowProg);
          finalColor = moonColor;
        }
      } else {
        // Solar Eclipse Family
        // 1. Sun surface disk
        bool insideSun = distToSun < sunRadius;
        bool insideMoon = distToMoon < moonRadius;

        if (insideSun && !insideMoon) {
          // Visible bright photosphere with limb darkening
          float rNorm = distToSun / sunRadius;
          float limbDarkening = 1.0 - 0.4 * (1.0 - sqrt(1.0 - rNorm * rNorm));
          vec3 photoColor = vec3(1.0, 0.95, 0.8) * limbDarkening;
          finalColor = photoColor;
        }

        // 2. Annular Ring of Fire
        if (uEclipseKind == 2 && insideSun && insideMoon) {
          // In annular, center is dark Moon, outer edge is brilliant ring
          finalColor = vec3(0.04, 0.04, 0.06);
        }

        // 3. Corona and Diamond Ring when in Total Solar Eclipse
        if (uEclipseKind == 1) {
          // Total Eclipse
          if (distToMoon < moonRadius) {
            finalColor = vec3(0.03, 0.03, 0.05); // Dark Moon disk
          } else {
            // Solar Corona rays
            float angle = atan(uv.y - center.y, uv.x - center.x);
            float rayNoise = sin(angle * 12.0 + uTime * 0.5) * 0.15 + cos(angle * 24.0) * 0.08;
            float coronaFalloff = pow(sunRadius / max(0.01, distToSun), 3.2);
            vec3 coronaColor = vec3(0.85, 0.92, 1.0) * coronaFalloff * (0.8 + rayNoise);

            // Diamond ring sparkle glint
            vec2 beadPos = center + vec2(cos(uTime * 0.2), sin(uTime * 0.2)) * sunRadius;
            float beadDist = length(uv - beadPos);
            float diamondGlint = exp(-beadDist * 40.0) * 2.0;

            finalColor = coronaColor + vec3(1.0, 0.98, 0.9) * diamondGlint;
          }
        }
      }

      gl_FragColor = vec4(finalColor, 1.0);
    }
  `
};
