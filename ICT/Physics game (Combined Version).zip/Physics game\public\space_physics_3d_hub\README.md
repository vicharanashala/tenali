# Space Physics 3D Hub (Class 8 Interactive Astronomy & Orbital Mechanics)

A self-contained 3D web application built with **Three.js (r128)**, **Tailwind CSS**, and the **Web Speech API** (`window.speechSynthesis`), designed for Class 8 science students (*Stars and the Solar System*, Lunar Phases, Lunar Eclipses, and Kepler's Laws of Planetary Motion).

## Included Games & Modules

1. **Game 1 — Moon Phases & Lunar Eclipse (`moon`)**
   - **Step 1:** 3D Solar System Atlas intro with planet fly-to inspection.
   - **Step 2:** Hero selection (**Iron Man, Spider-Man, Batman, Doctor Strange**).
   - **Step 3:** Cutaway ISRO Gaganyaan / LVM3 rocket cockpit at **Satish Dhawan Space Centre, Sriharikota** + liftoff sequence.
   - **Step 4:** 5-part narrated physics demonstration (speed of sunlight `300,000 km/s`, `1.3 s` Moon-to-Earth reflection, 24h Earth spin, `27.3 d` / `29.5 d` lunar periods, Full Moon geometry, and `5°` vs `0°` Lunar Eclipse / Red Blood Moon).
   - **Step 5:** 3-part guided control tutorial.
   - **Step 6:** Interactive sandbox with a visible **3D Person on Earth + Line-of-Sight beam**, **View From Earth PiP** bubble, **Hero POV / Earth Person POV** camera modes, and **DeviceOrientation** tilt sensor support.
   - **Step 7:** 6-question equation-free conceptual quiz.

2. **Game 2 — Kepler's 3 Laws (`kepler`)**
   - **1st Law (Ellipses):** Sun at Focus $F_1$, empty Focus $F_2$, Perihelion & Aphelion markers.
   - **2nd Law (Equal Areas):** Live green ($A_1$) and blue ($A_2$) swept sectors + dynamic Vis-Viva speed vector.
   - **3rd Law (Periods):** Inner vs. outer planet orbital race.
   - **Interactive Sandbox + 4-Question Conceptual Quiz.**

3. **Game 3 — Solar System Encyclopedia & Planet Detective (`solar`)**
   - Procedural 3D surface maps for the Sun and all 8 planets, asteroid belt, Saturn's rings, and toggleable **3D Core Cutaways**.
   - NASA-grounded planetary cards (composition, spin period, orbital period, temperature, moons, and mission history).
   - 5-clue **Planet Detective** challenge.

## How to Run Locally

No build step or `npm install` is required—all dependencies load via CDN in `index.html`.

```bash
# Option 1: Python built-in HTTP server
python3 -m http.server 8080
# Open http://localhost:8080

# Option 2: Node static server
npx serve .
```
