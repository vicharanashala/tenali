import React, { useState } from 'react';
import { soundEngine } from '../../utils/soundEngine';

export const OrbitalTiltNodeWidget: React.FC = () => {
  const [hasTilt, setHasTilt] = useState<boolean>(true);
  const [moonPosition, setMoonPosition] = useState<number>(0); // 0 to 360 deg

  const tiltAngle = hasTilt ? 5.145 : 0;
  // Eclipse happens if moon is at new moon (approx 180 deg) AND near node (0 or 180 deg)
  const isNewMoon = Math.abs(moonPosition - 180) < 15;
  const isNearNode = Math.abs(moonPosition - 0) < 20 || Math.abs(moonPosition - 180) < 20 || Math.abs(moonPosition - 360) < 20;
  const isEclipse = !hasTilt ? isNewMoon : (isNewMoon && isNearNode);

  const toggleTilt = (tilt: boolean) => {
    soundEngine.playClick(800);
    setHasTilt(tilt);
  };

  return (
    <div className="flex flex-col items-center w-full h-full bg-slate-950/60 p-3 rounded-xl border border-slate-800">
      <div className="w-full flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Orbital Tilt & Nodes</span>
        <span className={`text-xs font-mono font-bold ${isEclipse ? 'text-amber-400 animate-pulse' : 'text-slate-400'}`}>
          {isEclipse ? '⚡ ECLIPSE OCCURRING!' : 'Shadow Misses Earth'}
        </span>
      </div>

      {/* 3D Oblique SVG visualization */}
      <div className="w-full max-w-[340px] aspect-[16/9] bg-slate-900/80 rounded-xl border border-slate-800 flex items-center justify-center p-2 relative">
        <svg viewBox="0 0 320 160" className="w-full h-full">
          {/* Ecliptic Reference Plane (Earth's orbital plane) */}
          <ellipse cx="160" cy="80" rx="120" ry="32" fill="rgba(56, 189, 248, 0.05)" stroke="rgba(56, 189, 248, 0.3)" strokeWidth="1" strokeDasharray="3 3" />
          <text x="260" y="78" fill="#38BDF8" fontSize="9" fontFamily="monospace">Ecliptic Plane</text>

          {/* Earth at center */}
          <circle cx="160" cy="80" r="14" fill="#1E3A8A" stroke="#38BDF8" strokeWidth="1.5" />
          <text x="160" y="84" textAnchor="middle" fill="#FFFFFF" fontSize="8" fontWeight="bold">Earth</text>

          {/* Tilted Lunar Orbit Plane */}
          <g transform={`rotate(${tiltAngle}, 160, 80)`}>
            <ellipse
              cx="160"
              cy="80"
              rx="115"
              ry="30"
              fill={hasTilt ? "rgba(168, 85, 247, 0.08)" : "none"}
              stroke="#A855F7"
              strokeWidth="2"
            />
            {/* Nodal Line */}
            <line x1="45" y1="80" x2="275" y2="80" stroke="#F59E0B" strokeWidth="1.5" strokeDasharray="4 2" />
            <circle cx="45" cy="80" r="3" fill="#F59E0B" />
            <circle cx="275" cy="80" r="3" fill="#F59E0B" />
            <text x="40" y="75" textAnchor="end" fill="#F59E0B" fontSize="8" fontFamily="monospace">Node 1</text>
            <text x="280" y="75" textAnchor="start" fill="#F59E0B" fontSize="8" fontFamily="monospace">Node 2</text>

            {/* Moon on tilted plane */}
            {(() => {
              const rad = (moonPosition * Math.PI) / 180;
              const mx = 160 + 115 * Math.cos(rad);
              const my = 80 + 30 * Math.sin(rad);

              return (
                <g>
                  {/* Shadow cone projecting from Moon */}
                  <polygon
                    points={`${mx},${my} ${mx + 60},${my - 8} ${mx + 60},${my + 8}`}
                    fill={isEclipse ? "rgba(239, 68, 68, 0.5)" : "rgba(148, 163, 184, 0.25)"}
                  />
                  <circle cx={mx} cy={my} r="6" fill="#E2E8F0" stroke="#FFFFFF" strokeWidth="1" />
                </g>
              );
            })()}
          </g>

          {/* Sun direction indicator */}
          <g transform="translate(10, 80)">
            <line x1="0" y1="0" x2="20" y2="0" stroke="#FACC15" strokeWidth="2" />
            <polygon points="25,0 18,-4 18,4" fill="#FACC15" />
            <text x="0" y="-8" fill="#FACC15" fontSize="8" fontFamily="monospace">To Sun</text>
          </g>
        </svg>
      </div>

      {/* Tilt Controls */}
      <div className="flex items-center justify-between w-full mt-3 gap-2">
        <button
          onClick={() => toggleTilt(false)}
          className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-colors ${
            !hasTilt ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-slate-800 text-slate-400'
          }`}
        >
          0° Flat Orbit
        </button>
        <button
          onClick={() => toggleTilt(true)}
          className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-colors ${
            hasTilt ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40' : 'bg-slate-800 text-slate-400'
          }`}
        >
          True 5.145° Tilted Orbit
        </button>
      </div>

      {/* Moon Position Scrubber */}
      <div className="w-full mt-2">
        <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
          <span>Moon Orbital Position:</span>
          <span className="text-purple-300 font-bold">{moonPosition}°</span>
        </div>
        <input
          type="range"
          min="0"
          max="360"
          step="5"
          value={moonPosition}
          onChange={(e) => setMoonPosition(parseInt(e.target.value))}
          className="w-full accent-purple-400 cursor-pointer"
        />
      </div>
    </div>
  );
};
