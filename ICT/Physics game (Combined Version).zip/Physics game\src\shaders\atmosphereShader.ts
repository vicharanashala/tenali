import * as THREE from 'three';

export const AtmosphereShader = {
  vertexShader: `
    varying vec3 vNormal;
    void main() {
      vNormal = normalize(normalMatrix * normal);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform vec3 uAtmosphereColor;
    uniform float uIntensity;
    uniform float uPower;
    varying vec3 vNormal;

    void main() {
      // View direction is (0, 0, 1) in view space
      float intensity = pow(uIntensity - dot(vNormal, vec3(0.0, 0.0, 1.0)), uPower);
      intensity = clamp(intensity, 0.0, 1.0);
      gl_FragColor = vec4(uAtmosphereColor, intensity);
    }
  `,
  createMaterial: (color = '#38BDF8', intensity = 0.7, power = 3.0) => {
    return new THREE.ShaderMaterial({
      vertexShader: AtmosphereShader.vertexShader,
      fragmentShader: AtmosphereShader.fragmentShader,
      uniforms: {
        uAtmosphereColor: { value: new THREE.Color(color) },
        uIntensity: { value: intensity },
        uPower: { value: power },
      },
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true,
      depthWrite: false,
    });
  }
};
