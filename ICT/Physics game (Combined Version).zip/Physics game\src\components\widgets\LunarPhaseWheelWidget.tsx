import React, { useState } from 'react';
import { soundEngine } from '../../utils/soundEngine';

export const LunarPhaseWheelWidget: React.FC = () => {
  const [angleDeg, setAngleDeg] = useState<number>(45); // 0 = New Moon (Sun on right or left)

  // In our coordinate frame:
  // Sunlight enters from the left (x = 0).
  // Angle = 0°: Moon on left between Earth and Sun -> New Moon (dark side faces Earth)
  // Angle = 90°: Moon at top -> First Quarter
  // Angle = 180°: Moon on right -> Full Moon (illuminated side faces Earth)
  // Angle = 270°: Moon at bottom -> Third Quarter

  const getPhaseName = (deg: number): { name: string; illumination: number } => {
    const norm = (deg % 360 + 360) % 360;
    // Illumination fraction = (1 - cos(angle)) / 2
    const illum = Math.round(((1 - Math.cos((norm * Math.PI) / 180)) / 2) * 100);

    if (norm < 15 || norm > 345) return { name: 'New Moon', illumination: illum };
    if (norm >= 15 && norm < 75) return { name: 'Waxing Crescent', illumination: illum };
    if (norm >= 75 && norm <= 105) return { name: 'First Quarter (Half)', illumination: illum };
    if (norm > 105 && norm < 165) return { name: 'Waxing Gibbous', illumination: illum };
    if (norm >= 165 && norm <= 195) return { name: 'Full Moon', illumination: illum };
    if (norm > 195 && norm < 255) return { name: 'Waning Gibbous', illumination: illum };
    if (norm >= 255 && norm <= 285) return { name: 'Third Quarter (Half)', illumination: illum };
    return { name: 'Waning Crescent', illumination: illum };
  };

  const phase = getPhaseName(angleDeg);

  const handleAngleSlider = (deg: number) => {
    soundEngine.playClick(700);
    setAngleDeg(deg);
  };

  return (
    <div className="flex flex-col items-center w-full h-full bg-slate-950/60 p-3 rounded-xl border border-slate-800">
      <div className="w-full flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Lunar Phase Generator</span>
        <span className="text-xs font-mono text-cyan-400 font-bold">{phase.name} ({phase.illumination}%)</span>
      </div>

      <div className="grid grid-cols-2 gap-3 w-full max-w-[340px] items-center">
        {/* Left: Top-Down Space Orbit View */}
        <div className="relative aspect-square flex items-center justify-center bg-slate-900/80 rounded-xl border border-slate-800 p-2">
          <svg viewBox="0 0 160 160" className="w-full h-full">
            {/* Sunlight rays from left */}
            {[-30, 0, 30].map((yOff) => (
              <g key={yOff}>
                <line x1="2" y1={80 + yOff} x2="25" y2={80 + yOff} stroke="#FACC15" strokeWidth="2" />
                <polygon points={`28,${80 + yOff} 22,${77 + yOff} 22,${83 + yOff}`} fill="#FACC15" />
              </g>
            ))}

            {/* Orbit circle */}
            <circle cx="80" cy="80" r="50" fill="none" stroke="#334155" strokeWidth="1" strokeDasharray="3 3" />

            {/* Earth in center */}
            <circle cx="80" cy="80" r="16" fill="#1E3A8A" stroke="#38BDF8" strokeWidth="1.5" />
            {/* Earth night half */}
            <path d="M 80,64 A 16 16 0 0 1 80,96 Z" fill="#090D1A" />

            {/* Moon revolving */}
            {(() => {
              const rad = (angleDeg * Math.PI) / 180;
              // Angle 0 is at left (-x)
              const mx = 80 - 50 * Math.cos(rad);
              const my = 80 - 50 * Math.sin(rad);

              return (
                <g>
                  {/* Orbit trail connecting Earth to Moon */}
                  <line x1="80" y1="80" x2={mx} y2={my} stroke="#A855F7" strokeWidth="1" strokeDasharray="2 2" opacity="0.6" />
                  {/* Moon body */}
                  <circle cx={mx} cy={my} r="7" fill="#E2E8F0" />
                  {/* Moon shadow half (always on the side away from Sun) */}
                  <path d={`M ${mx},${my - 7} A 7 7 0 0 1 ${mx},${my + 7} Z`} fill="#0F172A" />
                  <circle cx={mx} cy={my} r="7" fill="none" stroke="#F8FAFC" strokeWidth="1" />
                </g>
              );
            })()}
          </svg>
          <span className="absolute bottom-1 left-2 text-[9px] font-mono text-amber-300">☀ Sunlight</span>
        </div>

        {/* Right: Earth Observer Sky View (Telescope) */}
        <div className="flex flex-col items-center justify-center aspect-square bg-slate-900/80 rounded-xl border border-slate-800 p-2">
          <span className="text-[10px] text-slate-400 font-semibold mb-1">Earth Sky View</span>
          <div className="relative w-20 h-20 rounded-full bg-slate-950 border-2 border-slate-700 overflow-hidden shadow-inner flex items-center justify-center">
            {/* Render realistic phase disk */}
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {/* Dark base */}
              <circle cx="50" cy="50" r="48" fill="#0B1120" />

              {/* Lit portion */}
              {(() => {
                const norm = (angleDeg % 360 + 360) % 360;
                // If angle between 0 and 180, waxing (lit on right)
                // If angle between 180 and 360, waning (lit on left)
                const isWaxing = norm <= 180;
                const sweep = isWaxing ? 1 : 0;
                const k = Math.cos((norm * Math.PI) / 180); // 1 at new, -1 at full
                const rx = Math.abs(k * 48);

                return (
                  <path
                    d={`M 50,2 A 48 48 0 0 ${sweep} 50,98 A ${rx} 48 0 0 ${k > 0 ? (isWaxing ? 0 : 1) : (isWaxing ? 1 : 0)} 50,2 Z`}
                    fill="#E2E8F0"
                  />
                );
              })()}
            </svg>
          </div>
          <span className="text-[11px] font-mono text-cyan-300 font-bold mt-2 text-center">{phase.name}</span>
        </div>
      </div>

      {/* Orbit Angle Scrubber */}
      <div className="w-full mt-3">
        <input
          type="range"
          min="0"
          max="360"
          step="5"
          value={angleDeg}
          onChange={(e) => handleAngleSlider(parseInt(e.target.value))}
          className="w-full accent-cyan-400 cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
          <span>0° New</span>
          <span>90° 1st Qtr</span>
          <span>180° Full</span>
          <span>270° 3rd Qtr</span>
          <span>360° New</span>
        </div>
      </div>
    </div>
  );
};
