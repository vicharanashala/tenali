import * as THREE from 'three';

export const ShadowConeShader = {
  vertexShader: `
    varying vec3 vPosition;
    varying vec3 vNormal;
    varying vec2 vUv;

    void main() {
      vPosition = position;
      vNormal = normalize(normalMatrix * normal);
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform vec3 uConeColor;
    uniform float uOpacity;
    uniform float uEdgeFade;
    varying vec3 vPosition;
    varying vec3 vNormal;
    varying vec2 vUv;

    void main() {
      // Soft falloff at edges of shadow volume
      float rim = 1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0)));
      float alpha = uOpacity * (1.0 - rim * uEdgeFade);

      // Distance gradient along cone length
      alpha *= smoothstep(0.0, 0.15, vUv.y) * smoothstep(1.0, 0.75, vUv.y);

      gl_FragColor = vec4(uConeColor, clamp(alpha, 0.0, 1.0));
    }
  `,
  createMaterial: (color = '#6366F1', opacity = 0.35, edgeFade = 0.5) => {
    return new THREE.ShaderMaterial({
      vertexShader: ShadowConeShader.vertexShader,
      fragmentShader: ShadowConeShader.fragmentShader,
      uniforms: {
        uConeColor: { value: new THREE.Color(color) },
        uOpacity: { value: opacity },
        uEdgeFade: { value: edgeFade },
      },
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
      blending: THREE.NormalBlending,
    });
  }
};
