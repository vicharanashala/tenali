import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertOctagon, RotateCcw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary3D extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('COSMOS LAB 3D Context Error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center p-6 bg-slate-950/90 rounded-2xl border border-rose-500/30 text-center">
          <div className="p-3 rounded-2xl bg-rose-500/20 text-rose-400 mb-3">
            <AlertOctagon className="w-8 h-8" />
          </div>
          <h3 className="font-heading font-bold text-lg text-slate-100 mb-1">
            3D WebGL Context Interrupted
          </h3>
          <p className="text-xs text-slate-400 max-w-md mb-4 leading-relaxed">
            Your graphics driver or browser suspended the 3D canvas context. Click below to reinitialize the physics simulation.
          </p>
          <button
            onClick={this.handleReset}
            className="flex items-center gap-2 py-2 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs transition-colors shadow-lg shadow-cyan-500/20"
          >
            <RotateCcw className="w-4 h-4" /> Reinitialize 3D Viewport
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
