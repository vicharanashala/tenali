# COSMOS LAB ⚛
### Production-Grade Interactive 3D Physics, Gravity & Space Web Application
> Built for **Class 6 to Class 12 Students** engineered around **Three.js r187 / WebGL2**, **PhET's Implicit Scaffolding framework**, **MIT TEAL's 3D Physics Visualization methodology**, and **Richard Mayer's Multimedia Learning Principles**.

---

## 🚀 Overview & Architectural Pillars

**COSMOS LAB** unifies five pedagogical pillars into one single-page application:

### 0. Stage 0 — Interactive 5-Step "Flight School" Tutorial
- **Live 3D Earth–Moon Stage**: Gesture-verified onboarding training.
- **Step 1 (Orbit Camera)**: Sums cumulative azimuthal rotation delta $\ge 45^\circ$ to auto-advance.
- **Step 2 (Zoom & Scale)**: Detects radial camera distance changes.
- **Step 3 (Inspect Body)**: Interactive raycast targeting on the Moon.
- **Step 4 (Toggle Vectors & Warp Time)**: Teaches vector HUD overlays and orbital time-dilation.
- **Step 5 (Flight Certified)**: Audio fanfare + confetti particle burst + unlockable achievement badge (+100 XP).
- **Accessibility**: 1-click Web Speech Synthesis Voice Captions (`speechSynthesis`) and a skip button for educators.

### 1. Page 1 — Cosmic Academy (Astrophy-Style Interactive Theory)
- **Two-Column Responsive Deck**: Left roadmap with completion indicators + right focused interactive card stage.
- **Mayer's Coherence Principle**: Explanations under 55 words per card, dynamically adapted across 3 Grade Tiers:
  - *Cadet (Class 6–8)*: Concrete qualitative intuition, mass vs. weight, shadows, moon phases.
  - *Navigator (Class 9–10)*: Scalar equations ($F = G m_1 m_2 / r^2$, $g = GM/R^2$, $W = mg$, $v = 2\pi r/T$).
  - *Astrophysicist (Class 11–12)*: Kepler's three laws, vis-viva equation, escape velocity, mechanical energy.
- **6 Embedded Micro-Widgets**:
  - `NewtonCannonWidget`: Sub-orbital crash $\rightarrow$ 7.9 km/s circular $\rightarrow$ 11.2 km/s escape.
  - `InverseSquareLightWidget`: Draggable screen showing $1r \rightarrow 2r \rightarrow 3r$ with $1\times \rightarrow 4\times \rightarrow 9\times$ spread.
  - `LunarPhaseWheelWidget`: 360° Moon orbit with real-time synced Earth sky view.
  - `OrbitalTiltNodeWidget`: $0^\circ$ flat vs. true $5.145^\circ$ tilted orbit showing nodal crossings.
  - `DensityComparisonWidget`: Flotation tank showing why Saturn ($0.687\text{ g/cm}^3$) floats in water.
  - `EscapeVelocityWidget`: Multi-world probe launcher with potential well curves.
- **Formula Inspector**: Hover-to-highlight KaTeX variable bindings with SI units and definitions.
- **Predict–Observe–Explain (POE) Checkpoints**: Hypothesis testing with inquiry XP rewards.

### 2. Page 2 — Virtual Physics Lab (PhET Suite + Native Symplectic Vector Engine)
- **Mode A: Official PhET HTML5 Simulator Suite**:
  - Embeds 4 official simulations: *Gravity and Orbits*, *Gravity Force Lab: Basics*, *Kepler's Laws*, and *My Solar System*.
  - Collapsible Grade-Tiered Inquiry Drawer with interactive verification checks.
  - Offline / Firewall timeout guard with instant 1-click fallback to the native engine.
- **Mode B: Native Symplectic 2D/3D Velocity-Verlet Lab**:
  - Symplectic Velocity-Verlet integrator with 8 substeps per frame and softening parameter $\epsilon$.
  - Energy conservation tracker (Kinetic $K$, Potential $U$, Total Energy $E$, drift percentage).
  - Presets: Sun-Earth circular, eccentric comet ($e = 0.72$), binary star waltz, Jupiter gravity assist.
  - **"CUT GRAVITY (G = 0)" Switch**: POE check followed by instantaneous $G=0$ cut to demonstrate Newton's 1st Law tangent motion.
  - **Kepler Equal-Area Sweeper**: Alternating translucent violet/cyan triangular sectors demonstrating $dA/dt = \text{const}$.

### 3. Page 3 — 3D Solar System, Stellarium Sky Dome & Eclipse Observatory
- **View 1 (3D Solar System)**: J2000 orbital parameters, Classroom Scale vs. True Scale toggle, and physical telemetry HUD.
- **View 2 (Stellarium-Style Sky Dome)**: 4,000+ stars with Planckian spectral chromaticity (O, B, A, F, G, K, M), constellation stick figures (Orion, Ursa Major, Cassiopeia, Crux, Scorpius), and observer latitude controls.
- **View 3 (3D Eclipse Observatory)**:
  - Analytically accurate 3D Umbra and Penumbra cones.
  - Solar vs. Lunar Eclipse modes.
  - $5.145^\circ$ lunar tilt with nodal offset controls.
  - Synced Picture-in-Picture (PiP) viewport showing the diamond ring effect, Baily's beads, annular ring of fire, and Blood Moon Rayleigh scattering.

### 4. Page 4 — Gravity Calculator, 3D Planetary Materials & Orbital Missions
- **Module 1 (Kinematics Jump Lab)**: Parabolic flight $y(t) = v_0 t - \frac{1}{2}gt^2$, hang-time, and weight across Moon, Mars, Earth, and Jupiter.
- **Module 2 (3D Planetary Cutaway)**: 3D quarter-wedge concentric sphere cutaways of Earth, Mars, and Jupiter showing Crust, Mantle, Outer Core, and Inner Core with composition, temperature, and dynamo explanations.
- **Module 3 (Orbital Engineer Sandbox)**: 8 gamified spaceflight missions with automated physics rubrics:
  1. Low Earth Orbit Insertion
  2. Geostationary Parking Orbit ($T = 24.0\text{ h}$)
  3. Lunar Gravity-Assist Flyby
  4. Hohmann Transfer to Mars
  5. High-Latitude Molniya Orbit ($e \approx 0.72$)
  6. Solar System Escape
  7. Sun-Earth L1 Halo Station-Keeping
  8. Safe Atmospheric Re-Entry

---

## 🛠 Tech Stack

- **Framework**: React 19 + TypeScript 5.6+
- **Build Tool**: Vite 8+
- **Graphics & 3D**: Three.js (r187+), OrbitControls, Custom GLSL Shaders (Atmosphere Rayleigh scattering, Sun plasma turbulence, Volumetric shadow cones, Eclipse sky scatter)
- **Styling**: Tailwind CSS v4, Lucide React Icons
- **Math Formatting**: KaTeX (`katex`)
- **State Management**: Zustand with `localStorage` persistence (`cosmos_lab_v1`)
- **Audio**: Procedural Web Audio API synthesizer (tactile clicks, harmonic orbit locks, warning buzzes, victory fanfares)
- **Procedural Textures**: Seeded simplex/value noise Canvas2D textures (Earth, Moon, Mars, Jupiter, Sun, Saturn rings) with zero broken external URLs!

---

## 🎮 Running Locally

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev

# 3. Build production bundle
npm run build

# 4. Preview production build
npm run preview
```
