import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import {
  Layers,
  Activity,
  Rocket,
  Play,
  RotateCcw,
  CheckCircle2,
  Sparkles,
  ArrowUp,
  ArrowDown,
  Info,
  ShieldAlert,
  Compass
} from 'lucide-react';
import { PLANETARY_MATERIALS } from '../data/planetaryMaterialsData';
import { ORBITAL_MISSIONS } from '../data/missionsData';
import { calculateSurfaceGravity, calculateJumpProfile, calculateHohmannTransfer } from '../physics/gravityMath';
import { useCosmosStore } from '../store/useCosmosStore';
import { soundEngine } from '../utils/soundEngine';
import { FormulaInspector } from '../components/shared/FormulaInspector';

interface JumpWorld {
  id: string;
  name: string;
  massKg: number;
  radiusKm: number;
  color: string;
}

const JUMP_WORLDS: JumpWorld[] = [
  { id: 'moon', name: 'Moon', massKg: 7.342e22, radiusKm: 1737.4, color: '#CBD5E1' },
  { id: 'mars', name: 'Mars', massKg: 6.417e23, radiusKm: 3389.5, color: '#EF4444' },
  { id: 'earth', name: 'Earth', massKg: 5.972e24, radiusKm: 6371.0, color: '#38BDF8' },
  { id: 'jupiter', name: 'Jupiter', massKg: 1.898e27, radiusKm: 69911, color: '#F97316' },
];

export const GravityMaterialsPage: React.FC = () => {
  const {
    gradeTier,
    addXP,
    unlockBadge,
    inspectLayer,
    compareJumpWorld,
    completedMissions,
    completeMission
  } = useCosmosStore();

  const [activeModule, setActiveModule] = useState<'jump' | 'cutaway' | 'missions'>('jump');

  // Jump Lab State
  const [selectedWorldId, setSelectedWorldId] = useState<string>('earth');
  const [userMassKg, setUserMassKg] = useState<number>(70);
  const [isJumping, setIsJumping] = useState<boolean>(false);
  const [jumpTime, setJumpTime] = useState<number>(0);

  // Cutaway State
  const [selectedCutawayPlanet, setSelectedCutawayPlanet] = useState<string>('earth');
  const [activeLayerIdx, setActiveLayerIdx] = useState<number>(0);
  const cutawayCanvasRef = useRef<HTMLDivElement | null>(null);

  // Orbital Missions State
  const [activeMissionIdx, setActiveMissionIdx] = useState<number>(0);
  const [currentSpeedKms, setCurrentSpeedKms] = useState<number>(6.2);
  const [currentRadiusKm, setCurrentRadiusKm] = useState<number>(6671);
  const [currentEccentricity, setCurrentEccentricity] = useState<number>(0.12);
  const [missionLog, setMissionLog] = useState<string[]>([]);

  const activeMission = ORBITAL_MISSIONS[activeMissionIdx];
  const activeCutawayData = PLANETARY_MATERIALS[selectedCutawayPlanet] || PLANETARY_MATERIALS['earth'];
  const activeLayer = activeCutawayData.layers[activeLayerIdx] || activeCutawayData.layers[0];

  const currentJumpWorld = JUMP_WORLDS.find((w) => w.id === selectedWorldId) || JUMP_WORLDS[2];
  const worldG = calculateSurfaceGravity(currentJumpWorld.massKg, currentJumpWorld.radiusKm);
  const userWeightN = userMassKg * worldG;
  const jumpProfile = calculateJumpProfile(worldG, 3.2);

  // Handle Jump Animation
  useEffect(() => {
    let animId: number;
    if (isJumping) {
      animId = requestAnimationFrame(() => {
        setJumpTime((t) => {
          const next = t + 0.03;
          if (next >= jumpProfile.hangTimeSeconds) {
            setIsJumping(false);
            return 0;
          }
          return next;
        });
      });
    }
    return () => cancelAnimationFrame(animId);
  }, [isJumping, jumpTime, jumpProfile.hangTimeSeconds]);

  const handleStartJump = () => {
    soundEngine.playThruster(0.15);
    setJumpTime(0);
    setIsJumping(true);
    compareJumpWorld(currentJumpWorld.id);
  };

  // 3D Procedural Quarter-Wedge Planetary Interior in Three.js
  useEffect(() => {
    if (activeModule !== 'cutaway') return;
    const container = cutawayCanvasRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#050814');

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(12, 10, 15);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;

    // Lights
    const amb = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(amb);
    const dir = new THREE.DirectionalLight(0xffffff, 1.8);
    dir.position.set(20, 20, 20);
    scene.add(dir);

    // Build Concentric Quarter-Wedge Layers
    // A sphere with thetaLength = 1.5 * PI (removes a 90 deg quarter slice!)
    const layers = activeCutawayData.layers;
    let currentR = 6.0;

    layers.forEach((layer, idx) => {
      const isSelected = activeLayerIdx === idx;
      const geo = new THREE.SphereGeometry(
        currentR,
        32,
        32,
        0,
        Math.PI * 1.5, // 270 degrees -> leaves 90 deg quarter cutaway!
        0,
        Math.PI
      );

      const mat = new THREE.MeshStandardMaterial({
        color: layer.color,
        roughness: 0.6,
        metalness: idx >= layers.length - 2 ? 0.8 : 0.2, // metallic cores
        emissive: isSelected ? layer.color : '#000000',
        emissiveIntensity: isSelected ? 0.35 : 0.0,
        side: THREE.DoubleSide
      });

      const mesh = new THREE.Mesh(geo, mat);
      scene.add(mesh);

      currentR -= currentR * layer.thicknessFraction;
    });

    let animId: number;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
      controls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [activeModule, selectedCutawayPlanet, activeLayerIdx]);

  // Orbital Sandbox Thruster Burns & Evaluation
  const handleProgradeBurn = (dv: number) => {
    soundEngine.playThruster(0.25);
    const newSpeed = currentSpeedKms + dv;
    const newRadius = currentRadiusKm * (1 + dv * 0.04);
    const newEcc = Math.max(0, currentEccentricity + (dv > 0 ? 0.04 : -0.04));
    setCurrentSpeedKms(newSpeed);
    setCurrentRadiusKm(newRadius);
    setCurrentEccentricity(newEcc);

    setMissionLog((prev) => [
      `Fired Prograde Burn: +${dv.toFixed(2)} km/s | New Speed: ${newSpeed.toFixed(2)} km/s`,
      ...prev.slice(0, 4)
    ]);
  };

  const handleRetrogradeBurn = (dv: number) => {
    soundEngine.playThruster(0.25);
    const newSpeed = Math.max(0, currentSpeedKms - dv);
    const newRadius = Math.max(6371, currentRadiusKm * (1 - dv * 0.04));
    const newEcc = Math.max(0, currentEccentricity - 0.03);
    setCurrentSpeedKms(newSpeed);
    setCurrentRadiusKm(newRadius);
    setCurrentEccentricity(newEcc);

    setMissionLog((prev) => [
      `Fired Retrograde Burn: -${dv.toFixed(2)} km/s | New Speed: ${newSpeed.toFixed(2)} km/s`,
      ...prev.slice(0, 4)
    ]);
  };

  const handleEvaluateMission = () => {
    const t = activeMission.targetConditions;
    let passed = true;

    if (t.minSpeedKms && currentSpeedKms < t.minSpeedKms) passed = false;
    if (t.maxSpeedKms && currentSpeedKms > t.maxSpeedKms) passed = false;
    if (t.maxEccentricity && currentEccentricity > t.maxEccentricity) passed = false;

    if (passed) {
      soundEngine.playVictory();
      completeMission(activeMission.id);
      addXP(activeMission.xpReward, `Mission Passed: ${activeMission.title}`);
      alert(`🎉 MISSION OBJECTIVE ACHIEVED! +${activeMission.xpReward} XP awarded.`);
    } else {
      soundEngine.playWarning();
      alert('Mission conditions not yet met. Check the objective rubric and fine-tune your orbital burns.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Top Header & Module Switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1 rounded-md bg-amber-500/20 text-amber-400">
              <Activity className="w-4 h-4" />
            </span>
            <span className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
              Kinematics, Geophysics & Orbital Engineering
            </span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-heading font-extrabold text-white">
            Gravity, Interiors & Missions
          </h1>
        </div>

        {/* 3 Module Switcher */}
        <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => {
              soundEngine.playClick(600);
              setActiveModule('jump');
            }}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
              activeModule === 'jump'
                ? 'bg-amber-500/20 text-amber-200 border border-amber-400/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Activity className="w-3.5 h-3.5" /> Multi-World Jump
          </button>
          <button
            onClick={() => {
              soundEngine.playClick(600);
              setActiveModule('cutaway');
            }}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
              activeModule === 'cutaway'
                ? 'bg-purple-500/20 text-purple-200 border border-purple-400/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> 3D Interior Cutaways
          </button>
          <button
            onClick={() => {
              soundEngine.playClick(600);
              setActiveModule('missions');
            }}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
              activeModule === 'missions'
                ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/50 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Rocket className="w-3.5 h-3.5" /> Orbital Missions (8)
          </button>
        </div>
      </div>

      {/* MODULE 1: MULTI-WORLD JUMP & WEIGHT CALCULATOR */}
      {activeModule === 'jump' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Main Jump Visualizer (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Astronaut Kinematics Parabola
              </span>
              <span className="text-xs font-mono text-cyan-400">
                y(t) = v₀t - ½gt²
              </span>
            </div>

            {/* Parabolic Trajectory SVG */}
            <div className="w-full aspect-[16/9] bg-slate-950 rounded-xl border border-slate-800 relative flex items-center justify-center p-3 overflow-hidden">
              <svg viewBox="0 0 360 200" className="w-full h-full">
                {/* Surface Ground */}
                <line x1="20" y1="180" x2="340" y2="180" stroke="#64748B" strokeWidth="2" />
                <rect x="20" y="180" width="320" height="15" fill="rgba(100, 116, 139, 0.2)" />

                {/* Maximum Height Ceiling Guide */}
                <line x1="20" y1="40" x2="340" y2="40" stroke="#334155" strokeWidth="1" strokeDasharray="3 3" />
                <text x="330" y="35" textAnchor="end" fill="#64748B" fontSize="9" fontFamily="monospace">
                  Peak Height: {jumpProfile.maxHeightMeters.toFixed(2)} m
                </text>

                {/* Animated Parabolic Jump Path */}
                {(() => {
                  const currentY = jumpProfile.heightAtTime(jumpTime);
                  // Scale height to SVG coordinates (180 is ground, 40 is max)
                  const scaleY = 180 - (currentY / Math.max(0.5, jumpProfile.maxHeightMeters)) * 130;
                  const currentX = 60 + (jumpTime / jumpProfile.hangTimeSeconds) * 240;

                  return (
                    <g>
                      {/* Parabola guide */}
                      <path
                        d="M 60,180 Q 180,50 300,180"
                        fill="none"
                        stroke="#38BDF8"
                        strokeWidth="1.5"
                        strokeDasharray="4 2"
                        opacity="0.4"
                      />

                      {/* Astronaut glyph */}
                      <circle cx={currentX} cy={scaleY} r="10" fill="#38BDF8" />
                      <circle cx={currentX} cy={scaleY - 3} r="4" fill="#0F172A" />

                      {/* Velocity Vector arrow (Cyan) */}
                      {isJumping && (
                        <line
                          x1={currentX}
                          y1={scaleY}
                          x2={currentX}
                          y2={scaleY - jumpProfile.speedAtTime(jumpTime) * 8}
                          stroke="#38BDF8"
                          strokeWidth="2.5"
                        />
                      )}
                    </g>
                  );
                })()}
              </svg>

              <div className="absolute top-3 left-3 text-xs font-mono text-slate-300">
                <div>Hang-Time: <strong className="text-amber-400">{jumpProfile.hangTimeSeconds.toFixed(2)} s</strong></div>
                <div>Current Height: <strong className="text-cyan-400">{jumpProfile.heightAtTime(jumpTime).toFixed(2)} m</strong></div>
              </div>
            </div>

            {/* Jump Action */}
            <div className="flex gap-2">
              <button
                disabled={isJumping}
                onClick={handleStartJump}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-50 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                <ArrowUp className="w-4 h-4" /> Trigger Vertical Jump (v₀ = 3.2 m/s)
              </button>
            </div>
          </div>

          {/* Right Column: World Comparison & Weight (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 space-y-4">
            <h3 className="font-heading font-extrabold text-white text-base">
              Planetary Gravity & Weight
            </h3>

            {/* World Switcher */}
            <div className="grid grid-cols-4 gap-1.5">
              {JUMP_WORLDS.map((w) => (
                <button
                  key={w.id}
                  onClick={() => {
                    soundEngine.playClick(650);
                    setSelectedWorldId(w.id);
                  }}
                  className={`py-1.5 px-1 rounded-xl text-xs font-bold transition-colors ${
                    selectedWorldId === w.id
                      ? 'bg-amber-500/30 text-amber-200 border border-amber-400'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {w.name}
                </button>
              ))}
            </div>

            {/* Weight on World Telemetry */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 font-mono text-xs">
              <div className="flex justify-between items-center text-slate-400">
                <span>Surface Gravity (g):</span>
                <span className="text-amber-400 font-bold text-sm">{worldG.toFixed(2)} m/s²</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>Earth Relative g:</span>
                <span className="text-cyan-400 font-bold">{(worldG / 9.807).toFixed(2)}× Earth</span>
              </div>
              <div className="flex justify-between items-center text-slate-400 border-t border-slate-800 pt-2">
                <span>Weight (W = m·g):</span>
                <span className="text-emerald-400 font-bold text-sm">{userWeightN.toFixed(1)} N ({((userWeightN / 9.807) * 2.204).toFixed(1)} lbs)</span>
              </div>
            </div>

            {/* Linked KaTeX Equation */}
            <FormulaInspector
              latex="W = m \\cdot g"
              bindings={[
                { symbol: 'W', name: 'Weight Force', unit: 'N', color: '#10B981', meaning: { '6-8': 'The force pulling your body down.', '9-10': 'Gravitational attraction on mass.', '11-12': 'Local downward gravitational force vector.' } },
                { symbol: 'm', name: 'Inertial Mass', unit: 'kg', color: '#38BDF8', meaning: { '6-8': 'The matter that makes up your body.', '9-10': 'Constant invariant mass.', '11-12': 'Inertial mass scalar.' } },
                { symbol: 'g', name: 'Gravitational Acceleration', unit: 'm/s²', color: '#F59E0B', meaning: { '6-8': 'How fast things speed up when falling.', '9-10': 'Surface gravitational acceleration g = GM/R².', '11-12': 'Gravitational field strength vector.' } }
              ]}
            />
          </div>
        </div>
      )}

      {/* MODULE 2: 3D PLANETARY MATERIALS CUTAWAYS */}
      {activeModule === 'cutaway' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Main 3D Cutaway Viewport (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Procedural 3D Quarter-Wedge Cutaway
              </span>
              <span className="text-xs font-mono text-purple-400">
                Rotate 360° to inspect interior
              </span>
            </div>

            {/* Planet selector */}
            <div className="flex gap-2">
              {['earth', 'jupiter', 'mars'].map((pId) => (
                <button
                  key={pId}
                  onClick={() => {
                    soundEngine.playClick(650);
                    setSelectedCutawayPlanet(pId);
                    setActiveLayerIdx(0);
                  }}
                  className={`py-1.5 px-4 rounded-xl text-xs font-bold uppercase transition-colors ${
                    selectedCutawayPlanet === pId
                      ? 'bg-purple-500/30 text-purple-200 border border-purple-400'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {pId}
                </button>
              ))}
            </div>

            {/* 3D WebGL Canvas */}
            <div className="relative w-full aspect-[4/3] rounded-xl border border-slate-800 overflow-hidden bg-slate-950">
              <div ref={cutawayCanvasRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
            </div>
          </div>

          {/* Right Column: Layer Inspector & Geodynamo (5 cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 space-y-4">
            <h3 className="font-heading font-extrabold text-white text-base">
              Interior Layer Inspector
            </h3>

            {/* Layer Selection Buttons */}
            <div className="space-y-1.5">
              {activeCutawayData.layers.map((l, idx) => (
                <button
                  key={l.name}
                  onClick={() => {
                    soundEngine.playClick(700);
                    setActiveLayerIdx(idx);
                    inspectLayer(selectedCutawayPlanet, l.name);
                  }}
                  className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between ${
                    activeLayerIdx === idx
                      ? 'bg-purple-500/20 border-purple-400 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: l.color }} />
                    <span className="text-xs font-semibold">{l.name}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{l.depthRangeKm}</span>
                </button>
              ))}
            </div>

            {/* Active Layer Details */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs font-mono">
              <div className="text-amber-400 font-bold">{activeLayer.name}</div>
              <div className="text-slate-300">State: <span className="text-slate-100">{activeLayer.state}</span></div>
              <div className="text-slate-300">Density: <span className="text-cyan-400 font-bold">{activeLayer.density}</span></div>
              <div className="text-slate-300">Temperature: <span className="text-rose-400 font-bold">{activeLayer.temperature}</span></div>
              <div className="text-slate-300">Pressure: <span className="text-purple-400 font-bold">{activeLayer.pressure}</span></div>
              <div className="text-slate-400 text-[11px] pt-1 font-sans leading-relaxed">
                {activeLayer.keyFact[gradeTier]}
              </div>
            </div>

            {/* Planetary Dynamo & Magnetic Shield */}
            <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-indigo-300 mb-1">
                <ShieldAlert className="w-4 h-4" /> Magnetic Field Dynamo Link
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                {activeCutawayData.magneticFieldDesc[gradeTier]}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 3: ORBITAL ENGINEER SANDBOX (8 MISSIONS) */}
      {activeModule === 'missions' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Mission Deck (4 cols) */}
          <div className="lg:col-span-4 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-4 space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
              Mission Directives ({completedMissions.length} / {ORBITAL_MISSIONS.length} Done)
            </span>

            <div className="space-y-1.5">
              {ORBITAL_MISSIONS.map((m, idx) => {
                const isSelected = activeMissionIdx === idx;
                const isDone = completedMissions.includes(m.id);
                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      soundEngine.playClick(700);
                      setActiveMissionIdx(idx);
                      setCurrentSpeedKms(m.initialState.v);
                      setCurrentRadiusKm(m.initialState.r);
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-cyan-500/20 border-cyan-400 text-white'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold line-clamp-1">{m.title}</div>
                      <div className="text-[10px] text-amber-400 font-mono">+{m.xpReward} XP</div>
                    </div>
                    {isDone && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Mission Cockpit (8 cols) */}
          <div className="lg:col-span-8 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="pb-3 border-b border-slate-800">
              <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold">
                Orbital Mission Simulator
              </span>
              <h2 className="text-xl font-heading font-extrabold text-white mt-0.5">
                {activeMission.title}
              </h2>
              <p className="text-xs text-slate-300 mt-1">
                {activeMission.briefing}
              </p>
            </div>

            {/* Objective & Target Rubric */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
              <span className="font-bold text-amber-400 block mb-1">Target Flight Objective:</span>
              <span className="text-slate-200">{activeMission.objective}</span>
            </div>

            {/* Live Telemetry Flight Deck */}
            <div className="grid grid-cols-3 gap-2 text-xs font-mono text-center">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-[10px] uppercase text-slate-400">Current Velocity</div>
                <div className="text-cyan-400 font-bold text-base mt-0.5">{currentSpeedKms.toFixed(2)} km/s</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-[10px] uppercase text-slate-400">Orbital Radius</div>
                <div className="text-purple-400 font-bold text-base mt-0.5">{Math.round(currentRadiusKm).toLocaleString()} km</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-[10px] uppercase text-slate-400">Eccentricity (e)</div>
                <div className="text-emerald-400 font-bold text-base mt-0.5">{currentEccentricity.toFixed(2)}</div>
              </div>
            </div>

            {/* Thruster Burn Controls */}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <button
                onClick={() => handleProgradeBurn(0.5)}
                className="flex-1 py-2 px-3 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold transition-colors"
              >
                +0.5 km/s Prograde Burn
              </button>
              <button
                onClick={() => handleProgradeBurn(2.0)}
                className="flex-1 py-2 px-3 rounded-xl bg-cyan-500/30 hover:bg-cyan-500/40 text-cyan-200 border border-cyan-400 text-xs font-bold transition-colors"
              >
                +2.0 km/s Main Thruster
              </button>
              <button
                onClick={() => handleRetrogradeBurn(0.5)}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-colors"
              >
                -0.5 km/s Retrograde Burn
              </button>
            </div>

            {/* Automated Physics Grading Button */}
            <div className="pt-2">
              <button
                onClick={handleEvaluateMission}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-extrabold text-xs transition-all shadow-lg shadow-emerald-500/20"
              >
                Evaluate Trajectory & Grade Mission Orbit →
              </button>
            </div>

            {/* Mission Log Output */}
            {missionLog.length > 0 && (
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-400 space-y-1">
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Flight Telemetry Log:</span>
                {missionLog.map((log, i) => (
                  <div key={i} className="text-slate-300">{log}</div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
