import { GradeTier } from '../types/curriculum';

export function formatDistance(distanceKm: number, tier: GradeTier): string {
  if (tier === '6-8') {
    if (distanceKm >= 1e6) {
      return `${(distanceKm / 1e6).toFixed(1)} million km`;
    }
    return `${Math.round(distanceKm).toLocaleString()} km`;
  }
  if (tier === '9-10') {
    if (distanceKm >= 1e6) {
      return `${(distanceKm / 1e6).toFixed(2)} × 10⁶ km`;
    }
    return `${distanceKm.toFixed(1)} km`;
  }
  // 11-12
  const meters = distanceKm * 1000;
  return `${meters.toExponential(3)} m (${(distanceKm / 149597870.7).toFixed(3)} AU)`;
}

export function formatSpeed(speedKms: number, tier: GradeTier): string {
  if (tier === '6-8') {
    const mph = Math.round(speedKms * 2236.94);
    return `${speedKms.toFixed(1)} km/s (~${mph.toLocaleString()} mph)`;
  }
  if (tier === '9-10') {
    return `${speedKms.toFixed(2)} km/s (${(speedKms * 1000).toLocaleString()} m/s)`;
  }
  // 11-12
  const ms = speedKms * 1000;
  return `${ms.toExponential(3)} m/s`;
}

export function formatMass(massKg: number, tier: GradeTier): string {
  if (tier === '6-8') {
    if (massKg >= 1e24) {
      const earthMasses = (massKg / 5.972e24).toFixed(2);
      return `${earthMasses} Earth Masses`;
    }
    return `${massKg.toExponential(2)} kg`;
  }
  if (tier === '9-10') {
    return `${massKg.toExponential(2)} kg`;
  }
  return `${massKg.toExponential(4)} kg`;
}

export function formatForce(forceN: number, tier: GradeTier): string {
  if (tier === '6-8') {
    if (forceN > 1e18) return 'Enormous Gravitational Pull';
    if (forceN > 1000) return `${Math.round(forceN).toLocaleString()} Newtons (N)`;
    return `${forceN.toFixed(1)} N`;
  }
  if (tier === '9-10') {
    if (forceN >= 1e6 || forceN <= 0.01) {
      return `${forceN.toExponential(2)} N`;
    }
    return `${forceN.toFixed(2)} N`;
  }
  return `${forceN.toExponential(3)} N`;
}

export function formatEnergy(energyJoules: number, tier: GradeTier): string {
  if (tier === '6-8') {
    return `${(energyJoules / 1e6).toFixed(1)} MJ`;
  }
  if (tier === '9-10') {
    return `${energyJoules.toExponential(2)} J`;
  }
  return `${energyJoules.toExponential(3)} J`;
}
