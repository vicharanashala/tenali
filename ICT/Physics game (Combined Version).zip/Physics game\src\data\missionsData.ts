import { MissionSpec } from '../types/physics';

export const ORBITAL_MISSIONS: MissionSpec[] = [
  {
    id: 'm1_leo',
    title: 'Mission 1: Low Earth Orbit Insertion',
    tier: 'all',
    briefing: 'Launch a reconnaissance satellite into a circular Low Earth Orbit (LEO) between 250 km and 450 km altitude.',
    objective: 'Burn prograde until orbital speed reaches ~7.7 km/s with eccentricity e < 0.05.',
    initialState: {
      r: 6671, // 300 km altitude
      v: 6.2,  // suborbital
      altitudeKm: 300
    },
    targetConditions: {
      minPeriapsisKm: 6571, // 200 km alt
      maxPeriapsisKm: 6871, // 500 km alt
      maxEccentricity: 0.06,
      minSpeedKms: 7.5,
      maxSpeedKms: 8.1
    },
    hints: [
      'Circular velocity at 300 km is v_c = √(GM/r) ≈ 7.73 km/s.',
      'Fire the Prograde (+Δv) thruster when near apoapsis to raise your periapsis.'
    ],
    xpReward: 100
  },
  {
    id: 'm2_geo',
    title: 'Mission 2: Geostationary Orbit Parking',
    tier: '9-10',
    briefing: 'Place a telecommunications satellite into Geostationary Orbit where its orbital period matches Earth’s 24.0 hour rotation.',
    objective: 'Circularize the orbit at r = 42,164 km (altitude 35,786 km) with period T = 24.0 ± 0.5 hours.',
    initialState: {
      r: 6671,
      v: 10.2, // GTO transfer speed
      altitudeKm: 300
    },
    targetConditions: {
      minPeriapsisKm: 41000,
      maxPeriapsisKm: 43500,
      targetPeriodHours: 24.0,
      periodToleranceHours: 0.8,
      maxEccentricity: 0.05
    },
    hints: [
      'Kepler’s 3rd Law gives r³ = GM·T²/(4π²). For T = 86,164 s, r = 42,164 km.',
      'When your transfer ellipse reaches 42,164 km, fire a prograde burn of ~1.47 km/s to circularize.'
    ],
    xpReward: 150
  },
  {
    id: 'm3_lunar_flyby',
    title: 'Mission 3: Lunar Gravity-Assist Flyby',
    tier: 'all',
    briefing: 'Send the Artemis Explorer on a figure-8 free-return trajectory around the Moon and swing back toward Earth.',
    objective: 'Inject into translunar trajectory (v ≈ 10.9 km/s) and pass within 5,000 km of the Moon.',
    initialState: {
      r: 6771,
      v: 7.7,
      altitudeKm: 400
    },
    targetConditions: {
      minSpeedKms: 10.7,
      maxSpeedKms: 11.1
    },
    hints: [
      'Raise apoapsis out to the Moon’s orbital distance of ~384,000 km.',
      'The Moon’s gravitational pull will bend the trajectory into a free-return loop.'
    ],
    xpReward: 200
  },
  {
    id: 'm4_hohmann_mars',
    title: 'Mission 4: Hohmann Transfer to Mars',
    tier: '11-12',
    briefing: 'Execute an interplanetary Hohmann transfer orbit from Earth (1.0 AU) to Mars (1.524 AU).',
    objective: 'Calculate and burn Δv₁ ≈ 2.94 km/s at Earth departure, then Δv₂ ≈ 2.65 km/s upon Mars arrival.',
    initialState: {
      r: 149597870, // 1 AU
      v: 29.78,     // Earth heliocentric speed
      altitudeKm: 0
    },
    targetConditions: {
      minPeriapsisKm: 148000000,
      minApoapsisKm: 225000000,
      maxApoapsisKm: 232000000,
      maxEccentricity: 0.25
    },
    hints: [
      'Semi-major axis of transfer ellipse is a = (r_earth + r_mars)/2 = 1.262 AU.',
      'Perihelion velocity is v_t1 = √(GM_sun · (2/r₁ - 1/a)) = 32.73 km/s. Δv = 32.73 - 29.78 = 2.95 km/s.'
    ],
    xpReward: 250
  },
  {
    id: 'm5_molniya',
    title: 'Mission 5: High-Latitude Molniya Orbit',
    tier: '11-12',
    briefing: 'Design a highly eccentric Molniya communication orbit with e ≈ 0.72 to maximize dwell time over the northern hemisphere.',
    objective: 'Achieve eccentricity between 0.65 and 0.75 with perigee at 600 km and apogee at 39,000 km.',
    initialState: {
      r: 6971,
      v: 7.6,
      altitudeKm: 600
    },
    targetConditions: {
      minEccentricity: 0.65,
      maxEccentricity: 0.76,
      targetPeriodHours: 12.0,
      periodToleranceHours: 1.0
    },
    hints: [
      'Kepler’s 2nd law dictates that the satellite moves slowest near apogee, spending over 8 hours of its 12-hour orbit over the target zone.',
      'Fire a strong prograde burn at perigee until apogee reaches ~40,000 km.'
    ],
    xpReward: 150
  },
  {
    id: 'm6_escape',
    title: 'Mission 6: Solar System Escape',
    tier: 'all',
    briefing: 'Propel the interstellar probe beyond the Sun’s gravitational grasp into the interstellar medium like Voyager 1.',
    objective: 'Accelerate the probe beyond heliocentric escape velocity (v > 42.1 km/s at 1 AU).',
    initialState: {
      r: 149597870,
      v: 29.78,
      altitudeKm: 0
    },
    targetConditions: {
      minSpeedKms: 42.2
    },
    hints: [
      'Escape velocity from the Sun at 1 AU is v_esc = √(2GM/r) = √2 · 29.78 km/s ≈ 42.1 km/s.',
      'A burn of +12.4 km/s in the prograde direction will turn the orbit into an open hyperbola (e > 1).'
    ],
    xpReward: 200
  },
  {
    id: 'm7_lagrange',
    title: 'Mission 7: Sun-Earth L1 Halo Station-Keeping',
    tier: '11-12',
    briefing: 'Station the Solar Dynamics Observatory at the Sun-Earth L1 Lagrange point (1.5 million km Sunward of Earth).',
    objective: 'Balance the inward solar pull against Earth’s outward gravitational tug at the neutral balance point.',
    initialState: {
      r: 148100000, // 1.5 million km from Earth
      v: 29.78 * 0.99,
      altitudeKm: 0
    },
    targetConditions: {
      minSpeedKms: 29.4,
      maxSpeedKms: 30.1
    },
    hints: [
      'At L1, the Sun’s stronger gravity is partially offset by Earth’s pull, allowing an orbit with a shorter radius to have the same 1-year period as Earth.'
    ],
    xpReward: 200
  },
  {
    id: 'm8_reentry',
    title: 'Mission 8: Safe Atmospheric Re-Entry',
    tier: 'all',
    briefing: 'Guide a returning astronaut capsule from a 400 km circular orbit into the atmosphere for a splashdown.',
    objective: 'Fire a retrograde burn (-Δv) to drop periapsis below 90 km so atmospheric friction can safely capture the craft.',
    initialState: {
      r: 6771, // 400 km
      v: 7.67,
      altitudeKm: 400
    },
    targetConditions: {
      maxPerigeeAltitudeKm: 90
    },
    hints: [
      'Firing Retrograde (-Δv) reduces your velocity, which lowers the opposite side of your orbit (periapsis).',
      'A modest retrograde burn of ~120 m/s is all that is needed to drop periapsis from 400 km into the thick atmosphere (< 80 km).'
    ],
    xpReward: 150
  }
];
