import { R_SUN_KM, R_EARTH_KM, R_MOON_KM } from './constants';

export type EclipseType = 'TOTAL_SOLAR' | 'ANNULAR_SOLAR' | 'HYBRID_SOLAR' | 'PARTIAL_SOLAR' | 'TOTAL_LUNAR' | 'PARTIAL_LUNAR' | 'PENUMBRAL_LUNAR' | 'NONE';

export interface ShadowConeData {
  umbraLengthKm: number;
  umbraHalfAngleRad: number;
  penumbraApexDistKm: number;
  penumbraHalfAngleRad: number;
  umbraRadiusAtTargetKm: number;
  penumbraRadiusAtTargetKm: number;
}

// Compute shadow geometry for an occulting body illuminated by the Sun
export function computeShadowCones(
  occultingRadiusKm: number,
  distSunToBodyKm: number,
  distBodyToObserverKm: number
): ShadowConeData {
  const Rs = R_SUN_KM;
  const Rb = occultingRadiusKm;
  const d = distSunToBodyKm;
  const D = distBodyToObserverKm;

  // Umbra apex distance from body center (pointing away from Sun)
  const umbraLengthKm = (Rb * d) / (Rs - Rb);
  const umbraHalfAngleRad = Math.asin((Rs - Rb) / d);

  // Penumbra vertex distance (pointing towards Sun from body center)
  const penumbraApexDistKm = (Rb * d) / (Rs + Rb);
  const penumbraHalfAngleRad = Math.asin((Rs + Rb) / d);

  // Radius of umbra cross section at observer plane
  // Note: if D > umbraLengthKm, umbra is negative (antumbra region)
  const umbraRadiusAtTargetKm = Rb - D * Math.tan(umbraHalfAngleRad);

  // Radius of penumbra cross section at observer plane
  const penumbraRadiusAtTargetKm = Rb + D * Math.tan(penumbraHalfAngleRad);

  return {
    umbraLengthKm,
    umbraHalfAngleRad,
    penumbraApexDistKm,
    penumbraHalfAngleRad,
    umbraRadiusAtTargetKm,
    penumbraRadiusAtTargetKm
  };
}

// Classify Eclipse for Solar (Moon occults Sun from Earth)
export function classifySolarEclipse(
  distEarthMoonKm: number,
  apparentDistFromNodeDeg: number // Angular distance of Moon from Ecliptic plane
): { type: EclipseType; coveragePercent: number; umbraRadiusKm: number } {
  const dSunMoon = 149597870 - distEarthMoonKm;
  const cones = computeShadowCones(R_MOON_KM, dSunMoon, distEarthMoonKm);

  // Moon's vertical offset from Earth's center in km due to inclination
  const verticalOffsetKm = distEarthMoonKm * Math.sin((apparentDistFromNodeDeg * Math.PI) / 180);
  const offset = Math.abs(verticalOffsetKm);

  const penumbraRadius = cones.penumbraRadiusAtTargetKm;
  const umbraRadius = cones.umbraRadiusAtTargetKm;

  if (offset > penumbraRadius + R_EARTH_KM) {
    return { type: 'NONE', coveragePercent: 0, umbraRadiusKm: 0 };
  }

  // Inside umbra path?
  if (offset < Math.abs(umbraRadius)) {
    if (umbraRadius > 0) {
      return { type: 'TOTAL_SOLAR', coveragePercent: 100, umbraRadiusKm: umbraRadius };
    } else {
      // Antumbra (Moon apparent size smaller than Sun)
      return { type: 'ANNULAR_SOLAR', coveragePercent: 92, umbraRadiusKm: Math.abs(umbraRadius) };
    }
  }

  // In Penumbra
  const coverage = Math.max(5, Math.min(95, Math.round((1 - offset / penumbraRadius) * 100)));
  return { type: 'PARTIAL_SOLAR', coveragePercent: coverage, umbraRadiusKm: 0 };
}

// Classify Eclipse for Lunar (Earth occults Sun from Moon)
export function classifyLunarEclipse(
  distEarthMoonKm: number,
  apparentDistFromNodeDeg: number
): { type: EclipseType; coveragePercent: number } {
  const dSunEarth = 149597870;
  const cones = computeShadowCones(R_EARTH_KM, dSunEarth, distEarthMoonKm);

  const verticalOffsetKm = distEarthMoonKm * Math.sin((apparentDistFromNodeDeg * Math.PI) / 180);
  const offset = Math.abs(verticalOffsetKm);

  const umbraRadius = cones.umbraRadiusAtTargetKm;
  const penumbraRadius = cones.penumbraRadiusAtTargetKm;

  if (offset > penumbraRadius + R_MOON_KM) {
    return { type: 'NONE', coveragePercent: 0 };
  }

  if (offset + R_MOON_KM <= umbraRadius) {
    return { type: 'TOTAL_LUNAR', coveragePercent: 100 };
  }

  if (offset < umbraRadius + R_MOON_KM) {
    const coverage = Math.round(((umbraRadius + R_MOON_KM - offset) / (2 * R_MOON_KM)) * 100);
    return { type: 'PARTIAL_LUNAR', coveragePercent: Math.min(99, Math.max(1, coverage)) };
  }

  return { type: 'PENUMBRAL_LUNAR', coveragePercent: 30 };
}
