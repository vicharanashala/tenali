import * as THREE from 'three';

// Procedural Canvas2D planet texture generator
// Generates deterministic high-resolution planetary textures with zero external URL dependencies

const textureCache = new Map<string, THREE.CanvasTexture>();

// Simple deterministic 2D pseudo-random noise generator
function pseudoNoise(x: number, y: number, seed: number): number {
  const n = Math.sin(x * 12.9898 + y * 78.233 + seed * 137.5) * 43758.5453;
  return n - Math.floor(n);
}

function smoothNoise(x: number, y: number, seed: number): number {
  const i = Math.floor(x);
  const j = Math.floor(y);
  const fx = x - i;
  const fy = y - j;

  // Smoothstep interpolation
  const sx = fx * fx * (3 - 2 * fx);
  const sy = fy * fy * (3 - 2 * fy);

  const n00 = pseudoNoise(i, j, seed);
  const n10 = pseudoNoise(i + 1, j, seed);
  const n01 = pseudoNoise(i, j + 1, seed);
  const n11 = pseudoNoise(i + 1, j + 1, seed);

  const nx0 = n00 * (1 - sx) + n10 * sx;
  const nx1 = n01 * (1 - sx) + n11 * sx;

  return nx0 * (1 - sy) + nx1 * sy;
}

function fractalNoise(x: number, y: number, octaves: number, persistence: number, seed: number): number {
  let total = 0;
  let frequency = 1;
  let amplitude = 1;
  let maxValue = 0;

  for (let i = 0; i < octaves; i++) {
    total += smoothNoise(x * frequency, y * frequency, seed + i * 17) * amplitude;
    maxValue += amplitude;
    amplitude *= persistence;
    frequency *= 2;
  }

  return total / maxValue;
}

export function createSunTexture(width = 1024, height = 512): THREE.CanvasTexture {
  const cached = textureCache.get('sun');
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const v = y / height;
    for (let x = 0; x < width; x++) {
      const u = x / width;
      const n1 = fractalNoise(u * 12, v * 6, 4, 0.5, 42);
      const n2 = fractalNoise(u * 28, v * 14, 3, 0.5, 99);
      const gran = n1 * 0.7 + n2 * 0.3;

      const idx = (y * width + x) * 4;
      // Vibrant solar plasma: yellow-orange-red core with bright convection granules
      data[idx] = Math.min(255, Math.floor(255 * (0.95 + gran * 0.15))); // R
      data[idx + 1] = Math.min(255, Math.floor(200 * gran * 1.2));       // G
      data[idx + 2] = Math.min(255, Math.floor(40 * gran * gran));       // B
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  // Add solar magnetic limb flare highlights
  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, 'rgba(255, 120, 0, 0.3)');
  grad.addColorStop(0.5, 'rgba(255, 230, 80, 0.1)');
  grad.addColorStop(1, 'rgba(255, 120, 0, 0.3)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  textureCache.set('sun', texture);
  return texture;
}

export function createEarthTexture(width = 1024, height = 512): THREE.CanvasTexture {
  const cached = textureCache.get('earth');
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const lat = (y / height - 0.5) * Math.PI; // -pi/2 to +pi/2
    const v = y / height;

    for (let x = 0; x < width; x++) {
      const u = x / width;
      const idx = (y * width + x) * 4;

      // Polar ice caps
      const isPolar = Math.abs(lat) > 1.25;
      if (isPolar) {
        const iceNoise = fractalNoise(u * 10, v * 10, 3, 0.5, 12);
        if (Math.abs(lat) > 1.35 || iceNoise > 0.4) {
          data[idx] = 240;
          data[idx + 1] = 248;
          data[idx + 2] = 255;
          data[idx + 3] = 255;
          continue;
        }
      }

      // Continents vs Ocean using multi-octave noise
      const continentVal = fractalNoise(u * 6, v * 3, 5, 0.55, 77);
      const isLand = continentVal > 0.51;

      if (isLand) {
        // Vegetation, mountain elevation, arid deserts
        const detail = fractalNoise(u * 18, v * 9, 3, 0.5, 33);
        const isArid = Math.abs(lat) < 0.45 && detail > 0.55;

        if (isArid) {
          // Sahara/desert tone
          data[idx] = 195 + detail * 40;
          data[idx + 1] = 160 + detail * 30;
          data[idx + 2] = 100 + detail * 20;
        } else {
          // Lush green / temperate forest / mountain
          const elev = (continentVal - 0.51) / 0.49;
          if (elev > 0.6) {
            // Mountain peak brown/gray
            data[idx] = 130 + detail * 30;
            data[idx + 1] = 120 + detail * 20;
            data[idx + 2] = 100 + detail * 20;
          } else {
            // Forest green
            data[idx] = 34 + detail * 40;
            data[idx + 1] = 110 + detail * 60;
            data[idx + 2] = 45 + detail * 30;
          }
        }
      } else {
        // Deep blue ocean with coastal shallow cyan
        const depth = (0.51 - continentVal) / 0.51;
        if (depth < 0.08) {
          // Coastal shelf
          data[idx] = 18;
          data[idx + 1] = 95;
          data[idx + 2] = 160;
        } else {
          // Abyssal deep ocean
          data[idx] = 10 + depth * 10;
          data[idx + 1] = 35 + depth * 20;
          data[idx + 2] = 85 + depth * 40;
        }
      }

      // Cloud layer blending
      const cloudVal = fractalNoise(u * 8 + 0.1, v * 4, 4, 0.55, 88);
      if (cloudVal > 0.56) {
        const cloudDensity = (cloudVal - 0.56) / 0.44;
        const alpha = Math.min(1, cloudDensity * 1.5);
        data[idx] = Math.floor(data[idx] * (1 - alpha) + 255 * alpha);
        data[idx + 1] = Math.floor(data[idx + 1] * (1 - alpha) + 255 * alpha);
        data[idx + 2] = Math.floor(data[idx + 2] * (1 - alpha) + 255 * alpha);
      }

      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  textureCache.set('earth', texture);
  return texture;
}

export function createMoonTexture(width = 1024, height = 512): THREE.CanvasTexture {
  const cached = textureCache.get('moon');
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const v = y / height;
    for (let x = 0; x < width; x++) {
      const u = x / width;
      const idx = (y * width + x) * 4;

      // Highlands vs Basaltic Maria
      const mariaNoise = fractalNoise(u * 5, v * 2.5, 4, 0.5, 101);
      const craterNoise = fractalNoise(u * 22, v * 11, 4, 0.5, 202);

      let brightness = mariaNoise > 0.53 ? 90 + mariaNoise * 40 : 160 + mariaNoise * 60;
      brightness += (craterNoise - 0.5) * 50;
      brightness = Math.max(40, Math.min(235, brightness));

      data[idx] = brightness;
      data[idx + 1] = brightness * 0.98;
      data[idx + 2] = brightness * 0.95;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  textureCache.set('moon', texture);
  return texture;
}

export function createMarsTexture(width = 1024, height = 512): THREE.CanvasTexture {
  const cached = textureCache.get('mars');
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const lat = (y / height - 0.5) * Math.PI;
    const v = y / height;

    for (let x = 0; x < width; x++) {
      const u = x / width;
      const idx = (y * width + x) * 4;

      // Polar caps
      if (Math.abs(lat) > 1.38) {
        data[idx] = 245;
        data[idx + 1] = 240;
        data[idx + 2] = 235;
        data[idx + 3] = 255;
        continue;
      }

      // Rusty iron oxide deserts and dark volcanic basalt terrain
      const n1 = fractalNoise(u * 8, v * 4, 4, 0.5, 305);
      const darkRegion = n1 > 0.58;

      if (darkRegion) {
        // Syrtis Major dark basalt
        data[idx] = 110 + n1 * 30;
        data[idx + 1] = 60 + n1 * 20;
        data[idx + 2] = 40 + n1 * 15;
      } else {
        // Rusty orange-red regolith
        data[idx] = 200 + n1 * 45;
        data[idx + 1] = 95 + n1 * 35;
        data[idx + 2] = 55 + n1 * 25;
      }
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  textureCache.set('mars', texture);
  return texture;
}

export function createJupiterTexture(width = 1024, height = 512): THREE.CanvasTexture {
  const cached = textureCache.get('jupiter');
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const v = y / height;
    for (let x = 0; x < width; x++) {
      const u = x / width;
      const idx = (y * width + x) * 4;

      // Alternating atmospheric belts and zones
      const bandWave = Math.sin(v * Math.PI * 18);
      const turbulence = fractalNoise(u * 20, v * 10, 3, 0.5, 410) * 0.25;
      const band = (bandWave + turbulence + 1) * 0.5;

      // Base cream/amber/russet colors
      let r = 190 + band * 45;
      let g = 145 + band * 35;
      let b = 105 + band * 25;

      // Great Red Spot at ~22 deg South latitude, u around 0.65
      const spotDistX = Math.abs(u - 0.65);
      const spotDistY = Math.abs(v - 0.62) * 2.2;
      const spotRadius = Math.sqrt(spotDistX * spotDistX + spotDistY * spotDistY);

      if (spotRadius < 0.07) {
        const spotWeight = 1 - spotRadius / 0.07;
        r = r * (1 - spotWeight) + 215 * spotWeight;
        g = g * (1 - spotWeight) + 75 * spotWeight;
        b = b * (1 - spotWeight) + 55 * spotWeight;
      }

      data[idx] = Math.min(255, Math.floor(r));
      data[idx + 1] = Math.min(255, Math.floor(g));
      data[idx + 2] = Math.min(255, Math.floor(b));
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  textureCache.set('jupiter', texture);
  return texture;
}

export function createSaturnRingTexture(size = 512): THREE.CanvasTexture {
  const cached = textureCache.get('saturnRing');
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = 1;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, size, 0);
  // C Ring (faint inner)
  grad.addColorStop(0.0, 'rgba(180, 160, 130, 0.0)');
  grad.addColorStop(0.15, 'rgba(195, 175, 140, 0.4)');
  // B Ring (brightest, dense)
  grad.addColorStop(0.2, 'rgba(230, 215, 175, 0.85)');
  grad.addColorStop(0.58, 'rgba(220, 200, 165, 0.88)');
  // Cassini Division (dark gap)
  grad.addColorStop(0.60, 'rgba(40, 30, 20, 0.08)');
  grad.addColorStop(0.65, 'rgba(40, 30, 20, 0.08)');
  // A Ring (outer)
  grad.addColorStop(0.67, 'rgba(215, 195, 160, 0.7)');
  grad.addColorStop(0.96, 'rgba(190, 170, 140, 0.6)');
  // Encke division & outer edge
  grad.addColorStop(1.0, 'rgba(180, 160, 130, 0.0)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, 1);

  const texture = new THREE.CanvasTexture(canvas);
  textureCache.set('saturnRing', texture);
  return texture;
}

export function getProceduralTexture(bodyId: string): THREE.CanvasTexture {
  switch (bodyId) {
    case 'sun':
      return createSunTexture();
    case 'earth':
      return createEarthTexture();
    case 'moon':
      return createMoonTexture();
    case 'mars':
      return createMarsTexture();
    case 'jupiter':
      return createJupiterTexture();
    default:
      return createMoonTexture();
  }
}
