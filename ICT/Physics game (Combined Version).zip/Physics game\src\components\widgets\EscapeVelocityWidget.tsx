import React, { useState } from 'react';
import { Play } from 'lucide-react';
import { soundEngine } from '../../utils/soundEngine';

interface WorldEscapeData {
  id: string;
  name: string;
  v_orbit: number; // km/s
  v_escape: number; // km/s
  color: string;
}

const WORLDS: WorldEscapeData[] = [
  { id: 'moon', name: 'Moon', v_orbit: 1.68, v_escape: 2.38, color: '#CBD5E1' },
  { id: 'mars', name: 'Mars', v_orbit: 3.56, v_escape: 5.03, color: '#EF4444' },
  { id: 'earth', name: 'Earth', v_orbit: 7.91, v_escape: 11.19, color: '#38BDF8' },
  { id: 'jupiter', name: 'Jupiter', v_orbit: 42.1, v_escape: 59.5, color: '#F97316' },
];

export const EscapeVelocityWidget: React.FC = () => {
  const [worldIdx, setWorldIdx] = useState<number>(2); // Earth
  const [launchSpeed, setLaunchSpeed] = useState<number>(11.2);

  const world = WORLDS[worldIdx];
  const isEscape = launchSpeed >= world.v_escape;
  const isOrbit = launchSpeed >= world.v_orbit && launchSpeed < world.v_escape;

  const handleLaunch = () => {
    soundEngine.playThruster(0.3);
    if (isEscape) {
      soundEngine.playVictory();
    } else {
      soundEngine.playClick(600);
    }
  };

  return (
    <div className="flex flex-col items-center w-full h-full bg-slate-950/60 p-3 rounded-xl border border-slate-800">
      <div className="w-full flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Escape Velocity Barrier</span>
        <span className={`text-xs font-mono font-bold ${isEscape ? 'text-emerald-400' : isOrbit ? 'text-purple-400' : 'text-rose-400'}`}>
          {isEscape ? '🚀 ESCAPING TO INTERPLANETARY SPACE' : isOrbit ? '🛰 CLOSED BOUND ORBIT' : '💥 SUB-ORBITAL IMPACT'}
        </span>
      </div>

      {/* Trajectory Canvas SVG */}
      <div className="w-full max-w-[340px] aspect-[16/9] bg-slate-900/80 rounded-xl border border-slate-800 relative flex items-center justify-center p-2">
        <svg viewBox="0 0 320 150" className="w-full h-full">
          {/* Gravitational Potential Well Curve */}
          <path
            d="M 20,40 Q 160,140 300,40"
            fill="none"
            stroke="rgba(148, 163, 184, 0.3)"
            strokeWidth="1.5"
            strokeDasharray="4 2"
          />
          <text x="160" y="130" textAnchor="middle" fill="#64748B" fontSize="9" fontFamily="monospace">
            Gravitational Potential Well
          </text>

          {/* Central Body */}
          <circle cx="160" cy="100" r="22" fill={world.color} />
          <text x="160" y="104" textAnchor="middle" fill="#0F172A" fontSize="9" fontWeight="bold">
            {world.name}
          </text>

          {/* Trajectory Line based on launch speed */}
          {(() => {
            if (isEscape) {
              return (
                <path
                  d="M 160,78 Q 210,30 310,15"
                  fill="none"
                  stroke="#10B981"
                  strokeWidth="2.5"
                  strokeDasharray="4 2"
                  className="animate-pulse"
                />
              );
            } else if (isOrbit) {
              return (
                <ellipse
                  cx="160"
                  cy="75"
                  rx="60"
                  ry="25"
                  fill="none"
                  stroke="#A855F7"
                  strokeWidth="2"
                />
              );
            } else {
              return (
                <path
                  d="M 160,78 Q 185,55 180,88"
                  fill="none"
                  stroke="#EF4444"
                  strokeWidth="2"
                  strokeDasharray="3 3"
                />
              );
            }
          })()}
        </svg>
      </div>

      {/* World Selector Tabs */}
      <div className="grid grid-cols-4 gap-1 w-full mt-2">
        {WORLDS.map((w, idx) => (
          <button
            key={w.id}
            onClick={() => {
              setWorldIdx(idx);
              setLaunchSpeed(WORLDS[idx].v_escape);
              soundEngine.playClick(700);
            }}
            className={`py-1 rounded text-xs font-medium transition-colors ${
              worldIdx === idx ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400' : 'bg-slate-800 text-slate-400'
            }`}
          >
            {w.name}
          </button>
        ))}
      </div>

      {/* Controls & Thresholds */}
      <div className="w-full mt-2 space-y-2 font-mono text-xs">
        <div className="flex justify-between items-center text-slate-400">
          <span>Launch Velocity: <strong className="text-cyan-400">{launchSpeed.toFixed(1)} km/s</strong></span>
          <span>Required v_esc: <strong className="text-emerald-400">{world.v_escape.toFixed(1)} km/s</strong></span>
        </div>

        <input
          type="range"
          min={world.v_orbit * 0.5}
          max={world.v_escape * 1.5}
          step="0.1"
          value={launchSpeed}
          onChange={(e) => setLaunchSpeed(parseFloat(e.target.value))}
          className="w-full accent-emerald-400 cursor-pointer"
        />

        <button
          onClick={handleLaunch}
          className="w-full py-1.5 flex items-center justify-center gap-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-semibold transition-colors"
        >
          <Play className="w-3.5 h-3.5 fill-current" /> Fire Rocket Launch
        </button>
      </div>
    </div>
  );
};
